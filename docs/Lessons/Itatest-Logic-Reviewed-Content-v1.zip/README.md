# Itatest — Reasoning on texts and data / targeted content revision

Content only. Source: provided content export (local preview). Existing chapter order and IDs preserved. 178 lesson sections, 79 questions, 76 exercises, plus 15 original five-option mock items and a supplementary lesson.

`patches.json` lists targeted before/after field changes for 27 records. `subjects/logic` contains updated record JSON and existing chapter materials. `database-sources/logic` contains source HTML snapshots with targeted edits; original SHA metadata is historical, not the checksum of revised content. Source Markdown snapshots under database-sources are historical; use revised lesson-section JSON as canonical. Other metadata, document records and frontend samples are retained reference material, not replacement data. `new-mock-questions.json` is a separate content schema for Codex mapping; 0-based answers. Do not import as an existing database row schema without adapting. `supplemental-lesson.md` is original supplemental content.

The quarantined exercise remains quarantined until explicit editorial approval; its visible lesson wording/solution and candidate record are corrected. Do not silently activate it or duplicate it with an existing test. Keep the existing four-option practice items; the new mock matches 15-question/30-minute format.

Verification: source IDs and option/key consistency verified for every original question/exercise; mock unique IDs and options checked. This is targeted review, not certification of every lesson, embedded example, figure or historical source. HTML display and database integration not tested. No code or database changed.
