# CISIA syllabus mapping — Reasoning on texts and data
Source: https://www.cisiaonline.it/en/cent/cent-s/structure-and-syllabus (checked 2026-11-24). Official section: 15 questions / 30 minutes.

| Official area (paraphrased) | Existing coverage | Supplement |
|---|---|---|
| Deductive logic: connectives, equivalence, quantifiers, validity, conditions and sets | Ch. 1–13, 18, R1 | Explicit set operations; existential assumptions corrected |
| Data interpretation: conversion, extraction, evidence, sorting and procedures | Ch. 14–17, 19, R1/R2 | Histogram density, ranking, conversion and weighted rates |
| Problem solving: representation, calculation, ratios, mean, equations, feasibility | Ch. 18–19, R1/R2 | Feasibility and mock practice |

Mapping establishes topic presence, not exhaustive independent validation. Existing four-option practice is retained; new timed mock has five options per item.
