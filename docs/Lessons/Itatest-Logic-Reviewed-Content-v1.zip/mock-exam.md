# Reasoning on texts and data — Original practice mock
15 questions / 30 minutes

1. If P then Q. Q is false. What must follow?
   A. P is true
   B. P is false
   C. Q is true
   D. P and Q are true
   E. No conclusion about P is possible

2. Which is the negation of "Every applicant submitted at least one form"?
   A. No applicant submitted a form
   B. Every applicant submitted no forms
   C. At least one applicant submitted no forms
   D. At least one applicant submitted two forms
   E. Every applicant submitted exactly one form

3. Assume inclusive OR. P or Q is false. What follows?
   A. P and Q are both false
   B. P and Q are both true
   C. Exactly one is true
   D. P is true
   E. Q is true

4. A is necessary but not sufficient for B. Which statement must hold?
   A. A implies B
   B. Not B implies not A
   C. A and B never occur together
   D. B implies A
   E. A is equivalent to B

5. In classical predicate logic, no objects belong to class A. Which pair is true?
   A. Some A are B; Some A are not B
   B. All A are B; Some A are B
   C. No A are B; Some A are B
   D. All A are B; Some A are not B
   E. All A are B; No A are B

6. U={1,2,3,4,5}, A={1,2,3}, B={3,4}. What is A\B?
   A. {1,2,3,4}
   B. {1,2}
   C. {3}
   D. {4,5}
   E. {3,4}

7. A histogram uses frequency density. A class interval has width 8 and height 3. What is its frequency?
   A. 3
   B. 8
   C. 11
   D. 24
   E. 5

8. A: 18 successes out of 30; B: 21 out of 70; C: 15 out of 20. Which has the highest success rate?
   A. A
   B. B
   C. C
   D. All equal
   E. Cannot be determined

9. Group A has 40 people and a mean score of 6. Group B has 10 people and a mean of 11. What is the combined mean?
   A. 7
   B. 8.5
   C. 6
   D. 11
   E. 17

10. A value rises from 40 to 50, then falls to 40. What is the net percentage change from the original value?
   A. 10%
   B. 5%
   C. −5%
   D. 25%
   E. 0%

11. A store sold 90 items in June and 120 in July. Which calculation gives the percentage increase?
   A. (120−90)/120×100
   B. (120−90)/90×100
   C. 120/90
   D. (120+90)/90×100
   E. 90/120×100

12. 73 passengers require buses with 20 seats each. What is the minimum number of buses?
   A. 3
   B. 3.65
   C. 5
   D. 4
   E. 20

13. A:B=3:5 and A+B=64. What is B?
   A. 24
   B. 32
   C. 40
   D. 48
   E. 56

14. A taxi charges €4 plus €2 per kilometre. For a total charge of €18, how far was the trip?
   A. 7 km
   B. 9 km
   C. 11 km
   D. 14 km
   E. 22 km

15. Of 70 people, 40 have A, 35 have B and 15 have both. How many have neither?
   A. 15
   B. 20
   C. 25
   D. 30
   E. 10