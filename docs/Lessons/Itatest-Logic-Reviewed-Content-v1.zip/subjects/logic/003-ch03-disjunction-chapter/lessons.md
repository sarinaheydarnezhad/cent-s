# فصل ۳: فصل — «A or B» (Disjunction)

Original chapter ID: `74C76D87-B10A-FC12-22CA-7BBCE457B58F`

Original chapter import key: `logic/ch03-disjunction.html#chapter`

## فصل ۳: فصل — «A or B» (Disjunction)

Section ID: `E1C1DF74-E7F7-A8C6-E71F-147B9C3076AA`

Import key: `logic/ch03-disjunction.html#intro`

Topic ID: `0F228A63-7FE8-E532-42D8-EB7D48B2A42C`

Source: [logic/ch03-disjunction.html](../../../database-sources/logic/0F2CA150-41C3-0AEE-548B-844AE19755F9.html) — ID `0F2CA150-41C3-0AEE-548B-844AE19755F9`

CENT LOGIC — PART A · CHAPTER 3 / 13
فصل ۳: فصل — «A or B» (Disjunction)
کلمه‌ی «or» توی زبان روزمره و توی منطق دو معنی متفاوت داره. تشخیص اینکه کدوم معنی مدنظر سؤاله —
یا
— دقیقاً همون چیزیه که این فصل یادت می‌ده.
inclusive
exclusive

## Bاین مبحث چیست؟

Section ID: `0A04AB5C-B434-FBC5-5EDA-9CDEC86ACA84`

Import key: `logic/ch03-disjunction.html#section-01`

Topic ID: `0F228A63-7FE8-E532-42D8-EB7D48B2A42C`

Source: [logic/ch03-disjunction.html](../../../database-sources/logic/0F2CA150-41C3-0AEE-548B-844AE19755F9.html) — ID `0F2CA150-41C3-0AEE-548B-844AE19755F9`

این مبحث چیست؟
B
هر وقت سؤال با کلمه‌ی «or» دو (یا چند) گزاره رو به هم وصل کنه، با یک فصل
روبرویی. اجزای تشکیل‌دهنده‌اش رو
می‌گن. نکته‌ی کلیدی اینه که «or» می‌تونه دو جور معنی بده و باید از روی زمینه‌ی جمله تشخیص بدی کدومه.
(disjunction)
disjuncts

## Cمفهوم اصلی

Section ID: `9B442D44-4377-043F-68F1-F015F4E8BDE2`

Import key: `logic/ch03-disjunction.html#section-02`

Topic ID: `0F228A63-7FE8-E532-42D8-EB7D48B2A42C`

Source: [logic/ch03-disjunction.html](../../../database-sources/logic/0F2CA150-41C3-0AEE-548B-844AE19755F9.html) — ID `0F2CA150-41C3-0AEE-548B-844AE19755F9`

مفهوم اصلی
C
«A or B» درسته اگه
از A یا B درست باشه — حتی اگه هر دو درست باشن.
قدم ۱ — فصل شمولی (inclusive or):
حداقل یکی
نمونه
"A triangle can be defined as a polygon with three sides or as a polygon with three vertices."
اینجا هر دو تعریف هم‌زمان درستن و هیچ تضادی ندارن — این نشونه‌ی یک
است.
inclusive or
A
B
A or B (inclusive)
T
T
T
T
F
T
F
T
T
F
F
F
فقط یک حالت وجود داره که کل گزاره غلط می‌شه: وقتی
طرف غلط باشن. (نسخه‌ی اسکن‌شده‌ی منبع در این جدول دچار جابه‌جایی ستون‌ها بود؛ جدول بالا نسخه‌ی استاندارد و درست منطق گزاره‌ایه.)
هر دو
«A or B» فقط وقتی درسته که
از A یا B درست باشه، نه هر دو.
قدم ۲ — فصل استثنایی (exclusive or):
دقیقاً یکی
نمونه
"The coin landed either heads or tails."
اینجا نمی‌شه سکه هم‌زمان هم شیر بیفته هم خط — دقیقاً یکی از این دو ممکنه اتفاق بیفته. این نشونه‌ی یک
است.
exclusive or
A
B
A or B (exclusive)
T
T
F
T
F
T
F
T
T
F
F
F
تنها تفاوتش با نوع شمولی، ردیف اوله: وقتی هر دو درستن، فصل استثنایی
می‌شه، ولی فصل شمولی
می‌مونه.
غلط
درست
خود کلمه‌ی «or» فرقی نمی‌کنه؛ باید به
نگاه کنی. اگه دو حالت می‌تونن هم‌زمان با هم درست باشن (مثل دو تعریف هم‌ارز از یک شکل هندسی)، شمولیه. اگه دو حالت به‌طور طبیعی نمی‌تونن هم‌زمان اتفاق بیفتن (مثل شیر/خط سکه، یا زنده/مرده بودن)، استثناییه.
قدم ۳ — چطور تشخیص بدیم کدوم نوعه؟
واقعیت پشت جمله
از همون قانون فصل شمولی پیروی می‌کنه: کل زنجیره فقط وقتی غلطه که
حلقه‌ها غلط باشن. کافیه یکی درست باشه تا کل زنجیره درست بشه.
قدم ۴ — فصل زنجیره‌ای: «A or B or C or D or E».
همه‌ی

## Dقوانین و اصول مهم

Section ID: `C9E25F30-7949-49F1-869F-99637E7CCA13`

Import key: `logic/ch03-disjunction.html#section-03`

Topic ID: `0F228A63-7FE8-E532-42D8-EB7D48B2A42C`

Source: [logic/ch03-disjunction.html](../../../database-sources/logic/0F2CA150-41C3-0AEE-548B-844AE19755F9.html) — ID `0F2CA150-41C3-0AEE-548B-844AE19755F9`

قوانین و اصول مهم
D
پیش‌فرض در بیشتر سؤالات منطق، فصل
است — مگر زمینه‌ی جمله صراحتاً یا ضمناً بگه دو حالت نمی‌تونن هم‌زمان اتفاق بیفتن.
شمولی
فصل شمولی فقط در یک حالت غلطه: هر دو طرف غلط باشن.
فصل استثنایی وقتی غلطه که هر دو طرف یک ارزش یکسان داشته باشن (هر دو درست یا هر دو غلط).
فصل زنجیره‌ای («A or B or C…») هم مثل نوع شمولی رفتار می‌کنه — کافیه یکی درست باشه.

## Eروش حل

Section ID: `27A9932C-0BE8-1E9B-EE86-EA9BD5F698CD`

Import key: `logic/ch03-disjunction.html#section-04`

Topic ID: `0F228A63-7FE8-E532-42D8-EB7D48B2A42C`

Source: [logic/ch03-disjunction.html](../../../database-sources/logic/0F2CA150-41C3-0AEE-548B-844AE19755F9.html) — ID `0F2CA150-41C3-0AEE-548B-844AE19755F9`

روش حل
E
دیسجانکت‌ها (disjuncts) رو پیدا کن — گزاره‌های ساده‌ای که با «or» وصل شدن.
از روی زمینه‌ی جمله (نه فقط کلمه‌ی «or») تشخیص بده شمولیه یا استثنایی.
اگه شمولیه: دنبال حداقل یک حلقه‌ی درست بگرد — همون کافیه.
اگه استثناییه: چک کن که دقیقاً یکی درست و بقیه غلط باشن.
→ جواب: طبق جدول درستیِ مربوط به همون نوع فصل.

## Fمثال آموزشی

Section ID: `C89CD18C-AFEA-FB68-3905-2A4CA05244F9`

Import key: `logic/ch03-disjunction.html#section-05`

Topic ID: `0F228A63-7FE8-E532-42D8-EB7D48B2A42C`

Source: [logic/ch03-disjunction.html](../../../database-sources/logic/0F2CA150-41C3-0AEE-548B-844AE19755F9.html) — ID `0F2CA150-41C3-0AEE-548B-844AE19755F9`

مثال آموزشی
F
Example 1 — برای درک مفهوم
"Sara is at the movies or Sara is at the library." Sara is at the movies (True). Sara is at the library (False). What is the truth value of the whole claim, and which type of "or" is this?
این یک فصل شمولیه (سارا می‌تونه هم‌زمان جای دیگه‌ای هم باشه؛ هیچ تناقضی در بودن هر دو گزاره وجود نداره، حتی اگه اینجا فقط یکی درسته). طبق جدول شمولی، کافیه یکی از دو طرف درست باشه.
پاسخ: درسته.

## Gمثال امتحانی

Section ID: `A9F23524-9DE2-8726-5C48-44A62F30F9AC`

Import key: `logic/ch03-disjunction.html#section-06`

Topic ID: `0F228A63-7FE8-E532-42D8-EB7D48B2A42C`

Source: [logic/ch03-disjunction.html](../../../database-sources/logic/0F2CA150-41C3-0AEE-548B-844AE19755F9.html) — ID `0F2CA150-41C3-0AEE-548B-844AE19755F9`

مثال امتحانی
G
Example 2 — CEnT style
"A student's final grade is either Pass or Fail." If we are told the claim "A student's final grade is either Pass or Fail" is TRUE, and we also learn the student's grade is Pass, what can we conclude about "the student's grade is Fail"?
A) It must also be true, since the whole claim is true.
B) It must be false.
C) It cannot be determined.
D) It is true only if the student also passed a retake.
از کجا شروع کنیم؟
اول تشخیص بده این فصل، شمولیه یا استثنایی. «Pass» و «Fail» دو حالت هستن که از نظر واقعیت نمی‌تونن هم‌زمان درست باشن — پس این یک
است.
exclusive or
چه اطلاعاتی مهمه؟
طبق جدول درستی فصل استثنایی، وقتی یک طرف (Pass) درسته، طرف دیگه (Fail) باید غلط باشه — چون اگه هر دو درست بودن، کل گزاره طبق جدول exclusive غلط می‌شد، در حالی که فرض کردیم کل گزاره درسته.
چی حواس‌پرت‌کنه؟
گزینه‌ی A دقیقاً همون اشتباه رایجیه که فصل شمولی و استثنایی رو قاطی می‌کنه — انگار فکر کرده چون کل گزاره درسته، همه‌ی حلقه‌هاش هم باید درست باشن. گزینه‌ی D هم اطلاعات بی‌ربطی اضافه می‌کنه که در گزاره‌ی اصلی نیومده.
چرا این روش مطمئن‌تره؟
چون اول نوع فصل رو مشخص کردیم (استثنایی)، دیگه لازم نبود حدس بزنیم — مستقیم از جدول درستی درست می‌تونیم نتیجه بگیریم.
🎯 EXAM TIP
وقتی به یک «or» رسیدی، از خودت بپرس: «آیا دو طرف این جمله می‌تونن هم‌زمان با هم درست باشن؟» اگه جواب بله‌ست (یا شکی نداری)، شمولی در نظر بگیر. اگه دو طرف از نظر واقعیت متقابلاً منتفی هستن (مثل شیر/خط، Pass/Fail، زنده/مرده)، استثنایی در نظر بگیر.
⚡ QUICK METHOD
برای فصل شمولی: به‌محض پیدا کردن
حلقه‌ی درست، بلافاصله نتیجه بگیر کل گزاره درسته — نیازی به چک کردن بقیه‌ی حلقه‌ها نیست. این برعکسِ روش «and» است، جایی که دنبال یک حلقه‌ی غلط می‌گشتیم.
یک
⚠️ COMMON MISTAKES
فرض کردن اینکه «or» همیشه به معنی exclusive است (یعنی فقط یکی از دو حالت می‌تونه درست باشه).
اشتباه:
در زبان روزمره، وقتی می‌گیم «چای می‌خوای یا قهوه؟» معمولاً منظورمون اینه که فقط یکی رو انتخاب کن — همین عادت ذهنی باعث می‌شه داوطلب فکر کنه هر «or» یعنی انتخاب انحصاری.
چرا اتفاق می‌افته:
همیشه اول واقعیتِ پشت دو گزاره رو بررسی کن، نه فقط کلمه‌ی «or» رو. اگه سؤال صراحتاً نگفته دو حالت متقابلاً منتفی هستن و هیچ نشونه‌ی واقعی‌ای هم برای این تضاد وجود نداره، فرض رو بذار روی شمولی — که پیش‌فرض استاندارد منطقه.
چطور جلوش رو بگیریم:
🪤 QUESTION TRAP
در فصل زنجیره‌ای (سه یا چند حلقه با «or»)، آزمون گاهی می‌پرسه «کل گزاره کِی غلطه؟» به‌جای «کِی درسته؟». خیلی‌ها هنوز عادت ذهنیِ فصل رو دارن (دنبال یک درست بگردن) و جواب رو اشتباه می‌دن. یادت باشه: فصل شمولی
غلط داره — وقتی
حلقه‌ها غلط باشن.
فقط یک حالت
همه‌ی
🧠 MUST REMEMBER
فصل شمولی: درست اگه
درست باشه؛ غلط فقط اگه هر دو غلط باشن. فصل استثنایی: درست اگه
درست باشه. پیش‌فرض منطق گزاره‌ای، شمولیه — مگر واقعیت پشت جمله چیز دیگه‌ای بگه.
حداقل یکی
دقیقاً یکی

## 📝تمرین

Section ID: `ED8A5416-1728-98AD-A312-9B058DC91FEE`

Import key: `logic/ch03-disjunction.html#section-07`

Topic ID: `0F228A63-7FE8-E532-42D8-EB7D48B2A42C`

Source: [logic/ch03-disjunction.html](../../../database-sources/logic/0F2CA150-41C3-0AEE-548B-844AE19755F9.html) — ID `0F2CA150-41C3-0AEE-548B-844AE19755F9`

تمرین
📝
آسان
"You can pay by credit card or by bank transfer." A customer pays by credit card AND by bank transfer (splitting the amount). Assuming this is an inclusive or, is the original claim true or false?
A) True
B) False
C) Cannot be determined
D) The claim becomes meaningless
نمایش پاسخ و توضیح
در فصل شمولی، وقتی هر دو طرف درست باشن (هم پرداخت با کارت، هم با انتقال بانکی)، طبق جدول درستی، کل گزاره همچنان True است. این دقیقاً ردیف اول جدول inclusive or است.
پاسخ درست: A.
متوسط
"The number is either even or odd." We are told this exclusive-or claim is TRUE, and that "the number is even" is FALSE. What must be true about "the number is odd"?
A) It must also be false.
B) It must be true.
C) It cannot be determined from this information.
D) It depends on whether the number is positive.
نمایش پاسخ و توضیح
طبق جدول درستی فصل استثنایی، تنها ردیف‌هایی که کل گزاره True می‌دن اونایی هستن که دقیقاً یکی از دو طرف درسته. چون "even" را False داریم و گزاره کلاً True است، طبق جدول تنها گزینه‌ی سازگار اینه که "odd" باید True باشه.
پاسخ درست: B.
سخت
"The delivery will arrive on Monday, Tuesday, or Wednesday." This is an inclusive-style chain disjunction (the delivery could theoretically satisfy more than one description in a stretched sense, but here it refers to a single arrival day). We are told the whole claim is FALSE. What can we conclude?
A) The delivery arrived on at least one of the three days.
B) The delivery did not arrive on Monday, Tuesday, or Wednesday.
C) The delivery arrived on exactly one of the three days.
D) The claim cannot be false under any circumstances.
نمایش پاسخ و توضیح
برای اینکه یک فصل زنجیره‌ای غلط باشه، طبق قانون قدم ۴،
حلقه‌ها باید غلط باشن — یعنی نه دوشنبه، نه سه‌شنبه، نه چهارشنبه. گزینه‌ی A دقیقاً برعکس تعریف «غلط بودن فصل» است. گزینه‌ی C به فصل استثنایی مربوطه، نه به این مورد که یک روز تحویل واحده. این دقیقاً همون دام «Question Trap» بالاست: پرسیدن از حالت غلط، به‌جای حالت درست.
پاسخ درست: B.
همه‌ی

## 🚀مرور سریع — فصل ۳

Section ID: `62D9F7B9-8021-0080-A420-E9A3E272AA2D`

Import key: `logic/ch03-disjunction.html#section-08`

Topic ID: `0F228A63-7FE8-E532-42D8-EB7D48B2A42C`

Source: [logic/ch03-disjunction.html](../../../database-sources/logic/0F2CA150-41C3-0AEE-548B-844AE19755F9.html) — ID `0F2CA150-41C3-0AEE-548B-844AE19755F9`

مرور سریع — فصل ۳
🚀
مفاهیم اصلی
فصل شمولی: درست اگه حداقل یکی درست باشه.
فصل استثنایی: درست فقط اگه دقیقاً یکی درست باشه.
پیش‌فرض منطق گزاره‌ای، شمولیه.
روش
از روی واقعیت پشت جمله، نوع فصل رو تشخیص بده.
شمولی: دنبال یک حلقه‌ی درست بگرد.
استثنایی: چک کن دقیقاً یکی درست باشه.
اشتباهات رایج
فرض کردن هر «or» به‌عنوان استثنایی، مثل زبان روزمره.
قاطی کردن قانون «and» و «or» برای پیدا کردن حلقه‌ی تعیین‌کننده.
دام‌های تستی
پرسیدن از حالت «غلط بودن» فصل زنجیره‌ای.
سناریوهای واقعی که نوع or رو مبهم نشون می‌دن.
