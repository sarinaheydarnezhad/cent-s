# فصل ۵: نقیض و تضاد — «not-A» (Negation, Contradictories & Contraries)

Original chapter ID: `AD2CFB7C-5C1E-8AB5-D07F-57B46C072F00`

Original chapter import key: `logic/ch05-negation.html#chapter`

## فصل ۵: نقیض و تضاد — «not-A» (Negation, Contradictories & Contraries)

Section ID: `E1FE12AE-536D-6D48-A27A-FE66E747F59E`

Import key: `logic/ch05-negation.html#intro`

Topic ID: `9192A9BD-E54A-0DC4-4780-B1ECB79BDB38`

Source: [logic/ch05-negation.html](../../../database-sources/logic/1174E3F6-071A-01D4-C9A8-280BEAB9E5B8.html) — ID `1174E3F6-071A-01D4-C9A8-280BEAB9E5B8`

CENT LOGIC — PART A · CHAPTER 5 / 13
فصل ۵: نقیض و تضاد — «not-A» (Negation, Contradictories & Contraries)
تا اینجا با «not-A» به‌عنوان یک نقیض ساده آشنا شدی. این فصل نشونت می‌ده رایج‌ترین اشتباهِ ساختن نقیض چیه — و چرا انتخاب یک کلمه‌ی «مخالف» تقریباً همیشه اشتباهه.

## Bاین مبحث چیست؟

Section ID: `B08DE09B-B67D-8EBA-FC32-E8140766C83F`

Import key: `logic/ch05-negation.html#section-01`

Topic ID: `9192A9BD-E54A-0DC4-4780-B1ECB79BDB38`

Source: [logic/ch05-negation.html](../../../database-sources/logic/1174E3F6-071A-01D4-C9A8-280BEAB9E5B8.html) — ID `1174E3F6-071A-01D4-C9A8-280BEAB9E5B8`

این مبحث چیست؟
B
هدف این فصل اینه که فرق بین
یک گزاره و یک گزاره‌ی «متضاد» یا «مخالف»
رو یاد بگیری. این دو تا شبیه هم به نظر می‌رسن ولی از نظر منطقی خیلی متفاوتن، و آزمون دقیقاً از همین شباهت ظاهری برای طراحی گزینه‌های اشتباه استفاده می‌کنه.
نقیض واقعی (contradictory)
(contrary)

## Cمفهوم اصلی

Section ID: `AA89F469-69A0-7190-60F6-81B0DD8352A9`

Import key: `logic/ch05-negation.html#section-02`

Topic ID: `9192A9BD-E54A-0DC4-4780-B1ECB79BDB38`

Source: [logic/ch05-negation.html](../../../database-sources/logic/1174E3F6-071A-01D4-C9A8-280BEAB9E5B8.html) — ID `1174E3F6-071A-01D4-C9A8-280BEAB9E5B8`

مفهوم اصلی
C
قدم ۱ — نقیض (contradictory) گزاره‌ایه که همیشه ارزش درستیِ مخالفِ A رو داره.
نمونه
A = "John is at the movies"
not-A = "John is
at the movies."
not
A
not-A
T
F
F
T
قدم ۲ — رایج‌ترین اشتباه: انتخاب یک کلمه‌ی «مخالف» به‌جای نقیض واقعی.
نمونه
A = "The ball is black."
❌ not-A = "The ball is white."
(اشتباه — این نقیض نیست)
✅ not-A = "The ball is
black."
not
(درست — این نقیضه)
چرا «white» اشتباهه؟ چون توپ می‌تونه قرمز، آبی یا سبز هم باشه — یعنی هم «black» و هم «white» می‌تونن هم‌زمان
باشن (وقتی توپ قرمزه). ولی نقیض واقعی هیچ‌وقت نمی‌ذاره A و not-A هم‌زمان هر دو غلط باشن.
هر دو غلط
دو گزاره متضاد
هستن اگه
، ولی
. «black» و «white» دقیقاً همین رابطه رو دارن.
قدم ۳ — تعریف رسمی تضاد (contrary):
(contrary)
نتونن هم‌زمان هر دو درست باشن
بتونن هم‌زمان هر دو غلط باشن
دو گزاره نقیض هم هستن اگه
— یعنی دقیقاً یکی‌شون همیشه درسته و اون یکی همیشه غلط. تنها راه تضمینیِ ساختِ نقیضِ درست، گذاشتنِ «not» درست پشت خودِ کل گزاره‌ست، نه جایگزین کردنش با یک کلمه‌ی هم‌معنیِ مخالف.
قدم ۴ — تعریف رسمی نقیض (contradictory):
هیچ‌وقت نتونن هم‌زمان هر دو درست باشن، و هیچ‌وقت نتونن هم‌زمان هر دو غلط باشن
این یک نوع خاص از عطف
است که همیشه — بدون استثنا — غلطه.
قدم ۵ — تناقض (contradiction) یعنی «A and not-A».
(conjunction)
A
not-A
A and not-A
T
F
F
F
T
F
مقایسه
"John is at the movies
John is not at the movies." →
and
Contradiction (always False)
"John is at the movies
John is at the store." →
and
Not necessarily a contradiction — depends on the actual truth values.
گزاره‌ی دوم چون «at the store» نقیضِ «at the movies» نیست (می‌تونه هر دو غلط باشن — یعنی جایی سوم باشه)، صرفاً یک عطف عادیه، نه یک تناقض تضمینی.

## Dقوانین و اصول مهم

Section ID: `B458E15D-393C-3B2B-FBA4-2DEF83AA7067`

Import key: `logic/ch05-negation.html#section-03`

Topic ID: `9192A9BD-E54A-0DC4-4780-B1ECB79BDB38`

Source: [logic/ch05-negation.html](../../../database-sources/logic/1174E3F6-071A-01D4-C9A8-280BEAB9E5B8.html) — ID `1174E3F6-071A-01D4-C9A8-280BEAB9E5B8`

قوانین و اصول مهم
D
دقیقاً یکی درست، دقیقاً یکی غلط — همیشه، بدون استثنا.
Contradictory (نقیض):
نمی‌تونن هر دو درست باشن، ولی
هر دو غلط باشن.
Contrary (تضاد):
می‌تونن
ساختن نقیض همیشه یعنی «not» گذاشتن جلوی کل گزاره — نه جایگزینیِ یک کلمه با یک کلمه‌ی «مخالف».
«A and not-A» (تناقض) همیشه غلطه، فارغ از اینکه A چی باشه.

## Eروش حل

Section ID: `74668165-A3BB-4A5C-2AF5-C7527A85B154`

Import key: `logic/ch05-negation.html#section-04`

Topic ID: `9192A9BD-E54A-0DC4-4780-B1ECB79BDB38`

Source: [logic/ch05-negation.html](../../../database-sources/logic/1174E3F6-071A-01D4-C9A8-280BEAB9E5B8.html) — ID `1174E3F6-071A-01D4-C9A8-280BEAB9E5B8`

روش حل
E
برای ساختن نقیض یک گزاره، «not» رو مستقیماً به کل گزاره اضافه کن (نه اینکه دنبال یک کلمه‌ی مخالف بگردی).
برای چک کردن اینکه دو گزاره واقعاً نقیض هم هستن یا فقط متضاد: از خودت بپرس «آیا می‌تونن هم‌زمان هر دو غلط باشن؟» اگه بله، فقط متضادن، نقیض هم نیستن.
اگه سؤال گزاره‌ای به‌فرم «A and not-A» داد، بدون محاسبه بگو غلطه — این یک تناقض تضمینیه.
→ جواب: طبق جدول‌های بالا.

## Fمثال آموزشی

Section ID: `EDAAA27B-B9D4-F18E-7D08-A2A20BAEE7EE`

Import key: `logic/ch05-negation.html#section-05`

Topic ID: `9192A9BD-E54A-0DC4-4780-B1ECB79BDB38`

Source: [logic/ch05-negation.html](../../../database-sources/logic/1174E3F6-071A-01D4-C9A8-280BEAB9E5B8.html) — ID `1174E3F6-071A-01D4-C9A8-280BEAB9E5B8`

مثال آموزشی
F
Example 1 — برای درک مفهوم
A = "The light is on." Which of the following is the correct contradictory of A: "The light is off" or "The light is not on"?
در این مورد خاص، «off» و «not on» تقریباً هم‌ارزن چون چراغ فقط دو حالت داره (روشن/خاموش). ولی روش درست و همیشه-قابل‌اعتماد اینه که مستقیماً «not» بذاری، نه اینکه به یک کلمه‌ی مخالف اعتماد کنی — چون در خیلی موارد دیگه (مثل مثال توپ سیاه/سفید)، این دو یکی نیستن.
پاسخ: "The light is not on".

## Gمثال امتحانی

Section ID: `0BAFE253-1EFC-AC68-125B-239FF09576F1`

Import key: `logic/ch05-negation.html#section-06`

Topic ID: `9192A9BD-E54A-0DC4-4780-B1ECB79BDB38`

Source: [logic/ch05-negation.html](../../../database-sources/logic/1174E3F6-071A-01D4-C9A8-280BEAB9E5B8.html) — ID `1174E3F6-071A-01D4-C9A8-280BEAB9E5B8`

مثال امتحانی
G
Example 2 — CEnT style
A = "The temperature today is hot." Which of the following is the correct contradictory of A?
A) "The temperature today is cold."
B) "The temperature today is not hot."
C) "The temperature today is mild."
D) "The temperature today is freezing."
از کجا شروع کنیم؟
یادت باشه نقیض همیشه یعنی «not» + کل گزاره، نه یک کلمه‌ی مخالف.
چه اطلاعاتی مهمه؟
«hot» و «cold» می‌تونن هم‌زمان هر دو غلط باشن — مثلاً وقتی هوا «mild» یا «warm» است. پس این‌ها رابطه‌ی contrary دارن، نه contradictory.
چی حواس‌پرت‌کنه؟
گزینه‌های A، C و D همه کلمات «مخالف» یا حالت‌های دیگه‌ی دما هستن — همه‌شون طبق قدم ۲ همون دام رایجی هستن که این فصل دقیقاً درباره‌شه. فقط گزینه‌ی B تضمین می‌کنه که همیشه دقیقاً یکی از دو گزاره درست باشه.
چرا این روش مطمئن‌تره؟
چون تعریف رسمی نقیض («هیچ‌وقت هر دو غلط نباشن») رو مستقیماً روی گزینه‌ها تست کردیم، به‌جای اینکه به شهود زبانی اعتماد کنیم.
🎯 EXAM TIP
هر وقت گزینه‌ای دیدی که یک کلمه رو با یک کلمه‌ی «مخالفِ» ظاهری جایگزین کرده (hot/cold, black/white, up/down, always/never)، مشکوک شو. تست سریع: از خودت بپرس «آیا می‌تونن هم‌زمان هر دو غلط باشن؟» اگه جواب بله‌ست، اون گزینه نقیض نیست، فقط یک تضاده.
⚡ QUICK METHOD
اگه سؤال مستقیماً گزاره‌ای به فرم «A and not-A» بهت داد و ازت خواست ارزش درستیش رو بگی، نیازی به هیچ محاسبه‌ای نیست — جواب همیشه
است، چون این یک تناقض تضمینیه.
False
⚠️ COMMON MISTAKES
ساختن نقیض یک گزاره با جایگزین کردن یک کلمه با کلمه‌ی هم‌معنیِ مخالفش.
اشتباه:
در زبان روزمره، وقتی می‌خوایم بگیم چیزی «نقیض» یه چیز دیگه‌ست، معمولاً به یاد اولین کلمه‌ی مخالفی که به ذهنمون می‌رسه می‌افتیم (سیاه→سفید، گرم→سرد)، بدون اینکه چک کنیم آیا حالت سومی هم وجود داره یا نه.
چرا اتفاق می‌افته:
همیشه اول تست «آیا می‌تونن هر دو هم‌زمان غلط باشن؟» رو انجام بده. اگه بله، اون گزینه فقط یک contrary است، نه contradictory — و برای سؤالات نقیض باید ردش کنی.
چطور جلوش رو بگیریم:
🧠 MUST REMEMBER
دقیقاً یکی درست، یکی غلط — همیشه.
نمی‌تونن هر دو درست باشن، ولی می‌تونن هر دو غلط باشن. نقیض همیشه = «not» + کل گزاره. «A and not-A» همیشه غلطه.
Contradictory:
Contrary:

## 📝تمرین

Section ID: `B5194EDD-F2B2-0CBA-6DFD-18CF106ADC0B`

Import key: `logic/ch05-negation.html#section-07`

Topic ID: `9192A9BD-E54A-0DC4-4780-B1ECB79BDB38`

Source: [logic/ch05-negation.html](../../../database-sources/logic/1174E3F6-071A-01D4-C9A8-280BEAB9E5B8.html) — ID `1174E3F6-071A-01D4-C9A8-280BEAB9E5B8`

تمرین
📝
آسان
A = "The door is open." What is the correct contradictory of A?
A) "The door is broken."
B) "The door is not open."
C) "The window is open."
D) "The door will open soon."
نمایش پاسخ و توضیح
نقیض همیشه یعنی «not» + کل گزاره‌ی اصلی. گزینه‌های دیگه یا موضوع رو کلاً عوض کردن (پنجره به‌جای در) یا اطلاعات نامرتبط اضافه کردن (شکسته بودن، آینده).
پاسخ درست: B.
متوسط
A = "The company's profit increased this quarter." Which statement is a CONTRARY of A, but NOT its contradictory?
A) "The company's profit decreased this quarter."
B) "The company's profit did not increase this quarter."
C) "It is not true that the company's profit increased this quarter."
D) "The company's profit failed to increase this quarter."
نمایش پاسخ و توضیح
«decreased» و «increased» نمی‌تونن هم‌زمان هر دو درست باشن، ولی می‌تونن هر دو غلط باشن — مثلاً وقتی سود
مونده (نه افزایش، نه کاهش). این دقیقاً تعریف contrary است. گزینه‌های B، C و D همه شکل‌های مختلف همون «not increased» هستن که نقیض واقعیِ A محسوب می‌شن، چون هیچ حالت سومی رو باقی نمی‌ذارن.
پاسخ درست: A.
بدون تغییر
سخت
Consider: "The suspect was in the building at 9 PM, and the suspect was not in the building at 9 PM." Without knowing anything about the actual case, what is the truth value of this whole claim?
A) True, because one of the two parts must be true.
B) False, with certainty — no further information is needed.
C) Cannot be determined without more evidence.
D) True only if the suspect has an alibi.
نمایش پاسخ و توضیح
این گزاره دقیقاً به فرم «A and not-A» است — یک تناقض. طبق قدم ۵ و Quick Method این فصل، چنین گزاره‌ای
غلطه، فارغ از هر شواهد یا اطلاعات بیرونی. گزینه‌ی C دقیقاً همون دامیه که این فصل هشدارش رو می‌ده: این نوع سؤالات هیچ‌وقت به «اطلاعات بیشتر» نیاز ندارن، چون ساختار منطقیشون به‌تنهایی جواب رو مشخص می‌کنه.
پاسخ درست: B.
همیشه

## 🚀مرور سریع — فصل ۵

Section ID: `4ED526CD-E75B-9785-1C5B-EBE271CED238`

Import key: `logic/ch05-negation.html#section-08`

Topic ID: `9192A9BD-E54A-0DC4-4780-B1ECB79BDB38`

Source: [logic/ch05-negation.html](../../../database-sources/logic/1174E3F6-071A-01D4-C9A8-280BEAB9E5B8.html) — ID `1174E3F6-071A-01D4-C9A8-280BEAB9E5B8`

مرور سریع — فصل ۵
🚀
مفاهیم اصلی
Contradictory: دقیقاً یکی درست، یکی غلط — همیشه.
Contrary: نمی‌تونن هر دو درست باشن، ولی می‌تونن هر دو غلط باشن.
«A and not-A» همیشه غلطه (تناقض).
روش
نقیض = «not» + کل گزاره، نه یک کلمه‌ی مخالف.
تست: «آیا می‌تونن هر دو هم‌زمان غلط باشن؟»
اشتباهات رایج
جایگزین کردن با کلمه‌ی مخالفِ ظاهری (hot/cold, black/white).
نادیده گرفتن حالت سوم (mild, gray, no change).
دام‌های تستی
گزینه‌هایی که یک contrary رو به‌جای contradictory جا می‌زنن.
سؤالاتی که به‌نظر نیاز به «اطلاعات بیشتر» دارن ولی صرفاً یک تناقض ساختاری‌ان.
