# فصل ۱۷: نتیجه‌گیری و ارزیابیِ ادعاها — Drawing Conclusions & Evaluating Claims

Original chapter ID: `FE7415D5-DA50-CCAA-D111-283A46248634`

Original chapter import key: `logic/ch17-evaluating.html#chapter`

## فصل ۱۷: نتیجه‌گیری و ارزیابیِ ادعاها — Drawing Conclusions & Evaluating Claims

Section ID: `2C931A01-29AD-F435-2F83-228D46A7ED5A`

Import key: `logic/ch17-evaluating.html#intro`

Topic ID: `14C70AA2-7785-D3DF-F4CB-ACFE16DB2213`

Source: [logic/ch17-evaluating.html](../../../database-sources/logic/1F9B5357-1054-D852-3665-EAC1BF041AA5.html) — ID `1F9B5357-1054-D852-3665-EAC1BF041AA5`

CENT LOGIC — PART B · CHAPTER 17 / 19
فصل ۱۷: نتیجه‌گیری و ارزیابیِ ادعاها — Drawing Conclusions & Evaluating Claims
در این فصل یک ادعای کلامی («بیشترِ کارمندها راضی‌ان»، «فروش در همه‌ی مناطق رشد کرد») رو در برابرِ داده‌های واقعی می‌ذاریم. هدف اینه که دقیقاً مشخص کنی این ادعا با داده‌ها
،
، یا اصلاً از این داده‌ها
.
تأیید می‌شه
رد می‌شه
قابلِ تعیین نیست

## Bاین مبحث چیست؟

Section ID: `3F75B69F-DBEB-6879-418F-924681910D06`

Import key: `logic/ch17-evaluating.html#section-01`

Topic ID: `14C70AA2-7785-D3DF-F4CB-ACFE16DB2213`

Source: [logic/ch17-evaluating.html](../../../database-sources/logic/1F9B5357-1054-D852-3665-EAC1BF041AA5.html) — ID `1F9B5357-1054-D852-3665-EAC1BF041AA5`

این مبحث چیست؟
B
این نوع سؤالات دو تکه دارن: یک ادعای کلامی و یک مجموعه داده. کارِ تو اینه که ادعا رو دقیق ترجمه کنی به یک شرطِ قابلِ محاسبه، و بعد فقط همون محاسبه‌ی لازم رو انجام بدی — نه بیشتر، نه کمتر.

## Cمفهوم اصلی

Section ID: `733D8213-9E2B-E080-12CB-835FC666A4F1`

Import key: `logic/ch17-evaluating.html#section-02`

Topic ID: `14C70AA2-7785-D3DF-F4CB-ACFE16DB2213`

Source: [logic/ch17-evaluating.html](../../../database-sources/logic/1F9B5357-1054-D852-3665-EAC1BF041AA5.html) — ID `1F9B5357-1054-D852-3665-EAC1BF041AA5`

مفهوم اصلی
C
ادعاهای درصدی و کلی همیشه نسبت به یک مبنای مشخص سنجیده می‌شن.
قدم ۱ — قبل از هر محاسبه‌ای، مشخص کن «کل» چیه.
نمونه ۱ — ادعای «بیشتر (most)»
Claim: "Most of the company's employees are satisfied with the work environment."
Data (survey of 200 employees): Very Satisfied 60, Satisfied 70, Neutral 40, Dissatisfied 20, Very Dissatisfied 10.
مجموعِ راضی‌ها = ۶۰+۷۰=۱۳۰. درصد = ۱۳۰/۲۰۰ × ۱۰۰٪ = ۶۵٪. طبق تعریفِ استاندارد، «most» یعنی بیش از ۵۰٪. چون ۶۵٪ > ۵۰٪،
.
ادعا توسط داده‌ها پشتیبانی می‌شه (True)
قدم ۲ — ادعاهای «همه (all)» فقط با یک استثنا رد می‌شن — دقیقاً مثلِ فصل ۱۰.
نمونه ۲ — ادعای «همه (all)»
Claim: "Sales of our new product have grown in all regions."
Data (% change vs previous quarter): North +10%, South +5%, East −2%, West +8%.
منطقه‌ی شرق (East) کاهش (−۲٪) داشته. چون ادعا از «همه‌ی مناطق» صحبت کرده، همینِ یک استثنا کافیه:
— حتی اگه سه منطقه‌ی دیگه رشدِ خوبی داشته باشن.
ادعا غلطه (False)
این مهم‌ترین و ظریف‌ترین نکته‌ی این فصله. یک گزینه فقط وقتی «must be true» است که داده‌های داده‌شده، بدون هیچ فرضِ اضافه، اون رو تضمین کنن.
قدم ۳ — «باید حتماً درست باشه (must be true)» با «به‌نظر منطقی میاد» فرق داره.
نمونه
Data: 120 applicants studied Biology, 90 studied Chemistry, 70 studied Physics (out of an unknown total, with unknown overlaps).
آیا می‌تونیم بگیم «حداقل ۲۰ نفر هم زیست هم شیمی خوندن»؟
— چون هیچ اطلاعاتی درباره‌ی هم‌پوشانیِ این دو گروه نداریم؛ ممکنه هیچ‌کس هر دو رو هم‌زمان نخونده باشه. اما آیا می‌تونیم بگیم «تعداد کسانی که زیست خوندن از تعداد کسانی که شیمی خوندن بیشتره»؟
— چون ۱۲۰ > ۹۰، این مستقیماً از خودِ اعداد نتیجه می‌شه، بدون هیچ فرضِ اضافه‌ای.
نه
بله

## Dقوانین و اصول مهم

Section ID: `DE83274C-C7AC-448E-87B4-1EE696A97283`

Import key: `logic/ch17-evaluating.html#section-03`

Topic ID: `14C70AA2-7785-D3DF-F4CB-ACFE16DB2213`

Source: [logic/ch17-evaluating.html](../../../database-sources/logic/1F9B5357-1054-D852-3665-EAC1BF041AA5.html) — ID `1F9B5357-1054-D852-3665-EAC1BF041AA5`

قوانین و اصول مهم
D
قبل از محاسبه، «کل» یا مبنای ادعا رو دقیق مشخص کن.
«Most» یعنی بیش از ۵۰٪ از کل.
ادعای «All» با یک استثنای تنها، کاملاً رد می‌شه — نیازی به بررسیِ همه‌ی موارد نیست.
«Must be true» فقط شاملِ چیزهاییه که مستقیماً و بدون فرضِ اضافه از داده‌ها نتیجه می‌شن؛ هم‌پوشانی/تقاطعِ گروه‌ها هرگز فرض نمی‌شه مگر صریحاً داده شده باشه.

## Eروش حل

Section ID: `47AD9AD9-EAAA-5A9F-141D-D656445A3D66`

Import key: `logic/ch17-evaluating.html#section-04`

Topic ID: `14C70AA2-7785-D3DF-F4CB-ACFE16DB2213`

Source: [logic/ch17-evaluating.html](../../../database-sources/logic/1F9B5357-1054-D852-3665-EAC1BF041AA5.html) — ID `1F9B5357-1054-D852-3665-EAC1BF041AA5`

روش حل
E
ادعا رو دقیق بازنویسی کن: آیا یک ادعای «همه»، «بیشتر»، یا یک مقایسه‌ی مستقیمه؟
مشخص کن دقیقاً چه داده‌ای برای تستِ این ادعا لازمه.
فقط همون محاسبه‌ی لازم رو انجام بده.
برای ادعاهای «همه»، فعالانه دنبالِ یک استثنا بگرد.
نتیجه رو با آستانه یا منطقِ ادعا مقایسه کن.
→ جواب: تأیید (True) / رد (False) / غیرقابلِ تعیین (Cannot be determined).

## Fمثال آموزشی

Section ID: `9CBD6CFE-7974-15DA-D281-814913F6D67E`

Import key: `logic/ch17-evaluating.html#section-05`

Topic ID: `14C70AA2-7785-D3DF-F4CB-ACFE16DB2213`

Source: [logic/ch17-evaluating.html](../../../database-sources/logic/1F9B5357-1054-D852-3665-EAC1BF041AA5.html) — ID `1F9B5357-1054-D852-3665-EAC1BF041AA5`

مثال آموزشی
F
Example 1 — برای درک مفهوم
Claim: "The majority of survey respondents prefer working from home." Data: 45 out of 100 respondents said they prefer working from home. Is the claim supported?
۴۵/۱۰۰ = ۴۵٪، که کمتر از ۵۰٪ است. «majority» به‌معنیِ بیش از نیمی‌ست، پس این داده‌ها ادعا رو تأیید نمی‌کنن.
پاسخ: نه، ادعا رد می‌شه.

## Gمثال امتحانی

Section ID: `9AA01F03-92DA-79B6-268F-9F5B53DC233E`

Import key: `logic/ch17-evaluating.html#section-06`

Topic ID: `14C70AA2-7785-D3DF-F4CB-ACFE16DB2213`

Source: [logic/ch17-evaluating.html](../../../database-sources/logic/1F9B5357-1054-D852-3665-EAC1BF041AA5.html) — ID `1F9B5357-1054-D852-3665-EAC1BF041AA5`

مثال امتحانی
G
Example 2 — CEnT style
120 applicants studied Biology, 90 studied Chemistry, 70 studied Physics.
A survey of medical applicants found that:
Which statement MUST be true?
A) At least 20 applicants studied both Biology and Chemistry.
B) Exactly 280 applicants were surveyed.
C) More applicants studied Biology than Chemistry.
D) No applicant studied all three subjects.
E) Every Physics student also studied Biology.
از کجا شروع کنیم؟
یادت باشه هیچ اطلاعاتی درباره‌ی هم‌پوشانیِ این سه گروه یا تعدادِ کلِ داوطلبان نداریم — فقط سه عددِ مجزا داریم.
چه اطلاعاتی مهمه؟
گزینه‌ی C یک مقایسه‌ی مستقیمِ بینِ دو عددِ داده‌شده‌ست: ۱۲۰ > ۹۰. این بدونِ هیچ فرضِ اضافه‌ای، مستقیماً از خودِ داده‌ها نتیجه می‌شه.
چی حواس‌پرت‌کنه؟
گزینه‌ی A فرضِ هم‌پوشانی می‌کنه که هیچ‌جا داده نشده. گزینه‌ی B فرض می‌کنه سه گروه کاملاً مجزا و بدونِ هم‌پوشانی‌ان و هیچ داوطلبِ دیگه‌ای هم نیست — که هر دو فرضِ اضافه‌ست. گزینه‌های D و E هم ادعاهایی درباره‌ی هم‌پوشانی می‌کنن که هیچ داده‌ای براشون نداریم — ممکنه درست باشن، ممکنه غلط، ولی «must be true» نیستن.
چرا این روش مطمئن‌تره؟
چون به‌جای پذیرفتنِ گزینه‌های «منطقاً به‌نظر درست»، فقط گزینه‌ای رو انتخاب کردیم که مستقیماً و بدونِ هیچ فرضِ اضافه‌ای از اعدادِ داده‌شده نتیجه می‌شه.
🎯 EXAM TIP
برای سؤالاتِ «must be true»، هر گزینه رو با این سؤال تست کن: «آیا این گزینه، بدون هیچ فرضِ اضافه‌ای، مستقیماً از دقیقاً همین اعدادی که دادن نتیجه می‌شه؟» اگه برای درست بودنش به یک فرضِ نانوشته نیاز داری (مثلِ هم‌پوشانی یا نبودِ افرادِ دیگه)، اون گزینه رد می‌شه.
⚡ QUICK METHOD
برای ادعاهای «all/every»، به‌جای بررسیِ همه‌ی موارد، مستقیم دنبالِ یک استثنا بگرد. همین که یکی پیدا کردی، بدونِ محاسبه‌ی بیشتر می‌تونی نتیجه بگیری ادعا غلطه.
⚠️ COMMON MISTAKES
فرض کردنِ هم‌پوشانی یا رابطه‌ی بینِ دو گروهِ جدا، وقتی فقط تعدادِ هرکدوم به‌طور مجزا داده شده.
اشتباه:
وقتی چند عددِ مرتبط با هم می‌بینیم (مثلِ تعدادِ دانش‌آموزانِ هر درس)، ذهن به‌طور طبیعی سعی می‌کنه بینشون رابطه بسازه (مثلاً جمع بزنه یا هم‌پوشانی فرض کنه)، حتی وقتی داده‌ها همچین اطلاعاتی نمی‌دن.
چرا اتفاق می‌افته:
همیشه از خودت بپرس: «آیا این عدد یا رابطه مستقیماً در متن سؤال گفته شده، یا من دارم فرضش می‌کنم؟» اگه فرضشه، اون گزینه نمی‌تونه «must be true» باشه.
چطور جلوش رو بگیریم:
🪤 QUESTION TRAP
سؤال معمولاً بینِ گزینه‌ها، ادعایی می‌ذاره که در دنیای واقعی «به‌نظر منطقی» یا «معمولاً درسته» میاد (مثلِ «همه‌ی داوطلبانِ فیزیک، زیست هم خوندن») ولی از خودِ داده‌های داده‌شده تضمین نمی‌شه. همیشه بینِ «ممکنه درست باشه» و «حتماً درسته» فرق بذار.
🧠 MUST REMEMBER
Most = بیش از ۵۰٪. All فقط با یک استثنا رد می‌شه. Must be true = فقط چیزی که بدونِ فرضِ اضافه از داده‌ها نتیجه می‌شه — هم‌پوشانیِ گروه‌ها هرگز فرض نمی‌شه مگر صریحاً داده شده باشه.

## 📝تمرین

Section ID: `2443E063-633C-DFF9-8932-3926E8E7F7B7`

Import key: `logic/ch17-evaluating.html#section-07`

Topic ID: `14C70AA2-7785-D3DF-F4CB-ACFE16DB2213`

Source: [logic/ch17-evaluating.html](../../../database-sources/logic/1F9B5357-1054-D852-3665-EAC1BF041AA5.html) — ID `1F9B5357-1054-D852-3665-EAC1BF041AA5`

تمرین
📝
آسان
Claim: "Most customers rated the service as excellent." Data: 55 out of 100 customers rated it "excellent." Is the claim supported?
A) Yes, since 55% is more than half.
B) No, since 55% is not a large enough majority.
C) Cannot be determined.
D) Yes, but only if the other 45% rated it "poor."
نمایش پاسخ و توضیح
۵۵٪ بیشتر از ۵۰٪ است، پس طبق تعریفِ «most»، ادعا تأیید می‌شه. گزینه‌ی D هم شرطِ اضافه‌ای گذاشته که در ادعا نیومده.
پاسخ درست: A.
متوسط
Claim: "Every department reduced its budget this year." Data: Marketing −5%, Sales −3%, IT +2%, HR −8%. Is the claim supported?
A) Yes, because most departments show a decrease.
B) No, because IT's budget increased.
C) Cannot be determined without more data.
D) Yes, since the average change across departments is still negative.
نمایش پاسخ و توضیح
ادعا از «every department» صحبت کرده — یک ادعای «all». همینِ یک استثنا (IT با +۲٪) کافیه که کل ادعا رد بشه، فارغ از اینکه میانگین یا اکثریت چی نشون بده.
پاسخ درست: B.
سخت
Data: In a survey of 500 people, 150 people own a car and 80 people own a bicycle. Which statement MUST be true?
A) At least 30 people own both a car and a bicycle.
B) More people own a car than own a bicycle.
C) Exactly 270 people own neither a car nor a bicycle.
D) No one owns both a car and a bicycle.
نمایش پاسخ و توضیح
۱۵۰ > ۸۰ مستقیماً و بدونِ هیچ فرضِ اضافه‌ای از خودِ اعداد نتیجه می‌شه. گزینه‌های A و D هر دو درباره‌ی هم‌پوشانیِ این دو گروه فرض می‌کنن — که هیچ‌جا داده نشده؛ چون ۱۵۰+۸۰=۲۳۰ کمتر از کلِ ۵۰۰ نفره، اصلاً هم‌پوشانی
نیست (می‌تونه صفر باشه، یا هر عددی تا ۸۰). گزینه‌ی C هم دقیقاً همون فرضِ «هیچ هم‌پوشانی‌ای نیست» رو داره که تضمین‌شده نیست.
پاسخ درست: B.
اجباری

## 🚀مرور سریع — فصل ۱۷

Section ID: `6994DE2F-346E-ABF0-6D15-8F644CA562B3`

Import key: `logic/ch17-evaluating.html#section-08`

Topic ID: `14C70AA2-7785-D3DF-F4CB-ACFE16DB2213`

Source: [logic/ch17-evaluating.html](../../../database-sources/logic/1F9B5357-1054-D852-3665-EAC1BF041AA5.html) — ID `1F9B5357-1054-D852-3665-EAC1BF041AA5`

مرور سریع — فصل ۱۷
🚀
مفاهیم اصلی
Most = بیش از ۵۰٪.
All فقط با یک استثنا رد می‌شه.
Must be true ≠ به‌نظر منطقی میاد.
روش
اول «کل» رو مشخص کن.
برای «all»، دنبالِ یک استثنا بگرد.
برای «must be true»، هر گزینه رو با اعدادِ خام تست کن.
اشتباهات رایج
فرضِ هم‌پوشانی بینِ گروه‌های مجزا.
دام‌های تستی
ادعاهای «منطقاً محتمل» به‌جای «تضمین‌شده».
