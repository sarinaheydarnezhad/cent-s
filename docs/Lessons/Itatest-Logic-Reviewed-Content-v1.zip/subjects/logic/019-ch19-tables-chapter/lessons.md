# فصل ۱۹: حل مسئله با جدول و معادلات همزمان — Tables & Simultaneous Equations

Original chapter ID: `10628593-DDBE-383E-9C62-BDE18F3BF998`

Original chapter import key: `logic/ch19-tables.html#chapter`

## فصل ۱۹: حل مسئله با جدول و معادلات همزمان — Tables & Simultaneous Equations

Section ID: `7037F3E6-BD1A-2C83-DC4E-CC57155C9BBD`

Import key: `logic/ch19-tables.html#intro`

Topic ID: `D904B1E4-EE57-BE3E-E6A3-DACDC222477F`

Source: [logic/ch19-tables.html](../../../database-sources/logic/3988520F-3CAB-5534-5220-01D13E8437C2.html) — ID `3988520F-3CAB-5534-5220-01D13E8437C2`

CENT LOGIC — PART B · CHAPTER 19 / 19 · 🔴 CHALLENGE
فصل ۱۹: حل مسئله با جدول و معادلات همزمان — Tables & Simultaneous Equations
این آخرین فصلِ اصلیِ جزوه‌ست. اینجا با مسئله‌هایی سروکار داریم که چند مجهول دارن و از طریقِ چند رابطه (نه یک فرمولِ ساده) به هم وصل شدن — دقیقاً جایی که یک روشِ نظام‌مند، تفاوتِ بینِ حلِ سریع و گم شدن در جبر رو می‌سازه.

## Bاین مبحث چیست؟

Section ID: `958FA24D-FEBB-CFD4-C440-9B6A9F649D25`

Import key: `logic/ch19-tables.html#section-01`

Topic ID: `D904B1E4-EE57-BE3E-E6A3-DACDC222477F`

Source: [logic/ch19-tables.html](../../../database-sources/logic/3988520F-3CAB-5534-5220-01D13E8437C2.html) — ID `3988520F-3CAB-5534-5220-01D13E8437C2`

این مبحث چیست؟
B
دو الگوی رایج وجود داره: (۱) چند مجهول که یک «مجموعِ کل» دارن و هرکدوم بر اساسِ یکی دیگه توصیف شدن — اینجا از
استفاده می‌کنیم. (۲) چند مجهول که هرکدوم فقط در بعضی از معادله‌ها با هم ظاهر می‌شن (نه یک مجموعِ کل) — اینجا از
استفاده می‌کنیم.
روشِ جدول
جایگذاری (substitution)

## Cمفهوم اصلی

Section ID: `672F6D27-99B1-6D75-8987-1AEEC1FFD846`

Import key: `logic/ch19-tables.html#section-02`

Topic ID: `D904B1E4-EE57-BE3E-E6A3-DACDC222477F`

Source: [logic/ch19-tables.html](../../../database-sources/logic/3988520F-3CAB-5534-5220-01D13E8437C2.html) — ID `3988520F-3CAB-5534-5220-01D13E8437C2`

مفهوم اصلی
C
قدم ۱ — روشِ جدول: یک مجهول رو به‌عنوانِ پایه انتخاب کن، بقیه رو بر حسبِ اون بنویس، بعد یک معادله از رویِ «مجموعِ کل» بساز.
نمونه
The sum of the ages of Mia and Noah is 45. Mia is 7 years older than Noah. Find each person's age.
Person
Age
Noah
N
Mia
N + 7
معادله: N + (N+7) = 45 ⟹ 2N+7=45 ⟹ 2N=38 ⟹ N=19. پس نوآ ۱۹ ساله و میا ۲۶ ساله‌ست.
قدم ۲ — وقتی سه مجهول داریم ولی به‌جایِ یک «مجموعِ کل»، سه معادله‌ی دوتایی جدا داریم، باید با جایگذاریِ متوالی جلو بریم.
نمونه
Find the price of three fruits — Apple, Banana, Orange — given:
• Price of 2 Apples and 1 Banana: 15,000 Tomans
• Price of 1 Banana and 2 Oranges: 13,000 Tomans
• Price of 1 Apple and 1 Orange: 8,000 Tomans
معادلات: (۱) 2A+B=15000، (۲) B+2O=13000، (۳) A+O=8000
از (۳): O = 8000 − A
جایگذاریِ O در (۲): B + 2(8000−A) = 13000 ⟹ B + 16000 − 2A = 13000 ⟹ B − 2A = −3000 (معادله‌ی ۴)
حالا (۱) و (۴) رو با هم جمع بزن: (2A+B) + (−2A+B) = 15000 + (−3000) ⟹ 2B = 12000 ⟹ B = 6000
جایگذاریِ B در (۱): 2A+6000=15000 ⟹ A=4500
جایگذاریِ A در (۳): 4500+O=8000 ⟹ O=3500
پاسخ: سیب ۴۵۰۰، موز ۶۰۰۰، پرتقال ۳۵۰۰ تومان.
این ساده‌ترین راه برای گرفتنِ اشتباهاتِ علامت یا جایگذاریه.
قدم ۳ — همیشه در پایان، جواب‌ها رو در
معادله‌های اصلی جایگذاری کن تا مطمئن بشی جور در میان.
همه‌ی

## Dقوانین و اصول مهم

Section ID: `BBCCF1E4-81EF-34FA-50DB-C92251B6ECD0`

Import key: `logic/ch19-tables.html#section-03`

Topic ID: `D904B1E4-EE57-BE3E-E6A3-DACDC222477F`

Source: [logic/ch19-tables.html](../../../database-sources/logic/3988520F-3CAB-5534-5220-01D13E8437C2.html) — ID `3988520F-3CAB-5534-5220-01D13E8437C2`

قوانین و اصول مهم
D
نوعِ داده‌ها
روش
یک «مجموعِ کل» + توصیفِ همه بر حسبِ یکی
روشِ جدول: همه رو بر حسبِ یک متغیر بنویس، یک معادله بساز
چند معادله‌ی دوتاییِ جدا (بدون مجموعِ کل)
جایگذاریِ متوالی: از ساده‌ترین معادله شروع کن و مجهول‌ها رو یکی‌یکی حذف کن

## Eروش حل

Section ID: `8381E61F-5BF8-9956-2C8D-EB499CA7FEAE`

Import key: `logic/ch19-tables.html#section-04`

Topic ID: `D904B1E4-EE57-BE3E-E6A3-DACDC222477F`

Source: [logic/ch19-tables.html](../../../database-sources/logic/3988520F-3CAB-5534-5220-01D13E8437C2.html) — ID `3988520F-3CAB-5534-5220-01D13E8437C2`

روش حل
E
همه‌ی مجهول‌ها رو فهرست کن.
مشخص کن چه نوع رابطه‌ای بینشون داده شده: یک مجموعِ کل، یا چند معادله‌ی دوتاییِ جدا.
برای روشِ جدول: یک متغیر پایه انتخاب کن، بقیه رو بر حسبش بنویس، یک معادله از مجموع بساز و حل کن.
برای جایگذاری: ساده‌ترین معادله رو برای یک متغیر حل کن، در معادله‌ی دیگه جایگذاری کن، تا وقتی فقط یک مجهول بمونه تکرار کن.
همه‌ی جواب‌ها رو در معادله‌های اصلی چک کن.
→ جواب: مقدارِ هر مجهول.

## Fمثال آموزشی

Section ID: `7832F4ED-226C-F936-9AB4-E1A1F3F047BD`

Import key: `logic/ch19-tables.html#section-05`

Topic ID: `D904B1E4-EE57-BE3E-E6A3-DACDC222477F`

Source: [logic/ch19-tables.html](../../../database-sources/logic/3988520F-3CAB-5534-5220-01D13E8437C2.html) — ID `3988520F-3CAB-5534-5220-01D13E8437C2`

مثال آموزشی
F
Example 1 — برای درک مفهوم
The sum of two numbers is 50. The first number is 10 more than the second. Find both numbers.
فرض کن دومی N باشه؛ اولی N+10. معادله: N+(N+10)=50 ⟹ 2N=40 ⟹ N=20. پس دومی ۲۰ و اولی ۳۰ است.

## Gمثال امتحانی

Section ID: `725D32C6-1AAD-DC2A-77C7-DE085CC9F2F4`

Import key: `logic/ch19-tables.html#section-06`

Topic ID: `D904B1E4-EE57-BE3E-E6A3-DACDC222477F`

Source: [logic/ch19-tables.html](../../../database-sources/logic/3988520F-3CAB-5534-5220-01D13E8437C2.html) — ID `3988520F-3CAB-5534-5220-01D13E8437C2`

مثال امتحانی
G
Example 2 — CEnT style
Three coworkers — Alex, Ben, and Cara — have a combined 34 years of experience. Ben has 4 years more experience than Alex. Cara has 6 years more experience than Alex. How many years of experience does Ben have?
A) 8
B) 10
C) 12
D) 16
از کجا شروع کنیم؟
این یک «مجموعِ کل» با توصیفِ زنجیره‌ای داره — دقیقاً الگوی روشِ جدول. هم Ben و هم Cara مستقیماً بر حسبِ Alex توصیف شدن، پس منطقی‌ترین انتخابِ متغیرِ پایه، Alex است.
چه اطلاعاتی مهمه؟
فرض کن Alex = A. طبقِ متن: Ben = A+4، Cara = A+6. معادله: A + (A+4) + (A+6) = 34 ⟹ 3A+10=34 ⟹ 3A=24 ⟹ A=8. پس Ben = A+4 = 12.
چی حواس‌پرت‌کنه؟
گزینه‌ی A (=8) دقیقاً سنِ Alex است، نه Ben — کسی که عجله کنه ممکنه بعد از پیدا کردنِ A، فراموش کنه سؤال از Ben پرسیده، نه از متغیرِ پایه. گزینه‌ی D (=16) هم از جمع زدنِ اشتباهِ ۴+۶+A به‌جایِ اضافه کردنِ فقط ۴ به A به‌دست میاد.
چرا این روش مطمئن‌تره؟
چک نهایی: Alex=8, Ben=12, Cara=14. جمع = 8+12+14 = 34 ✓ — دقیقاً با مجموعِ داده‌شده مطابقت داره.
🎯 EXAM TIP
همیشه به‌عنوانِ متغیرِ پایه، اونی رو انتخاب کن که بقیه‌ی رابطه‌ها مستقیماً بر حسبش نوشته شدن — این کارِ جبری رو به حداقل می‌رسونه و احتمالِ اشتباه رو کم می‌کنه.
⚡ QUICK METHOD
بعد از پیدا کردنِ همه‌ی جواب‌ها، همیشه جمعشون بزن و با «مجموعِ کل»ی که سؤال داده مقایسه کن (یا در موردِ معادله‌های چندگانه، هر سه معادله رو دوباره چک کن). این یک ثانیه طول می‌کشه ولی تقریباً همه‌ی اشتباهاتِ جبری رو می‌گیره.
⚠️ COMMON MISTAKES
نوشتنِ رابطه‌ی «X، Y سال کمتر از Z است» در جهتِ اشتباه — مثلاً X=Z+Y به‌جایِ X=Z−Y.
اشتباه:
عبارت‌های «کمتر از» و «بیشتر از» در جمله‌های طولانی و زنجیره‌ای به‌راحتی با هم قاطی می‌شن، مخصوصاً وقتی چند رابطه پشتِ سرِ هم بیان می‌شن.
چرا اتفاق می‌افته:
برای هر رابطه، جدا و آهسته بخون: «X … than Y» — اگه «less» بود، X کوچیک‌تره (X = Y − عدد)؛ اگه «more» بود، X بزرگ‌تره (X = Y + عدد). هیچ‌وقت دو رابطه رو هم‌زمان در ذهن ترجمه نکن.
چطور جلوش رو بگیریم:
🪤 QUESTION TRAP
وقتی چند رابطه‌ی زنجیره‌ای پشتِ سرِ هم میان («A نسبت به B …، و C نسبت به A …»)، آزمون گاهی جهتِ یکی از رابطه‌ها رو در وسطِ جمله عوض می‌کنه تا داوطلب که به الگوی قبلی عادت کرده، غافلگیر بشه. هر رابطه رو کاملاً مستقل و از اول بخون.
🧠 MUST REMEMBER
مجموعِ کل + توصیفِ زنجیره‌ای ⟹ روشِ جدول (یک متغیر پایه). چند معادله‌ی دوتاییِ جدا ⟹ جایگذاریِ متوالی. همیشه در پایان، جواب‌ها رو در معادله‌های اصلی چک کن.

## 📝تمرین

Section ID: `287ABF54-ABEF-8655-F4CA-9730D24DBCFB`

Import key: `logic/ch19-tables.html#section-07`

Topic ID: `D904B1E4-EE57-BE3E-E6A3-DACDC222477F`

Source: [logic/ch19-tables.html](../../../database-sources/logic/3988520F-3CAB-5534-5220-01D13E8437C2.html) — ID `3988520F-3CAB-5534-5220-01D13E8437C2`

تمرین
📝
آسان
The sum of two numbers is 60. The first number is 12 more than the second. What is the second number?
A) 20
B) 24
C) 30
D) 36
نمایش پاسخ و توضیح
فرض کن دومی=N، اولی=N+12. N+(N+12)=60 ⟹ 2N=48 ⟹ N=24.
پاسخ درست: B.
متوسط
Three siblings have a combined age of 54. Emma is twice as old as Liam. Liam is 3 years younger than Noah. If Liam's age is L, which equation correctly represents the total?
A) L + 2L + (L−3) = 54
B) L + 2L + (L+3) = 54
C) L + (L/2) + (L+3) = 54
D) L + 2L + (L+3) = 27
نمایش پاسخ و توضیح
Emma = 2L (دو برابرِ لیام). "Liam is 3 years younger than Noah" یعنی Liam = Noah−3، پس Noah = Liam+3 = L+3. جمعِ کل: L + 2L + (L+3) = 54. گزینه‌ی A جهتِ رابطه‌ی Noah رو برعکس کرده — دقیقاً همون دامِ رایجِ این فصل.
پاسخ درست: B.
سخت
Find the price of three items — X, Y, Z — given:
• Price of 1 X and 2 Y: 32
• Price of 2 Y and 1 Z: 28
• Price of 1 X and 1 Z: 20
What is the price of Y?
A) 6
B) 8
C) 10
D) 12
نمایش پاسخ و توضیح
معادلات: (۱) X+2Y=32، (۲) 2Y+Z=28، (۳) X+Z=20. از (۱): X=32−2Y. جایگذاری در (۳): (32−2Y)+Z=20 ⟹ Z=2Y−12 (معادله‌ی ۴). جایگذاریِ (۴) در (۲): 2Y+(2Y−12)=28 ⟹ 4Y−12=28 ⟹ 4Y=40 ⟹ Y=10. چک نهایی: X=32−20=12، Z=2(10)−12=8. جایگذاری در (۲): 2(10)+8=28 ✓. در (۳): 12+8=20 ✓. همه‌ی معادلات جور در میان.
پاسخ درست: C.

## 🚀مرور سریع — فصل ۱۹ (پایانِ فصل‌های اصلی)

Section ID: `6E4637D9-A95C-D437-CB71-F82B7F15D7AA`

Import key: `logic/ch19-tables.html#section-08`

Topic ID: `D904B1E4-EE57-BE3E-E6A3-DACDC222477F`

Source: [logic/ch19-tables.html](../../../database-sources/logic/3988520F-3CAB-5534-5220-01D13E8437C2.html) — ID `3988520F-3CAB-5534-5220-01D13E8437C2`

مرور سریع — فصل ۱۹ (پایانِ فصل‌های اصلی)
🚀
مفاهیم اصلی
مجموعِ کل + توصیفِ زنجیره‌ای ⟹ روشِ جدول.
چند معادله‌ی دوتاییِ جدا ⟹ جایگذاریِ متوالی.
روش
یک متغیرِ پایه انتخاب کن که بیشترین رابطه‌ها بر حسبشن.
همیشه در پایان، در معادله‌های اصلی چک کن.
اشتباهات رایج
برعکس نوشتنِ جهتِ «کمتر از / بیشتر از».
دام‌های تستی
عوض شدنِ جهتِ یک رابطه در وسطِ زنجیره.
جواب دادن با متغیرِ پایه به‌جایِ چیزی که واقعاً پرسیده شده.
