# فصل ۱۶: نمودارهای خطی و تحلیل روند — Line Graphs & Trend Analysis

Original chapter ID: `848BA68E-E652-45E4-E203-5F361C801C1D`

Original chapter import key: `logic/ch16-linegraphs.html#chapter`

## فصل ۱۶: نمودارهای خطی و تحلیل روند — Line Graphs & Trend Analysis

Section ID: `0FE992D6-F892-1EAE-81A2-2957ED1C3BEA`

Import key: `logic/ch16-linegraphs.html#intro`

Topic ID: `E500B580-EDBA-8619-8580-4F95A0CB3BEA`

Source: [logic/ch16-linegraphs.html](../../../database-sources/logic/02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D.html) — ID `02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D`

CENT LOGIC — PART B · CHAPTER 16 / 19
فصل ۱۶: نمودارهای خطی و تحلیل روند — Line Graphs & Trend Analysis
نمودار خطی روندِ یک کمیت رو در طول زمان نشون می‌ده. سخت‌ترین بخشِ این نوع سؤالات، فرق گذاشتن بین چهار مفهومِ شبیه‌به‌هم است: بالاترین نقطه، تیزترین افزایش، روندِ کلی، و یک نوسانِ موقتی.

## Bاین مبحث چیست؟

Section ID: `1DFB92BF-3088-7D01-242B-4FCA2CB1E411`

Import key: `logic/ch16-linegraphs.html#section-01`

Topic ID: `E500B580-EDBA-8619-8580-4F95A0CB3BEA`

Source: [logic/ch16-linegraphs.html](../../../database-sources/logic/02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D.html) — ID `02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D`

این مبحث چیست؟
B
در نمودار خطی
، نقاط داده به ترتیبِ زمان به هم وصل می‌شن. سؤالات معمولاً درباره‌ی یکی از این چهار چیز می‌پرسن:
،
،
، یا یک
.
(line graph)
بالاترین نقطه
تیزترین تغییر (افزایش یا کاهش)
روندِ کلی
نوسانِ موقتیِ محلی

## Cمفهوم اصلی

Section ID: `64652D44-2617-A379-AE96-F728DCE56BF2`

Import key: `logic/ch16-linegraphs.html#section-02`

Topic ID: `E500B580-EDBA-8619-8580-4F95A0CB3BEA`

Source: [logic/ch16-linegraphs.html](../../../database-sources/logic/02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D.html) — ID `02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D`

مفهوم اصلی
C
قدم ۱ — خوندنِ مستقیمِ یک نقطه از روی نمودار.
نمونه
Height Growth of a Child (0 to 5 years)
Age
0
1
2
3
4
5
Height (cm)
50
75
88
98
106
112
قدم ۲ — برای پیدا کردنِ تیزترین تغییر، باید تفاضلِ هر دو نقطه‌ی پیاپی رو حساب کنی — نه فقط با چشم به شیبِ خط نگاه کنی.
تفاضل‌های پیاپی
0→1: +25  |  1→2: +13  |  2→3: +10  |  3→4: +8  |  4→5: +6
In which age interval did the child have the highest growth in height?
این بزرگ‌ترین عددِ بینِ همه‌ی تفاضل‌های پیاپیه — نه لزوماً بازه‌ای که در نگاهِ اول «شیب‌دارترین» به‌نظر می‌رسه، چون مقیاسِ محورها می‌تونه چشم رو گول بزنه.
پاسخ: از بدو تولد تا ۱ سالگی (رشد ۲۵ سانتی‌متری).
قدم ۳ — فرقِ «بالاترین نقطه»، «تیزترین تغییر» و «روندِ کلی».
بزرگ‌ترین مقدارِ مطلق در کل نمودار (فارغ از اینکه چطور بهش رسیده).
بالاترین نقطه:
بزرگ‌ترین تفاضلِ بینِ دو نقطه‌ی
(می‌تونه در هر جای نمودار اتفاق بیفته، حتی اگه نقطه‌ی پایانیش بالاترین نقطه نباشه).
تیزترین تغییر:
پیاپی
جهتِ عمومیِ تغییرات از ابتدا تا انتها — که باید
رو در نظر بگیره، نه فقط مقایسه‌ی اولین و آخرین نقطه.
روندِ کلی:
کلِ الگو
یک افتِ کوچیک در وسطِ راه، الزاماً کلِ روند رو نقض نمی‌کنه — باید ببینی جهتِ غالب (dominant) چیه.
قدم ۴ — یک روندِ کلیِ صعودی می‌تونه نوسانِ موقتیِ نزولی هم داشته باشه، بدون اینکه ادعای «روندِ صعودی» غلط بشه.

## Dقوانین و اصول مهم

Section ID: `0A9951B5-EBBE-64FA-46FB-7AC4D6D367B7`

Import key: `logic/ch16-linegraphs.html#section-03`

Topic ID: `E500B580-EDBA-8619-8580-4F95A0CB3BEA`

Source: [logic/ch16-linegraphs.html](../../../database-sources/logic/02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D.html) — ID `02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D`

قوانین و اصول مهم
D
برای تیزترین افزایش/کاهش، همیشه تفاضلِ هر دو نقطه‌ی پیاپی رو محاسبه کن — به شیبِ بصری اعتماد نکن، چون مقیاسِ محور می‌تونه گمراه‌کننده باشه.
بالاترین نقطه، تیزترین تغییر، و روندِ کلی سه سؤالِ کاملاً متفاوتن.
روندِ کلی باید بر اساسِ الگوی کاملِ داده‌ها تشخیص داده بشه، نه فقط مقایسه‌ی نقطه‌ی اول و آخر.

## Eروش حل

Section ID: `CA225E76-FF5E-86E5-4C49-5EACD5A775E3`

Import key: `logic/ch16-linegraphs.html#section-04`

Topic ID: `E500B580-EDBA-8619-8580-4F95A0CB3BEA`

Source: [logic/ch16-linegraphs.html](../../../database-sources/logic/02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D.html) — ID `02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D`

روش حل
E
همه‌ی نقاطِ داده رو به‌ترتیب فهرست کن.
اگه سؤال درباره‌ی تغییره، تفاضلِ هر جفت نقطه‌ی پیاپی رو یک‌بار و از اول تا آخر محاسبه کن.
مشخص کن دقیقاً کدوم نوع سؤاله: بالاترین نقطه، تیزترین تغییر، یا روندِ کلی.
هر گزینه رو با محاسبه‌ی دقیق (نه با نگاهِ چشمی) تأیید یا رد کن.
→ جواب: طبق دقیقاً همون نوع سؤالی که پرسیده شده.

## Fمثال آموزشی

Section ID: `9AD8C1EF-9759-21D7-BDAD-6FABF706F62B`

Import key: `logic/ch16-linegraphs.html#section-05`

Topic ID: `E500B580-EDBA-8619-8580-4F95A0CB3BEA`

Source: [logic/ch16-linegraphs.html](../../../database-sources/logic/02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D.html) — ID `02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D`

مثال آموزشی
F
Example 1 — برای درک مفهوم
Average Daily Temperature (°C) Over a Week
Day
1
2
3
4
5
6
7
Temp
22
24
25
22
20
19
21
On which day did the largest temperature DROP compared to the previous day occur?
تفاضل‌های پیاپی: Day1→2: +2, Day2→3: +1, Day3→4:
, Day4→5: −2, Day5→6: −1, Day6→7: +2. بزرگ‌ترین افتِ منفی، از روز ۳ به روز ۴ (۳ درجه) اتفاق افتاده — نه بازه‌ای دیگه که شاید در نگاهِ اول به چشم بیاد.
پاسخ: روز ۴ (نسبت به روز ۳).
−3

## Gمثال امتحانی

Section ID: `F5E0E7C9-1844-217C-8FF3-5B611CF9C470`

Import key: `logic/ch16-linegraphs.html#section-06`

Topic ID: `E500B580-EDBA-8619-8580-4F95A0CB3BEA`

Source: [logic/ch16-linegraphs.html](../../../database-sources/logic/02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D.html) — ID `02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D`

مثال امتحانی
G
Example 2 — CEnT style
Company Quarterly Profits (Million €)
Q1
Q2
Q3
Q4
Q5
Q6
Q7
Q8
4
7
5
9
8
10
6
11
Which statement is correct?
A) Profit increased in every quarter.
B) The largest drop occurred between Q6 and Q7.
C) The largest rise occurred between Q4 and Q5.
D) The overall increase from Q1 to Q8 was 6 million euros.
E) Profit was highest at Q6.
از کجا شروع کنیم؟
طبق قدم ۲، اول همه‌ی تفاضل‌های پیاپی رو یک‌جا حساب کن: Q1→2: +3, Q2→3: −2, Q3→4: +4, Q4→5: −1, Q5→6: +2, Q6→7:
, Q7→8: +5.
−4
چه اطلاعاتی مهمه؟
بزرگ‌ترین عددِ منفی در این لیست، −4 است که بینِ Q6 و Q7 اتفاق افتاده — دقیقاً گزینه‌ی B.
چی حواس‌پرت‌کنه؟
گزینه‌ی A با وجودِ چند افتِ واضح (مثل Q2→Q3) نقض می‌شه. گزینه‌ی C بازه‌ی اشتباهی رو نام برده — Q4→Q5 در واقع یک
(−1) است، نه یک رشد؛ بزرگ‌ترین رشدِ واقعی بینِ Q7 و Q8 (+5) اتفاق افتاده. گزینه‌ی D محاسبه‌اش غلطه: ۱۱−۴=۷، نه ۶. گزینه‌ی E هم اشتباهه چون بالاترین نقطه در Q8 (=11) است، نه Q6 (=10).
افت
چرا این روش مطمئن‌تره؟
چون به‌جای قضاوتِ چشمی روی شکلِ نمودار، هر پنج گزینه رو با محاسبه‌ی دقیق و مستقل تست کردیم — دقیقاً طبقِ قدمِ ۴ در «روش حل».
🎯 EXAM TIP
قبل از نگاه به گزینه‌ها، یک جدولِ کوچیک از تفاضل‌های پیاپی برای خودت بساز (حتی روی کاغذِ سررسید). این کار سریع‌تر از اینه که برای هر گزینه دوباره برگردی و از نمودار عدد بخونی.
⚡ QUICK METHOD
برای سؤالِ «روندِ کلی»، اگه فقط اولین و آخرین نقطه رو با هم مقایسه کنی ممکنه گمراه بشی. به‌جاش، به علامتِ اکثریتِ تفاضل‌های پیاپی نگاه کن — اگه بیشترشون مثبت‌ان، روندِ کلی صعودیه، حتی اگه یکی‌دو تا نوسانِ منفی هم داشته باشه.
⚠️ COMMON MISTAKES
محاسبه‌ی «افزایشِ کلی» با فرمولِ «بالاترین نقطه منهای پایین‌ترین نقطه» به‌جای «آخرین نقطه منهای اولین نقطه».
اشتباه:
وقتی داده‌ها نوسان دارن، ذهن به‌طور طبیعی به سمتِ بزرگ‌ترین و کوچک‌ترین عددِ کلِ جدول کشیده می‌شه، در حالی که «افزایشِ کلی از ابتدا تا انتها» فقط به دو نقطه‌ی خاص (اول و آخر) مربوطه.
چرا اتفاق می‌افته:
همیشه دقیقاً بخونِ سؤال از کدوم دو نقطه صحبت می‌کنه — «بالاترین تا پایین‌ترین» یا «اول تا آخر» — و فقط همون دو تا رو کم کن.
چطور جلوش رو بگیریم:
🪤 QUESTION TRAP
گزینه‌هایی که یک بازه‌ی زمانیِ اشتباه رو با یک ادعای درست ترکیب می‌کنن (مثل «بزرگ‌ترین رشد بینِ Q4 و Q5» — که در واقع یک افت بوده، نه رشد) خیلی رایجن. همیشه هم جهتِ تغییر (رشد یا افت) و هم بازه‌ی زمانی رو جداگانه چک کن.
🧠 MUST REMEMBER
تیزترین تغییر = بزرگ‌ترین تفاضلِ پیاپی (نه شیبِ بصری). بالاترین نقطه ≠ تیزترین تغییر ≠ روندِ کلی. افزایشِ کلی = آخرین نقطه − اولین نقطه (نه بالاترین − پایین‌ترین).

## 📝تمرین

Section ID: `D9945011-10D1-E663-8E9F-CB8C4AAFAA6B`

Import key: `logic/ch16-linegraphs.html#section-07`

Topic ID: `E500B580-EDBA-8619-8580-4F95A0CB3BEA`

Source: [logic/ch16-linegraphs.html](../../../database-sources/logic/02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D.html) — ID `02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D`

تمرین
📝
آسان
A line graph shows monthly rainfall (mm): Jan 40, Feb 55, Mar 30, Apr 60. Between which two consecutive months was the increase the largest?
A) Jan to Feb
B) Feb to Mar
C) Mar to Apr
D) All increases were equal.
نمایش پاسخ و توضیح
تفاضل‌ها: Jan→Feb: +15, Feb→Mar: −25, Mar→Apr: +30. بزرگ‌ترین افزایش بینِ مارس و آوریل (+30) اتفاق افتاده.
پاسخ درست: C.
متوسط
A line graph tracks a stock price over 5 days: Day1=€50, Day2=€65, Day3=€40, Day4=€55, Day5=€45. What is the overall change from Day 1 to Day 5?
A) An increase of €15 (using the highest and lowest points)
B) A decrease of €5 (Day 5 minus Day 1)
C) An increase of €25
D) No overall change.
نمایش پاسخ و توضیح
«تغییرِ کلی از روز ۱ تا روز ۵» یعنی Day5 − Day1 = 45 − 50 = −5 (یعنی ۵ یورو کاهش). گزینه‌ی A دقیقاً همون اشتباهِ رایجه — به‌جای اول و آخر، بالاترین (۶۵) و پایین‌ترین (۴۰) رو با هم مقایسه کرده.
پاسخ درست: B.
سخت
A line graph shows a factory's weekly output (units) over 6 weeks: W1=100, W2=120, W3=90, W4=140, W5=130, W6=160. Which of the following is TRUE?
A) Output decreased overall from Week 1 to Week 6.
B) The sharpest single-week drop was larger than the sharpest single-week rise.
C) The overall trend is upward, despite a temporary dip in Week 3.
D) Output was highest in Week 5.
نمایش پاسخ و توضیح
تفاضل‌های پیاپی: W1→2: +20, W2→3: −30, W3→4: +50, W4→5: −10, W5→6: +30. با اینکه یک افتِ محلی در هفته‌ی ۳ داریم (−30)، روندِ کلی از ۱۰۰ به ۱۶۰ صعودیه — و اکثرِ تفاضل‌ها هم مثبت‌ان. گزینه‌ی A مستقیماً غلطه (۱۰۰ به ۱۶۰ که افزایشه). گزینه‌ی B غلطه چون بزرگ‌ترین افزایشِ پیاپی (+50) از بزرگ‌ترین افتِ پیاپی (−30) بزرگ‌تره. گزینه‌ی D هم غلطه — بالاترین مقدار در هفته‌ی ۶ (۱۶۰) است، نه هفته‌ی ۵ (۱۳۰).
پاسخ درست: C.

## 🚀مرور سریع — فصل ۱۶

Section ID: `D739D50D-3B4D-B56E-5CBB-0A81568728C1`

Import key: `logic/ch16-linegraphs.html#section-08`

Topic ID: `E500B580-EDBA-8619-8580-4F95A0CB3BEA`

Source: [logic/ch16-linegraphs.html](../../../database-sources/logic/02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D.html) — ID `02B0C98C-BFA6-D4CF-B9DA-EECC6F2C5E3D`

مرور سریع — فصل ۱۶
🚀
مفاهیم اصلی
تیزترین تغییر = بزرگ‌ترین تفاضلِ پیاپی.
بالاترین نقطه ≠ تیزترین تغییر ≠ روندِ کلی.
روندِ کلی = آخر − اول، نه بالاترین − پایین‌ترین.
روش
همه‌ی تفاضل‌های پیاپی رو یک‌جا حساب کن.
نوع دقیقِ سؤال رو مشخص کن.
اشتباهات رایج
محاسبه‌ی «افزایشِ کلی» با بالاترین/پایین‌ترین به‌جای اول/آخر.
دام‌های تستی
بازه‌ی زمانیِ اشتباه با جهتِ تغییرِ اشتباه ترکیب‌شده.
