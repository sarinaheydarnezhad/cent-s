# فصل ۱۳: نقیض گزاره‌های کمّی — Negating Universal & Existential Statements

Original chapter ID: `E5C9B6EE-50FA-6C46-C32F-BC70706D41C0`

Original chapter import key: `logic/ch13-quantifiers.html#chapter`

## فصل ۱۳: نقیض گزاره‌های کمّی — Negating Universal & Existential Statements

Section ID: `45DDC559-3ED4-095E-330B-FE7C009E5FD9`

Import key: `logic/ch13-quantifiers.html#intro`

Topic ID: `79BC368D-0E70-A098-F148-709A8804AAAD`

Source: [logic/ch13-quantifiers.html](../../../database-sources/logic/B7E4AFA2-59FC-382C-AFCF-883920732837.html) — ID `B7E4AFA2-59FC-382C-AFCF-883920732837`

CENT LOGIC — PART A · CHAPTER 13 / 13 · 🔴 CHALLENGE
فصل ۱۳: نقیض گزاره‌های کمّی — Negating Universal & Existential Statements
این آخرین فصل بخش A است و مستقیماً روی فصل ۱۰ بنا می‌شه — همون قوانین «All / Some / No»، ولی این‌بار به زبان نمادین کمّی‌سنج‌ها
و با جمله‌های انگلیسیِ پیچیده‌تر و گول‌زننده‌تر.
(quantifiers)

## Bاین مبحث چیست؟

Section ID: `2AB24BB1-3283-73FC-0355-01C0E5D4F039`

Import key: `logic/ch13-quantifiers.html#section-01`

Topic ID: `79BC368D-0E70-A098-F148-709A8804AAAD`

Source: [logic/ch13-quantifiers.html](../../../database-sources/logic/B7E4AFA2-59FC-382C-AFCF-883920732837.html) — ID `B7E4AFA2-59FC-382C-AFCF-883920732837`

این مبحث چیست؟
B
خیلی از جمله‌های انگلیسی، بدون استفاده از کلمات صریح «all» یا «some»، در واقع یک ادعای کمّی رو پنهان می‌کنن — مثل «each time…»، «anyone who…»، یا «no one has…». این فصل کمکت می‌کنه این کمّی‌سنج‌های پنهان رو پیدا کنی و درست نقیضشون کنی.

## Cمفهوم اصلی

Section ID: `72CF7EE5-D07C-8EC1-44F8-21F648F63B16`

Import key: `logic/ch13-quantifiers.html#section-02`

Topic ID: `79BC368D-0E70-A098-F148-709A8804AAAD`

Source: [logic/ch13-quantifiers.html](../../../database-sources/logic/B7E4AFA2-59FC-382C-AFCF-883920732837.html) — ID `B7E4AFA2-59FC-382C-AFCF-883920732837`

مفهوم اصلی
C
یعنی «برای همه‌ی x» (all/every/each)،
یعنی «حداقل یک x وجود داره» (some/there exists/a…that)، و
یعنی «هیچ x ای وجود نداره» (no/none).
قدم ۱ — نمادهای کمّی‌سنج:
∀x
∃x
∄x
قدم ۲ — سه قانون نقیضِ کمّی‌سنج (دقیقاً معادلِ همون قوانین فصل ۱۰، فقط با نماد):
گزاره
نقیضش
∀x; p(x)
∃x; ~p(x)
∃x; p(x)
(=
)
∀x; ~p(x)
∄x; p(x)
∄x; p(x)
∃x; p(x)
نمونه ۱ — نقیضِ ∀
"All doctors have illegible handwriting." (همه‌ی دکترها خط ناخوانا دارن)
"There exists a doctor who has legible handwriting." (دکتری وجود داره که خط خوانا داره) — طبق قدم ۲، فقط یک استثنا کافیه.
نقیض:
نمونه ۲ — نقیضِ ∃
"There exists a bear that is white." (خرسی وجود داره که سفیده)
"No bear is white." (هیچ خرسی سفید نیست) — طبق قدم ۲، باید نشون بدی هیچ نمونه‌ای وجود نداره.
نقیض:
نمونه ۳ — نقیضِ ∄
"No child lies." (هیچ کودکی دروغ نمی‌گه)
"There exists a child who lies." (کودکی وجود داره که دروغ می‌گه)
نقیض:
«Each time X, Y» یعنی «برای هر لحظه‌ای، اگه X پیش بیاد، Y هم پیش میاد» — یک ترکیب از ∀ (فصل ۱۳) و شرطی (فصل ۴).
قدم ۳ — کمّی‌سنج‌های پنهان: عبارت‌هایی مثل «each time…»، «whenever…»، «anyone who…» در واقع یک شرطیِ زیرِ یک ∀ پنهان هستن.
نمونه
"Each time I took my umbrella, it did not rain."
این معادلِ «∀t: If (I took my umbrella at time t) then (it did not rain at time t)» است. برای نقیض کردنش، باید هم قانونِ نقیضِ ∀ (قدم ۲) رو اعمال کنیم، هم قانونِ نقیضِ شرطی (فصل ۷):
. نتیجه:
not-(if A then B) = A and not-B
"There is at least one time I took my umbrella AND it rained."

## Dقوانین و اصول مهم

Section ID: `19FF0E38-E8BC-C1B4-F7FA-3C146C53366F`

Import key: `logic/ch13-quantifiers.html#section-03`

Topic ID: `79BC368D-0E70-A098-F148-709A8804AAAD`

Source: [logic/ch13-quantifiers.html](../../../database-sources/logic/B7E4AFA2-59FC-382C-AFCF-883920732837.html) — ID `B7E4AFA2-59FC-382C-AFCF-883920732837`

قوانین و اصول مهم
D
All ⟷ نقیض: Some…not (فقط یک استثنا کافیه).
Some ⟷ نقیض: No (باید نشون بدی هیچ نمونه‌ای نیست).
No ⟷ نقیض: Some (فقط یک نمونه کافیه).
عبارت‌های «each time / whenever / anyone who» یک ∀ پنهان دارن که معمولاً با یک شرطی ترکیب شده — برای نقیضشون، هم قانون کمّی‌سنج و هم قانون نقیضِ شرطی (فصل ۷) رو با هم لازم داری.

## Eروش حل

Section ID: `AAFF69E2-4BBE-E489-25E6-2E14EFF0C673`

Import key: `logic/ch13-quantifiers.html#section-04`

Topic ID: `79BC368D-0E70-A098-F148-709A8804AAAD`

Source: [logic/ch13-quantifiers.html](../../../database-sources/logic/B7E4AFA2-59FC-382C-AFCF-883920732837.html) — ID `B7E4AFA2-59FC-382C-AFCF-883920732837`

روش حل
E
کمّی‌سنجِ پنهان یا صریحِ جمله رو پیدا کن (all/each/every = ∀، some/a…that = ∃، no/none = ∄).
اگه جمله شاملِ یک شرطیِ داخلی هم بود (مثل «each time X, Y»)، اول اون رو به فرم «If X then Y» بازنویسی کن.
قانونِ نقیضِ کمّی‌سنج رو از جدول قدم ۲ اعمال کن (∀⇄∃).
اگه شرطیِ داخلی هم داشت، طبق فصل ۷ نقیضش کن (not-(if X then Y) = X and not-Y).
→ جواب: گزاره‌ی نقیض‌شده به زبان طبیعی.

## Fمثال آموزشی

Section ID: `A3209CF4-6D8D-9146-5E51-6C1F87EEB9B1`

Import key: `logic/ch13-quantifiers.html#section-05`

Topic ID: `79BC368D-0E70-A098-F148-709A8804AAAD`

Source: [logic/ch13-quantifiers.html](../../../database-sources/logic/B7E4AFA2-59FC-382C-AFCF-883920732837.html) — ID `B7E4AFA2-59FC-382C-AFCF-883920732837`

مثال آموزشی
F
Example 1 — برای درک مفهوم
Write the negation of: "Not all donuts come out with a hole."
این جمله خودش از قبل یک نقیض داره (not-All). طبق قدم ۲، «not-(All A are B)» = «Some A are not-B». پس معادلش می‌شه:
— نه یک ادعای جدید و شدیدتر مثل «هیچ دونات‌ای سوراخ نداره».
"Some donuts do not come out with a hole."

## Gمثال امتحانی

Section ID: `B04DEB7F-C51E-359D-42A2-137C7C08D790`

Import key: `logic/ch13-quantifiers.html#section-06`

Topic ID: `79BC368D-0E70-A098-F148-709A8804AAAD`

Source: [logic/ch13-quantifiers.html](../../../database-sources/logic/B7E4AFA2-59FC-382C-AFCF-883920732837.html) — ID `B7E4AFA2-59FC-382C-AFCF-883920732837`

مثال امتحانی
G
Example 2 — CEnT style
The statement "Each student who studies passes the exam" is FALSE. What does this tell us?
A) Whoever does not study will fail.
B) There are students who pass the exam without having studied.
C) Some students who studied did not pass the exam.
D) All those who study pass the exam.
از کجا شروع کنیم؟
اول جمله رو به فرم منطقی برگردون: "∀x: If (x studies) then (x passes)."
چه اطلاعاتی مهمه؟
نقیضش طبق قدم ۲ و فصل ۷ می‌شه: "∃x: (x studies) AND not-(x passes)" = "Some students who studied did not pass the exam." — دقیقاً گزینه‌ی C.
چی حواس‌پرت‌کنه؟
گزینه‌ی A و D اصلاً به موضوع نقیض ربطی ندارن — این‌ها ادعاهای کاملاً متفاوتی هستن که هیچ‌کدوم از نقیضِ اصلی نتیجه نمی‌شن. گزینه‌ی B هم دقیقاً برعکسِ نتیجه‌ی درسته (این جمله درباره‌ی کسانی که
است، نه کسانی که
).
درس خوندن ولی قبول نشدن
درس نخوندن ولی قبول شدن
چرا این روش مطمئن‌تره؟
چون به‌جای حدس زدن معنیِ کلی جمله، مستقیماً از ترکیبِ دو قانونِ دقیق (نقیضِ ∀ + نقیضِ شرطی) استفاده کردیم.
🎯 EXAM TIP
هر وقت کلمات
رو دیدی، فوراً تشخیص بده که یک کمّی‌سنج (∀ یا ∄) پنهانه. اگه بعدش یک رابطه‌ی «اگه…پس» هم بود، هر دو قانون (نقیضِ کمّی‌سنج از این فصل + نقیضِ شرطی از فصل ۷) رو با هم لازم داری.
each, every, whenever, anyone who, no one
⚡ QUICK METHOD
سه قانون این فصل، دقیقاً همون سه قانونِ فصل ۱۰ هستن با نماد جدید:
،
(یا
)،
. اگه فصل ۱۰ رو خوب یاد گرفتی، فقط کافیه علائم رو بشناسی — هیچ قانونِ جدیدی یاد نگرفتی.
∀↔∃not
∃↔∀not
∄
∄↔∃
⚠️ COMMON MISTAKES
نقیض کردن فقط جمله‌ی داخلی (predicate) بدون تغییر کمّی‌سنج — مثلاً نقیضِ «Each time I took my umbrella, it did not rain» رو اشتباهاً «Each time I took my umbrella, it rained» نوشتن.
اشتباه:
ذهن معمولاً روی نقیضِ فعلِ اصلی (rained/did not rain) تمرکز می‌کنه و فراموش می‌کنه که خودِ کمّی‌سنجِ «each» هم باید به «حداقل یک مورد» (∃) تبدیل بشه.
چرا اتفاق می‌افته:
همیشه هر دو مرحله رو جداگانه چک کن: (۱) کمّی‌سنج عوض شد؟ (۲) شرطیِ داخلی هم طبق فصل ۷ درست نقیض شد؟
چطور جلوش رو بگیریم:
🪤 QUESTION TRAP
در سؤالاتی مثل «No man has one name only»، گزینه‌ی نادرست معمولاً یک ادعای مثبتِ نامرتبط می‌ذاره (مثل «همه‌ی مردها اسم دارن» یا «مردی به نام Mario وجود داره») به‌جای نقیضِ دقیقِ گزاره. همیشه فقط دنبال نقیضِ مستقیمِ همون کمّی‌سنجِ اصلی باش، نه یک ادعای جدید و نامرتبط.
🧠 MUST REMEMBER
|
|
. عبارت‌های «each/whenever/anyone who» یک ∀+شرطیِ پنهان دارن — برای نقیضشون هر دو قانون (این فصل + فصل ۷) لازمه.
not-(∀x; p(x)) = ∃x; not-p(x)
not-(∃x; p(x)) = ∀x; not-p(x)
not-(∄x; p(x)) = ∃x; p(x)

## 📝تمرین

Section ID: `30642050-C78F-74A3-4FAA-0A3913509620`

Import key: `logic/ch13-quantifiers.html#section-07`

Topic ID: `79BC368D-0E70-A098-F148-709A8804AAAD`

Source: [logic/ch13-quantifiers.html](../../../database-sources/logic/B7E4AFA2-59FC-382C-AFCF-883920732837.html) — ID `B7E4AFA2-59FC-382C-AFCF-883920732837`

تمرین
📝
آسان
Consider the statement "No dog has three paws." Saying that it is false means that:
A) All dogs have four paws.
B) At least one dog has three paws.
C) At least one dog has a number of paws different from three.
D) All dogs have three paws.
نمایش پاسخ و توضیح
طبق قدم ۲، نقیضِ «∄x; p(x)» می‌شه «∃x; p(x)». نقیضِ «هیچ سگی سه‌پا نداره» یعنی «حداقل یک سگ سه‌پا داره» — نه ادعای بی‌ربطی درباره‌ی چهارپا بودن یا تعداد پاهای متفاوت.
پاسخ درست: B.
متوسط
Saying that it's false that "no man has one name only" is equivalent to saying that:
A) At least one man has two names.
B) There exists a man named Mario.
C) There exists at least one man with one name only.
D) There exists a man without a name.
نمایش پاسخ و توضیح
"No man has one name only" یک گزاره‌ی ∄ است. طبق قدم ۲، نقیضش «∃x; p(x)» می‌شه — یعنی مستقیماً «حداقل یک مرد با فقط یک اسم وجود داره». گزینه‌های A، B و D همه ادعاهای اضافه یا نامرتبطی هستن که هیچ‌کدوم دقیقاً نقیضِ گزاره‌ی اصلی نیستن.
پاسخ درست: C.
سخت
The statement "It's not true that it is rainy and windy" means that:
A) It is not rainy, or it is not windy.
B) It is rainy and it is not windy.
C) It is not rainy and it is not windy.
D) It is not rainy and it is windy.
نمایش پاسخ و توضیح
این یک نقیضِ عطف ساده‌ست (فصل ۷)، نه یک گزاره‌ی کمّی، ولی دقیقاً همون منطقِ «and⇄or» رو نشون می‌ده که در کل این بخش دیدیم:
. گزینه‌ی C دقیقاً همون اشتباه رایج هست — عملگر رو عوض نکرده و «and» رو نگه داشته.
پاسخ درست: A.
not-(P and Q) = (not-P) or (not-Q)

## 🚀مرور سریع — فصل ۱۳ (پایان بخش A)

Section ID: `E34DB306-1554-AA96-DD28-EB43E9268E12`

Import key: `logic/ch13-quantifiers.html#section-08`

Topic ID: `79BC368D-0E70-A098-F148-709A8804AAAD`

Source: [logic/ch13-quantifiers.html](../../../database-sources/logic/B7E4AFA2-59FC-382C-AFCF-883920732837.html) — ID `B7E4AFA2-59FC-382C-AFCF-883920732837`

مرور سریع — فصل ۱۳ (پایان بخش A)
🚀
مفاهیم اصلی
∀x;p(x) ↔ نقیض: ∃x;~p(x)
∃x;p(x) ↔ نقیض: ∀x;~p(x) (=∄x;p(x))
∄x;p(x) ↔ نقیض: ∃x;p(x)
روش
کمّی‌سنجِ پنهان (each/whenever/no one) رو پیدا کن.
اگه شرطیِ داخلی داشت، فصل ۷ رو هم اعمال کن.
اشتباهات رایج
فراموش کردنِ تغییرِ خودِ کمّی‌سنج، فقط نقیضِ فعل.
دام‌های تستی
گزینه‌های نامرتبط به‌جای نقیضِ دقیق.
