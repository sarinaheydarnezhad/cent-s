# فصل ۲: عطف — «A and B» (Conjunction)

Original chapter ID: `E809725B-17DA-A1AD-6D1A-9B2CB21DC8A9`

Original chapter import key: `logic/ch02-conjunction.html#chapter`

## فصل ۲: عطف — «A and B» (Conjunction)

Section ID: `50571F1B-435E-4B1D-7DBC-D26C4A05A629`

Import key: `logic/ch02-conjunction.html#intro`

Topic ID: `A522AA4A-B71F-2AAA-D401-3E013834F716`

Source: [logic/ch02-conjunction.html](../../../database-sources/logic/00E861CC-37A3-973A-EB9F-622250C58294.html) — ID `00E861CC-37A3-973A-EB9F-622250C58294`

CENT LOGIC — PART A · CHAPTER 2 / 13
فصل ۲: عطف — «A and B» (Conjunction)
عطف
ساده‌ترین عملگریه که یاد می‌گیری، ولی آزمون معمولاً اون رو پشت کلماتی مثل «but» یا جمله‌های با فاعل مشترک پنهان می‌کنه. این فصل هم قانون پایه رو بهت می‌ده، هم یاد می‌ده چطور عطف‌های پنهان رو پیدا کنی.
(conjunction)

## Bاین مبحث چیست؟

Section ID: `921265CF-5E3D-70A3-4AE4-D9F121D41079`

Import key: `logic/ch02-conjunction.html#section-01`

Topic ID: `A522AA4A-B71F-2AAA-D401-3E013834F716`

Source: [logic/ch02-conjunction.html](../../../database-sources/logic/00E861CC-37A3-973A-EB9F-622250C58294.html) — ID `00E861CC-37A3-973A-EB9F-622250C58294`

این مبحث چیست؟
B
هر وقت آزمون بخواد بگه «این دو (یا چند) چیز، هر دو با هم درستن»، از عطف استفاده می‌کنه. کلمه‌ی ظاهری همیشه «and» نیست — گاهی «but»، «however»، «although» یا حتی فقط یک ویرگول با فاعل مشترکه. از نظر منطقی، همه‌ی این‌ها دقیقاً همون رفتار «and» رو دارن.

## Cمفهوم اصلی

Section ID: `898A6714-B541-209E-BDF2-C14E1D3655BC`

Import key: `logic/ch02-conjunction.html#section-02`

Topic ID: `A522AA4A-B71F-2AAA-D401-3E013834F716`

Source: [logic/ch02-conjunction.html](../../../database-sources/logic/00E861CC-37A3-973A-EB9F-622250C58294.html) — ID `00E861CC-37A3-973A-EB9F-622250C58294`

مفهوم اصلی
C
اگه حتی یکی‌شون غلط باشه، کل گزاره‌ی عطفی غلط می‌شه.
قدم ۱ — تعریف: «A and B» فقط وقتی درسته که هر دوی A و B درست باشن.
A
B
A and B
T
T
T
T
F
F
F
T
F
F
F
F
توجه: در نسخه‌ی اسکن‌شده‌ی جزوه‌ی منبع، ردیف سوم این جدول به‌اشتباه «F F T» چاپ شده بود (احتمالاً خطای اسکن/تراز ستون). جدول بالا نسخه‌ی درست و استانداردِ منطق گزاره‌ای برای «and» است — فقط یک حالت (هر دو True) نتیجه‌ی True می‌ده.
کلماتی مثل
از نظر لحن یک تضاد یا تعجب رو نشون می‌دن، ولی از نظر
دقیقاً مثل «and» عمل می‌کنن — یعنی فقط وقتی کل گزاره درسته که هر دو طرفش درست باشن.
قدم ۲ — کلماتی که ظاهرشون فرق داره ولی منطقشون «and» است.
but, however, although, yet
منطقی
نمونه
"John is a Rolling Stones fan
he doesn't like The Who."
but
از نظر منطقی این معادل «John is a Rolling Stones fan
he doesn't like The Who» است. تضادی که کلمه‌ی «but» القا می‌کنه فقط جنبه‌ی سبکی و ادبی داره؛ ساختار منطقی همون عطف ساده‌ست.
and
وقتی دو گزاره فاعل یکسان دارن، آزمون ممکنه اون رو یک‌بار بنویسه.
قدم ۳ — فاعل مشترک، عطف رو کوتاه می‌کنه.
نمونه
"John is a Rolling Stones fan and a teacher."
این دقیقاً همون معنی «John is a Rolling Stones fan
John is a teacher» رو داره — فقط فاعل تکراری حذف شده. قبل از تحلیل، همیشه اول این نوع جمله رو به دو گزاره‌ی کامل و جدا باز کن.
and
همون قانون «and» ساده رو دنبال می‌کنه: کل زنجیره فقط وقتی درسته که
حلقه‌ها درست باشن. کافیه یکی غلط باشه تا کل زنجیره غلط بشه.
قدم ۴ — عطف زنجیره‌ای: «A and B and C and D and E».
همه‌ی

## Dقوانین و اصول مهم

Section ID: `EF9A24E6-7D11-A95D-05F9-2015A14C4431`

Import key: `logic/ch02-conjunction.html#section-03`

Topic ID: `A522AA4A-B71F-2AAA-D401-3E013834F716`

Source: [logic/ch02-conjunction.html](../../../database-sources/logic/00E861CC-37A3-973A-EB9F-622250C58294.html) — ID `00E861CC-37A3-973A-EB9F-622250C58294`

قوانین و اصول مهم
D
عطف فقط در یک حالت درسته: هر دو (یا همه‌ی) طرفش درست باشن.
کلمات
در متن سوال، از نظر منطقی معادل «and» هستن.
but, however, although, yet, moreover
جمله‌های با فاعل مشترک («X is A and B») باید به دو گزاره‌ی کامل و جدا («X is A» و «X is B») باز بشن.
عطف زنجیره‌ای («A and B and C…») هم از همون قانون پیروی می‌کنه — با هر تعداد حلقه.

## Eروش حل

Section ID: `07F84BEB-208C-652F-0EEF-FA867A53008E`

Import key: `logic/ch02-conjunction.html#section-04`

Topic ID: `A522AA4A-B71F-2AAA-D401-3E013834F716`

Source: [logic/ch02-conjunction.html](../../../database-sources/logic/00E861CC-37A3-973A-EB9F-622250C58294.html) — ID `00E861CC-37A3-973A-EB9F-622250C58294`

روش حل
E
همه‌ی حلقه‌های عطف رو پیدا کن — حتی اون‌هایی که پشت «but/however/although» یا فاعل مشترک پنهانن.
هر جمله‌ی با فاعل مشترک رو به گزاره‌های کامل و جدا باز کن.
ارزش درستی هر حلقه رو جداگانه مشخص کن.
اگه حتی یک حلقه غلط بود، کل گزاره‌ی عطفی غلطه — دیگه نیازی به چک کردن بقیه نیست.
→ جواب: فقط اگه همه‌ی حلقه‌ها درست بودن، کل عطف درسته.

## Fمثال آموزشی

Section ID: `90A7F854-4B24-5A18-B59C-02EE4A9D3B52`

Import key: `logic/ch02-conjunction.html#section-05`

Topic ID: `A522AA4A-B71F-2AAA-D401-3E013834F716`

Source: [logic/ch02-conjunction.html](../../../database-sources/logic/00E861CC-37A3-973A-EB9F-622250C58294.html) — ID `00E861CC-37A3-973A-EB9F-622250C58294`

مثال آموزشی
F
Example 1 — برای درک مفهوم
"The store is open and it has a discount today." The store is open (True). It does NOT have a discount today (False). Is the whole claim true or false?
با اینکه بخش اول درسته، چون بخش دوم غلطه، کل گزاره‌ی عطفی غلط می‌شه — طبق قانون قدم ۱.
پاسخ: غلط.

## Gمثال امتحانی

Section ID: `42186263-539B-F7DC-F96D-BECEC8DE8BA5`

Import key: `logic/ch02-conjunction.html#section-06`

Topic ID: `A522AA4A-B71F-2AAA-D401-3E013834F716`

Source: [logic/ch02-conjunction.html](../../../database-sources/logic/00E861CC-37A3-973A-EB9F-622250C58294.html) — ID `00E861CC-37A3-973A-EB9F-622250C58294`

مثال امتحانی
G
Example 2 — CEnT style
"Maria speaks French and Spanish, but she doesn't speak Italian." Which statement, if true, would make the whole claim FALSE?
A) Maria speaks French.
B) Maria doesn't speak Italian.
C) Maria doesn't speak Spanish.
D) Maria speaks a fourth language.
از کجا شروع کنیم؟
اول جمله رو به سه حلقه‌ی عطفی باز کن: (۱) Maria speaks French، (۲) Maria speaks Spanish، (۳) Maria doesn't speak Italian. کلمه‌ی «but» اینجا فقط لحن جمله رو عوض می‌کنه، نه ساختار منطقیش — پس هر سه حلقه با «and» به هم وصلن.
چه اطلاعاتی مهمه؟
کل گزاره فقط وقتی غلط می‌شه که
از این سه حلقه غلط باشه. گزینه‌ی C دقیقاً حلقه‌ی دوم رو نقض می‌کنه.
حداقل یکی
چی حواس‌پرت‌کنه؟
گزینه‌ی D اطلاعات جدیدیه که اصلاً داخل گزاره‌ی اصلی نیست — درست بودنش هیچ تاثیری روی درستی سه حلقه‌ی موجود نداره. گزینه‌های A و B هر دو حلقه‌هایی رو تایید می‌کنن، نه رد؛ برای همین گزاره رو غلط نمی‌کنن.
چرا این روش مطمئن‌تره؟
چون قانون عطف می‌گه «فقط یک حلقه‌ی غلط کافیه»، لازم نیست هر سه حلقه رو کامل بررسی کنی — کافیه دنبال گزینه‌ای بگردی که دقیقاً یکی از حلقه‌های موجود رو نقض کنه.
🎯 EXAM TIP
هر وقت کلمات
رو دیدی، فوراً توی ذهنت جایگزینش کن با «and». این کلمات فقط برای طبیعی‌تر شدن جمله‌ی انگلیسی استفاده می‌شن، هیچ تاثیری روی منطق ندارن.
but, however, although, yet
⚡ QUICK METHOD
برای رد کردن سریع یک گزاره‌ی عطفی، دنبال
بگرد و همون‌جا متوقف شو — نیازی نیست بقیه‌ی حلقه‌ها رو چک کنی، چون یک «False» کافیه که کل گزاره False بشه.
اولین حلقه‌ی غلط
⚠️ COMMON MISTAKES
فکر کردن به اینکه کلمه‌ی «but» یعنی یک استثنا یا نفی در ساختار منطقی وجود داره.
اشتباه:
در زبان روزمره، «but» حس تضاد می‌ده و داوطلب ناخودآگاه فکر می‌کنه یعنی یک طرف باید غلط باشه یا یک رابطه‌ی متفاوت از «and» در کاره.
چرا اتفاق می‌افته:
همیشه اول «but/however/although» رو با «and» جایگزین کن و بعد جمله رو تحلیل کن. اگه این جایگزینی معنی جمله رو عوض نکرد (که هیچ‌وقت از نظر منطقی عوض نمی‌کنه)، خیالت راحت باشه که با یک عطف ساده روبرویی.
چطور جلوش رو بگیریم:
🪤 QUESTION TRAP
در سوالات با عطف زنجیره‌ای بلند (سه، چهار یا پنج حلقه)، آزمون گزینه‌هایی می‌ذاره که فقط
حلقه‌ها رو درست فرض می‌کنن و ادعا می‌کنن کل گزاره «تقریباً درسته» یا «بیشترش درسته». این تله‌ست — در منطق گزاره‌ای، درستیِ نسبی وجود نداره؛ یا همه‌ی حلقه‌ها درستن (کل گزاره True) یا حداقل یکی غلطه (کل گزاره False).
بعضی
🧠 MUST REMEMBER
عطف فقط در یک حالت درسته:
. کلمات
منطقاً همون «and» هستن. جمله‌های با فاعل مشترک رو قبل از تحلیل به گزاره‌های جدا باز کن.
همه‌ی طرف‌ها درست باشن
but, however, although, yet

## 📝تمرین

Section ID: `BBB6AF83-C430-646E-5A03-6BC1E58F38B0`

Import key: `logic/ch02-conjunction.html#section-07`

Topic ID: `A522AA4A-B71F-2AAA-D401-3E013834F716`

Source: [logic/ch02-conjunction.html](../../../database-sources/logic/00E861CC-37A3-973A-EB9F-622250C58294.html) — ID `00E861CC-37A3-973A-EB9F-622250C58294`

📝
تمرین
آسان
"Ana plays the violin and the piano." Ana plays the violin (True). Ana does NOT play the piano (False). What is the truth value of the whole claim?
A) True
B) False
C) Cannot be determined
D) Depends on which instrument is mentioned first
نمایش پاسخ و توضیح
پاسخ درست: B.
«Ana plays the violin and the piano» یعنی «Ana plays the violin AND Ana plays the piano». چون بخش دوم غلطه، طبق جدول درستی «and»، کل گزاره غلط می‌شه — فارغ از اینکه بخش اول درست باشه.
متوسط
"The flight departed on time, but it landed late." Which pair of truth values for the two parts makes this whole claim TRUE?
A) Departed on time = False, Landed late = True
B) Departed on time = True, Landed late = True
C) Departed on time = True, Landed late = False
D) Departed on time = False, Landed late = False
نمایش پاسخ و توضیح
پاسخ درست: B.
«but» اینجا منطقاً «and» است، پس گزاره «Departed on time AND Landed late» است. طبق جدول درستی «and»، تنها حالتی که کل گزاره True می‌شه وقتیه که
هر دو
بخش True باشن. گزینه‌های دیگه هر کدوم حداقل یک بخش را False دارن.
سخت
"Omar finished the report, submitted it on time, and informed his manager, but he forgot to attach the appendix." Exactly one of the four sub-claims in this sentence is false. Is the whole claim true or false, and why?
A) True, because most of the sub-claims are true
B) False, because it is a conjunction and one sub-claim is false
C) True, because "but" cancels out the earlier claims
D) Cannot be determined without knowing which sub-claim is false
نمایش پاسخ و توضیح
پاسخ درست: B.
این جمله چهار جزء عطفی دارد: گزارش را تمام کرد، به‌موقع تحویل داد، مدیر را مطلع کرد و فراموش کرد پیوست را اضافه کند. اگر دقیقاً یکی از همین چهار گزارهٔ بیان‌شده غلط باشد، کل عطف غلط است. نمی‌توان از عبارت «فراموش کرد» نتیجه گرفت که خودِ گزارهٔ چهارم غلط است؛ گزارهٔ چهارم همان فراموش‌کردن است.

## 🚀مرور سریع — فصل ۲

Section ID: `E6693FC7-058C-355E-B7CE-AB1DE6D1BCF4`

Import key: `logic/ch02-conjunction.html#section-08`

Topic ID: `A522AA4A-B71F-2AAA-D401-3E013834F716`

Source: [logic/ch02-conjunction.html](../../../database-sources/logic/00E861CC-37A3-973A-EB9F-622250C58294.html) — ID `00E861CC-37A3-973A-EB9F-622250C58294`

مرور سریع — فصل ۲
🚀
مفاهیم اصلی
عطف فقط وقتی درسته که همه‌ی طرف‌هاش درست باشن.
منطقاً همون «and» هستن.
but, however, although, yet
جمله‌های با فاعل مشترک باید به گزاره‌های جدا باز بشن.
روش
همه‌ی حلقه‌های عطف — حتی پنهان‌شده‌ها — رو پیدا کن.
دنبال یک حلقه‌ی غلط بگرد؛ همون کافیه.
عطف زنجیره‌ای هم همون قانون رو داره، با هر تعداد حلقه.
اشتباهات رایج
فکر کردن به «but» به‌عنوان یک استثنای منطقی.
قبول کردن «تقریباً درست» به‌جای «کاملاً درست».
دام‌های تستی
گزینه‌هایی که ادعای درستیِ نسبی می‌کنن.
عطف‌های زنجیره‌ای بلند که حواس‌پرتی ایجاد می‌کنن.
