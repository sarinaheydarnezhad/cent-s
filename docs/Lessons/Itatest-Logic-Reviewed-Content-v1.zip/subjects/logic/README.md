# Logic and data interpretation — منطق و تحلیل داده

Chapter folders preserve original order and IDs.

- [فصل ۱: مبانی — گزاره چیست؟ گزاره‌های ترکیبی چه هستند؟](001-ch01-foundations-fa-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۲: عطف — «A and B» (Conjunction)](002-ch02-conjunction-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۳: فصل — «A or B» (Disjunction)](003-ch03-disjunction-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۴: شرطی — «If A then B» (Conditional)](004-ch04-conditional-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۵: نقیض و تضاد — «not-A» (Negation, Contradictories & Contraries)](005-ch05-negation-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۶: سازگاری و ناسازگاری — Consistency vs Inconsistency](006-ch06-consistency-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۷: نقیض گزاره‌های ترکیبی (De Morgan's Rules)](007-ch07-negating-compounds-chapter/): 9 lesson sections, 4 questions, 3 exercises.
- [فصل ۸: معادل‌های شرطی — Equivalent Forms of "If A then B"](008-ch08-equivalents-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۹: شرط لازم و کافی — Necessary and Sufficient Conditions](009-ch09-necessary-sufficient-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۱۰: گزاره‌های قیاسی — Categorical Claims (All / Some / No / Only A are B)](010-ch10-categorical-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۱۱: مربع تعارض — Square of Opposition](011-ch11-square-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۱۲: قیاس فرضی و Modus Ponens — استنتاج معتبر و نامعتبر](012-ch12-syllogism-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۱۳: نقیض گزاره‌های کمّی — Negating Universal & Existential Statements](013-ch13-quantifiers-chapter/): 9 lesson sections, 2 questions, 3 exercises.
- [فصل ۱۴: خواندن نمودارهای میله‌ای — Reading Bar Charts](014-ch14-barcharts-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۱۵: خواندن نمودارهای دایره‌ای — Reading Pie Charts](015-ch15-piecharts-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۱۶: نمودارهای خطی و تحلیل روند — Line Graphs & Trend Analysis](016-ch16-linegraphs-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۱۷: نتیجه‌گیری و ارزیابیِ ادعاها — Drawing Conclusions & Evaluating Claims](017-ch17-evaluating-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۱۸: حل مسئله با نمودار ون — Venn Diagram Word Problems](018-ch18-venn-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [فصل ۱۹: حل مسئله با جدول و معادلات همزمان — Tables & Simultaneous Equations](019-ch19-tables-chapter/): 9 lesson sections, 3 questions, 3 exercises.
- [🧠 Logic Cheat Sheet — چکیده‌ی فشرده‌ی کل جزوه](020-20-final-review-chapter/): 3 lesson sections, 3 questions, 0 exercises.
- [مبانی و تکمیل سرفصل CEnT-S — logic](100-updates-2026-r1-chapter/): 3 lesson sections, 15 questions, 15 exercises.
- [مبانی و تکمیل سرفصل CEnT-S — logic](100-updates-2026-r2-chapter/): 1 lesson sections, 4 questions, 4 exercises.

`frontend-samples/` contains separate original frontend demo questions when present. `documents/` holds source document metadata. Reading shared texts and linked keys are in `passages/`.
