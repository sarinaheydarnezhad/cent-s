# فصل ۶: سازگاری و ناسازگاری — Consistency vs Inconsistency

Original chapter ID: `6E29F749-DB18-E639-6B1E-C3267756CD3C`

Original chapter import key: `logic/ch06-consistency.html#chapter`

## فصل ۶: سازگاری و ناسازگاری — Consistency vs Inconsistency

Section ID: `4C4A6744-A7C3-2187-9CAD-1CFF5F9B701F`

Import key: `logic/ch06-consistency.html#intro`

Topic ID: `3ED40B21-22E2-6A14-B51E-3E262A7F226C`

Source: [logic/ch06-consistency.html](../../../database-sources/logic/C818184C-3433-4055-C8C4-041F88038CB4.html) — ID `C818184C-3433-4055-C8C4-041F88038CB4`

CENT LOGIC — PART A · CHAPTER 6 / 13
فصل ۶: سازگاری و ناسازگاری — Consistency vs Inconsistency
حالا که با تناقض («A and not-A») آشنا شدی، وقتشه یاد بگیری چطور بفهمی چند گزاره‌ی کنار هم، جمعاً یک تناقض می‌سازن یا نه — حتی وقتی هیچ دوتاشون به‌تنهایی متناقض به‌نظر نمی‌رسن.

## Bاین مبحث چیست؟

Section ID: `B083ABEF-DB8D-BF2E-BF5D-E9AE57F51D74`

Import key: `logic/ch06-consistency.html#section-01`

Topic ID: `3ED40B21-22E2-6A14-B51E-3E262A7F226C`

Source: [logic/ch06-consistency.html](../../../database-sources/logic/C818184C-3433-4055-C8C4-041F88038CB4.html) — ID `C818184C-3433-4055-C8C4-041F88038CB4`

این مبحث چیست؟
B
وقتی آزمون چند گزاره رو با هم بهت می‌ده، ازت می‌خواد بگی آیا ممکنه
یا نه. اگه ممکن باشه، مجموعه
؛ اگه نشه — یعنی پذیرفتنشون با هم اجباراً به یک تناقض ختم بشه — مجموعه
.
همه‌شون هم‌زمان درست باشن
سازگاره (consistent)
ناسازگاره (inconsistent)

## Cمفهوم اصلی

Section ID: `DF011C8B-990C-A1CA-6755-C9FAE92E476E`

Import key: `logic/ch06-consistency.html#section-02`

Topic ID: `3ED40B21-22E2-6A14-B51E-3E262A7F226C`

Source: [logic/ch06-consistency.html](../../../database-sources/logic/C818184C-3433-4055-C8C4-041F88038CB4.html) — ID `C818184C-3433-4055-C8C4-041F88038CB4`

مفهوم اصلی
C
«ممکن بودن» یعنی «به یک تناقض ختم نمی‌شه» — یعنی نمی‌تونی از ترکیبشون یک گزاره به فرم «A and not-A» بسازی.
قدم ۱ — تعریف: یک مجموعه از گزاره‌ها سازگاره اگه از نظر منطقی ممکن باشه همه‌شون هم‌زمان درست باشن.
قدم ۲ — مثال سازگار.
نمونه
1. All humans are mortal.
2. Simon is immortal.
این دو گزاره با هم سازگارن — چون ممکنه سایمون اصلاً انسان نباشه (مثلاً یک شخصیت افسانه‌ای یا خدا باشه). هیچ تناقضی از ترکیبشون به‌دست نمیاد.
قدم ۳ — مثال ناسازگار مستقیم.
نمونه
1. All humans are mortal.
2. Some humans are not mortal.
این دو مستقیماً همدیگه رو نقض می‌کنن — گزاره‌ی دوم دقیقاً نقیض گزاره‌ی اوله (این رو در فصل ۱۰ به‌طور کامل با عنوان «نقیض All A are B» می‌بینیم). هیچ راهی نیست که هر دو هم‌زمان درست باشن.
قدم ۴ — نکته‌ی مهم‌تر: ناسازگاری می‌تونه از ترکیبِ چند گزاره پدید بیاد، حتی وقتی هیچ دوتاشون به‌تنهایی متناقض نیستن.
نمونه
1. All humans are mortal.
2. Simon is immortal.
3. Simon is human.
این‌بار همون دو گزاره‌ی قدم ۲ رو داریم، ولی یک گزاره‌ی سوم («Simon is human») بهشون اضافه شده. حالا از گزاره‌های ۱ و ۳ نتیجه می‌گیریم «Simon is mortal» — که مستقیماً با گزاره‌ی ۲ («Simon is immortal») در تناقضه. این مجموعه، برخلاف قدم ۲،
. اضافه شدن فقط یک گزاره‌ی به‌ظاهر بی‌ضرر، کل مجموعه رو ناسازگار کرد.
ناسازگاره
در مثال قدم ۴، فقط می‌دونیم
از این سه گزاره غلطه؛ نمی‌تونیم بدون اطلاعات بیرونی بگیم دقیقاً کدوم‌یکی.
قدم ۵ — نکته‌ی مهم: اگه یک مجموعه ناسازگار باشه، حداقل یکی از گزاره‌هاش باید غلط باشه — ولی خودِ منطق نمی‌گه کدومش.
حداقل یکی

## Dقوانین و اصول مهم

Section ID: `795C0061-FAB4-FA19-EA06-CE9FD71DFF50`

Import key: `logic/ch06-consistency.html#section-03`

Topic ID: `3ED40B21-22E2-6A14-B51E-3E262A7F226C`

Source: [logic/ch06-consistency.html](../../../database-sources/logic/C818184C-3433-4055-C8C4-041F88038CB4.html) — ID `C818184C-3433-4055-C8C4-041F88038CB4`

قوانین و اصول مهم
D
سازگار (consistent) = ممکنه همه هم‌زمان درست باشن (به تناقض ختم نمی‌شه).
ناسازگار (inconsistent) = پذیرفتن همه‌شون با هم اجباراً یک تناقض می‌سازه.
یک مجموعه می‌تونه در نگاه دوتایی سازگار به‌نظر برسه، ولی با اضافه شدن یک گزاره‌ی سوم ناسازگار بشه — همیشه ترکیب کامل رو چک کن، نه فقط جفت‌ها رو.
ناسازگاری فقط می‌گه «حداقل یکی غلطه»، نه اینکه کدوم‌یکی.

## Eروش حل

Section ID: `8CED1B9D-017D-0CC7-8DB1-C90687E040AF`

Import key: `logic/ch06-consistency.html#section-04`

Topic ID: `3ED40B21-22E2-6A14-B51E-3E262A7F226C`

Source: [logic/ch06-consistency.html](../../../database-sources/logic/C818184C-3433-4055-C8C4-041F88038CB4.html) — ID `C818184C-3433-4055-C8C4-041F88038CB4`

روش حل
E
همه‌ی گزاره‌های مجموعه رو فهرست کن.
دنبال تناقض مستقیم بین هر دو گزاره بگرد (مثل «All A are B» و «Some A are not B»).
اگه تناقض مستقیمی پیدا نکردی، ببین آیا می‌تونی با ترکیبِ چند گزاره (مثل یک قیاس ساده) یک نتیجه بسازی که با یکی از گزاره‌های دیگه در تناقض باشه.
اگه به هر طریقی به یک «A and not-A» رسیدی، مجموعه ناسازگاره؛ در غیر این صورت سازگاره.
→ جواب: سازگار یا ناسازگار.

## Fمثال آموزشی

Section ID: `6C1EE1B1-05FC-F41A-3230-27ECF7601601`

Import key: `logic/ch06-consistency.html#section-05`

Topic ID: `3ED40B21-22E2-6A14-B51E-3E262A7F226C`

Source: [logic/ch06-consistency.html](../../../database-sources/logic/C818184C-3433-4055-C8C4-041F88038CB4.html) — ID `C818184C-3433-4055-C8C4-041F88038CB4`

مثال آموزشی
F
Example 1 — برای درک مفهوم
Is the following set consistent? "1. No cats are reptiles. 2. Whiskers is a cat. 3. Whiskers is not a reptile."
از گزاره‌های ۱ و ۲ نتیجه می‌گیریم «Whiskers is not a reptile» — که دقیقاً همون گزاره‌ی ۳ است، نه نقیضش. هیچ تناقضی ساخته نمی‌شه؛ هر سه گزاره کاملاً می‌تونن هم‌زمان درست باشن.
پاسخ: سازگاره.

## Gمثال امتحانی

Section ID: `EF9D7E66-5CE1-D52C-6EA5-20B7BF8B85DB`

Import key: `logic/ch06-consistency.html#section-06`

Topic ID: `3ED40B21-22E2-6A14-B51E-3E262A7F226C`

Source: [logic/ch06-consistency.html](../../../database-sources/logic/C818184C-3433-4055-C8C4-041F88038CB4.html) — ID `C818184C-3433-4055-C8C4-041F88038CB4`

مثال امتحانی
G
Example 2 — CEnT style
Consider the set: "1. All members of the committee voted yes. 2. Anna is a member of the committee. 3. Anna voted no." Is this set consistent or inconsistent?
A) Consistent, because each statement is independently plausible.
B) Inconsistent, because statements 1 and 2 together entail "Anna voted yes," which contradicts statement 3.
C) Cannot be determined without knowing the actual vote count.
D) Consistent, because "voted no" and "voted yes" are only contraries, not contradictories.
از کجا شروع کنیم؟
اول ببین آیا هر دو گزاره به‌تنهایی با هم تناقض دارن یا نه — گزاره‌های ۱ و ۲ به‌تنهایی مشکلی ندارن. حالا ببین آیا ترکیبشون چیزی می‌سازه که با گزاره‌ی ۳ تناقض داشته باشه.
چه اطلاعاتی مهمه؟
از گزاره‌های ۱ («همه‌ی اعضا رأی بله دادن») و ۲ («آنا عضو کمیته‌ست») نتیجه می‌گیریم «آنا رأی بله داده». این نتیجه مستقیماً با گزاره‌ی ۳ («آنا رأی نه داده») در تناقضه.
چی حواس‌پرت‌کنه؟
گزینه‌ی A فقط گزاره‌ها رو تک‌تک و مجزا بررسی کرده، بدون ترکیب کردنشون — دقیقاً همون اشتباهی که این فصل هشدارش رو می‌ده. گزینه‌ی D اشتباه می‌کنه چون «voted yes» و «voted no» درباره‌ی یک نفر و یک رأی، دقیقاً نقیض همن (نه صرفاً تضاد) — کسی نمی‌تونه هم‌زمان هم بله رأی بده هم نه.
چرا این روش مطمئن‌تره؟
چون به‌جای قضاوت شهودی («به‌نظر همه‌چی درسته»)، مستقیماً یک استنتاج منطقی از دو گزاره ساختیم و اون رو با گزاره‌ی سوم مقایسه کردیم — دقیقاً همون روش قدم ۴ در بخش مفهوم اصلی.
🎯 EXAM TIP
وقتی سه یا چند گزاره باهم دادن، هیچ‌وقت فقط جفت‌به‌جفت چکشون نکن. سعی کن اول ببینی آیا از ترکیب دو گزاره می‌تونی یک نتیجه‌ی جدید بسازی (مثل یک قیاس ساده «All A are B» + «X is A» ⇒ «X is B»)، و بعد اون نتیجه رو با گزاره‌های باقی‌مونده مقایسه کن.
⚡ QUICK METHOD
یک الگوی خیلی رایج برای ناسازگاری مستقیم: هر وقت یک گزاره‌ی کلی («All A are B» یا «No A are B») در کنار یک گزاره‌ی جزئیِ متناقض («Some A are not B» یا «Some A are B») ظاهر بشه، بلافاصله بدون تحلیل بیشتر بدون مجموعه ناسازگاره. جزئیات کامل این الگوها در فصل ۱۰ و ۱۱ (منطق قیاسی و مربع تعارض) میاد.
⚠️ COMMON MISTAKES
بررسی هر گزاره به‌طور مجزا و نتیجه‌گیری که چون هیچ‌کدوم به‌تنهایی «غیرممکن» به‌نظر نمی‌رسه، پس کل مجموعه سازگاره.
اشتباه:
ذهن آدم به‌طور طبیعی گزاره‌ها رو یکی‌یکی می‌خونه و ارزیابی می‌کنه، نه اینکه به‌طور فعال دنبال ترکیبی از دو یا چند گزاره بگرده که یک نتیجه‌ی متناقض بسازه.
چرا اتفاق می‌افته:
همیشه از خودت بپرس: «اگه دو گزاره‌ی اول رو با هم قبول کنم، به چه نتیجه‌ی جدیدی می‌رسم؟ آیا اون نتیجه با بقیه‌ی گزاره‌ها جور در میاد؟»
چطور جلوش رو بگیریم:
🪤 QUESTION TRAP
گاهی سؤال می‌پرسه «کدوم گزاره، اگه حذف بشه، مجموعه رو سازگار می‌کنه؟» این با پرسیدن «مجموعه سازگاره یا نه؟» فرق داره — اینجا باید مشخص کنی دقیقاً کدوم گزاره «متهم اصلی» ناسازگاریه. یادت باشه طبق قدم ۵، خودِ منطق به‌تنهایی نمی‌گه کدوم گزاره غلطه؛ باید ببینی حذف کدوم گزاره، تناقض رو از بین می‌بره.
🧠 MUST REMEMBER
سازگار = ممکنه همه هم‌زمان درست باشن. ناسازگار = ترکیبشون یک تناقض می‌سازه. همیشه ترکیب گزاره‌ها رو چک کن، نه فقط هر گزاره رو تنها. ناسازگاری فقط می‌گه «حداقل یکی غلطه»، نه اینکه دقیقاً کدوم.

## 📝تمرین

Section ID: `2E98751C-F013-D7F7-5BB8-A8A862D4D758`

Import key: `logic/ch06-consistency.html#section-07`

Topic ID: `3ED40B21-22E2-6A14-B51E-3E262A7F226C`

Source: [logic/ch06-consistency.html](../../../database-sources/logic/C818184C-3433-4055-C8C4-041F88038CB4.html) — ID `C818184C-3433-4055-C8C4-041F88038CB4`

📝
تمرین
آسان
Is the set consistent or inconsistent? "1. No birds can swim underwater for more than an hour. 2. Penguins can swim underwater for more than an hour."
A) Inconsistent, if penguins are considered birds.
B) Consistent, because penguins are unusual birds.
C) Consistent, because statement 1 only refers to "most" birds.
D) Cannot be determined.
نمایش پاسخ و توضیح
پاسخ درست: A.
اگه پنگوئن رو یک پرنده در نظر بگیریم، گزاره‌ی ۲ مستقیماً گزاره‌ی ۱ («No birds…») رو نقض می‌کنه — چون گزاره‌ی ۱ می‌گه هیچ پرنده‌ای نمی‌تونه، ولی گزاره‌ی ۲ می‌گه یک نوع پرنده (پنگوئن) می‌تونه. گزینه‌ی C اشتباهه چون گزاره‌ی ۱ کلمه‌ی «No» (یعنی هیچ) رو به‌کار برده، نه «most» (بیشتر).
متوسط
Is the set consistent or inconsistent? 1. Every student in the class passed the exam. 2. Tom is in the class. 3. Tom did not pass the exam.
A) Consistent — Tom is an exception allowed by premise 1.
B) Inconsistent — premises 1 and 2 entail that Tom passed, contradicting premise 3.
C) Consistent — premise 1 says only some students passed.
D) Cannot be determined without knowing Tom’s score.
نمایش پاسخ و توضیح
پاسخ درست: B.
از گزاره‌های ۱ و ۲ به‌طور مستقیم نتیجه می‌گیریم تام قبول شده است. گزارهٔ ۳ نقیض همین نتیجه است. بنابراین هیچ حالتی وجود ندارد که هر سه گزاره هم‌زمان درست باشند. گزینهٔ B صحیح است.
سخت
A set contains: "1. If it rained last night, the streets are wet. 2. It rained last night. 3. The streets are not wet." Is this set consistent or inconsistent?
A) Consistent — it's possible for rain not to make streets wet under some conditions.
B) Inconsistent — statements 1 and 2 together entail "the streets are wet," which contradicts statement 3.
C) Cannot be determined without visiting the location.
D) Consistent — statement 1 and statement 3 are only contraries, not contradictories.
نمایش پاسخ و توضیح
پاسخ درست: B.
از گزاره‌های ۱ و ۲ — یک شرطی به‌همراه تأیید مقدمش — طبق قانون Modus Ponens (که در فصل ۱۲ کامل می‌بینیمش) نتیجه می‌گیریم «the streets are wet». این نتیجه مستقیماً نقیض گزاره‌ی ۳ است. طبق تعریف نقیض در فصل ۵، «wet» و «not wet» دقیقاً یکی درست و یکی غلطن (contradictory)، نه فقط contrary — پس گزینه‌ی D رد می‌شه. گزینه‌ی A هم واقعیت بیرونی رو قاطی منطق درونیِ خودِ سه گزاره کرده؛ درون این سیستم بسته، اگه ۱ و ۲ رو بپذیریم، دیگه راهی برای درست بودن ۳ باقی نمی‌مونه.

## 🚀مرور سریع — فصل ۶

Section ID: `9EC5B052-848D-FCFE-6051-AE4B7DFDC04C`

Import key: `logic/ch06-consistency.html#section-08`

Topic ID: `3ED40B21-22E2-6A14-B51E-3E262A7F226C`

Source: [logic/ch06-consistency.html](../../../database-sources/logic/C818184C-3433-4055-C8C4-041F88038CB4.html) — ID `C818184C-3433-4055-C8C4-041F88038CB4`

مرور سریع — فصل ۶
🚀
مفاهیم اصلی
سازگار = ممکنه همه هم‌زمان درست باشن.
ناسازگار = ترکیبشون یک تناقض می‌سازه.
ناسازگاری می‌تونه از ترکیب چند گزاره پدید بیاد، نه فقط از یک جفت.
روش
دنبال تناقض مستقیم بین جفت‌ها بگرد.
اگه نبود، سعی کن از ترکیب گزاره‌ها یک نتیجه‌ی جدید بسازی.
اشتباهات رایج
بررسی مجزای هر گزاره بدون ترکیب کردنشون.
فرض کردن که همه‌ی محدودیت‌های دنیای واقعی، تناقض منطقی‌ان.
دام‌های تستی
پرسیدن «کدوم گزاره باعث ناسازگاریه؟» به‌جای «سازگاره یا نه؟».
الگوی کلی + جزئیِ متناقض (فصل ۱۰-۱۱).
