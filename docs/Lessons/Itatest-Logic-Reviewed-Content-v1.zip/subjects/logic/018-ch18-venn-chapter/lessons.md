# فصل ۱۸: حل مسئله با نمودار ون — Venn Diagram Word Problems

Original chapter ID: `9F2CE0B5-0DA0-FF1F-2EEA-B4FBAD480B30`

Original chapter import key: `logic/ch18-venn.html#chapter`

## فصل ۱۸: حل مسئله با نمودار ون — Venn Diagram Word Problems

Section ID: `4234A8D9-23F8-A230-D416-E3A36D8BC076`

Import key: `logic/ch18-venn.html#intro`

Topic ID: `8A081DCC-ADFE-58E5-D694-D5202EBB0344`

Source: [logic/ch18-venn.html](../../../database-sources/logic/A6FED340-4FB2-DF1A-F925-63D5D5223CF5.html) — ID `A6FED340-4FB2-DF1A-F925-63D5D5223CF5`

CENT LOGIC — PART B · CHAPTER 18 / 19
فصل ۱۸: حل مسئله با نمودار ون — Venn Diagram Word Problems
این فصل یکی از پرتکرارترین الگوهای مسئله‌ی کلامیِ آزمونه: دو گروه که با هم هم‌پوشانی دارن، به‌همراه یک «کل» و یک تعداد «هیچ‌کدام». یک فرمولِ ثابت، همیشه این نوع مسئله رو حل می‌کنه.

## Bاین مبحث چیست؟

Section ID: `7ADB9AD8-F936-273F-953C-205138D1D101`

Import key: `logic/ch18-venn.html#section-01`

Topic ID: `8A081DCC-ADFE-58E5-D694-D5202EBB0344`

Source: [logic/ch18-venn.html](../../../database-sources/logic/A6FED340-4FB2-DF1A-F925-63D5D5223CF5.html) — ID `A6FED340-4FB2-DF1A-F925-63D5D5223CF5`

این مبحث چیست؟
B
وقتی مسئله دو ویژگی (مثلِ «ماشین دارد» و «گوشیِ هوشمند دارد») رو در یک جمعیت توصیف می‌کنه، جمعیت به چهار بخش تقسیم می‌شه: فقط A، فقط B، هر دو، و هیچ‌کدام. نمودار ون
این چهار بخش رو به‌صورت بصری نشون می‌ده.
(Venn diagram)
A
B
Only A
Only B
Both
Neither (outside both circles)

## Cمفهوم اصلی

Section ID: `25F9EE36-94D3-4433-3963-802E1D12AFEF`

Import key: `logic/ch18-venn.html#section-02`

Topic ID: `8A081DCC-ADFE-58E5-D694-D5202EBB0344`

Source: [logic/ch18-venn.html](../../../database-sources/logic/A6FED340-4FB2-DF1A-F925-63D5D5223CF5.html) — ID `A6FED340-4FB2-DF1A-F925-63D5D5223CF5`

مفهوم اصلی
C
یا به‌شکلِ مفیدتر برای حل مسئله:
.
قدم ۱ — فرمول پایه: کل = (فقط A) + (فقط B) + (هر دو) + (هیچ‌کدام).
|A| + |B| − (هر دو) = کل − (هیچ‌کدام)
قدم ۲ — مثالِ کامل، قدم‌به‌قدم.
نمونه
In a residential complex, 100 families live. 60 families have a car. 80 families have a smartphone. 10 families have neither a car nor a smartphone. How many families have both?
تعدادِ خانواده‌هایی که حداقل یکی از این دو رو دارن: ۱۰۰ − ۱۰ = ۹۰.
فرض کن تعدادِ خانواده‌هایی که هر دو رو دارن، x باشه.
طبقِ فرمول: ۶۰ + ۸۰ − x = ۹۰
حل: ۱۴۰ − x = ۹۰ ⟹ x = ۵۰
پاسخ: ۵۰ خانواده هم ماشین دارن، هم گوشیِ هوشمند.
قدم ۳ — همون الگو، برای موقعیتِ متفاوت.
نمونه
In a class of 40 students, 25 like football, 20 like volleyball, and 10 like neither. How many students like both sports?
حداقل یکی: ۴۰−۱۰=۳۰. معادله: ۲۵+۲۰−y=۳۰ ⟹ ۴۵−y=۳۰ ⟹ y=۱۵.
پاسخ: ۱۵ نفر به هر دو ورزش علاقه دارن.
قدم ۴ — اگه «هر دو» رو بدن و «هیچ‌کدام» رو بخوان (جهتِ برعکس)، همون فرمول رو فقط برعکس حل کن.

## Dقوانین و اصول مهم — جعبه‌ابزارِ فرمول

Section ID: `11DC1138-AC80-8BD8-CDF0-4E31A625978A`

Import key: `logic/ch18-venn.html#section-03`

Topic ID: `8A081DCC-ADFE-58E5-D694-D5202EBB0344`

Source: [logic/ch18-venn.html](../../../database-sources/logic/A6FED340-4FB2-DF1A-F925-63D5D5223CF5.html) — ID `A6FED340-4FB2-DF1A-F925-63D5D5223CF5`

قوانین و اصول مهم — جعبه‌ابزارِ فرمول
D
می‌دونیم
می‌خوایم
فرمول
Total, |A|, |B|, Neither
Both
Both = |A|+|B|−(Total−Neither)
Total, |A|, |B|, Both
Neither
Neither = Total−(|A|+|B|−Both)
|A|, Both
Only A
Only A = |A| − Both

## Eروش حل

Section ID: `856DE24A-E733-7223-953B-90583A43FC3B`

Import key: `logic/ch18-venn.html#section-04`

Topic ID: `8A081DCC-ADFE-58E5-D694-D5202EBB0344`

Source: [logic/ch18-venn.html](../../../database-sources/logic/A6FED340-4FB2-DF1A-F925-63D5D5223CF5.html) — ID `A6FED340-4FB2-DF1A-F925-63D5D5223CF5`

روش حل
E
چهار مقدارِ کلیدی رو مشخص کن: کل، |A|، |B|، و هیچ‌کدام — ببین کدوم‌یکی مجهوله.
«حداقل یکی» رو با
حساب کن (اگه از قبل داده نشده).
کل − هیچ‌کدام
معادله‌ی اصلی رو بساز:
.
|A| + |B| − هر دو = حداقل یکی
مجهول رو حل کن.
اگه سؤال «فقط A» یا «فقط B» خواست، از «هر دو» که پیدا کردی، اون‌ها رو هم استخراج کن.
→ جواب: مقدارِ خواسته‌شده.

## Fمثال آموزشی

Section ID: `F638B31E-A6BB-EB61-BAFC-850398EB6C81`

Import key: `logic/ch18-venn.html#section-05`

Topic ID: `8A081DCC-ADFE-58E5-D694-D5202EBB0344`

Source: [logic/ch18-venn.html](../../../database-sources/logic/A6FED340-4FB2-DF1A-F925-63D5D5223CF5.html) — ID `A6FED340-4FB2-DF1A-F925-63D5D5223CF5`

مثال آموزشی
F
Example 1 — برای درک مفهوم
A gym has 80 members. 50 attend yoga classes, 35 attend spin classes, and 15 attend both. How many members attend NEITHER class?
حداقل یکی = ۵۰+۳۵−۱۵ = ۷۰. هیچ‌کدام = ۸۰−۷۰ =
. اینجا برعکسِ نمونه‌های قبلی، «هر دو» رو داشتیم و «هیچ‌کدام» رو پیدا کردیم.
حل:
۱۰ نفر

## Gمثال امتحانی

Section ID: `EC25B284-6B60-B8B0-6A39-5CF6130426C0`

Import key: `logic/ch18-venn.html#section-06`

Topic ID: `8A081DCC-ADFE-58E5-D694-D5202EBB0344`

Source: [logic/ch18-venn.html](../../../database-sources/logic/A6FED340-4FB2-DF1A-F925-63D5D5223CF5.html) — ID `A6FED340-4FB2-DF1A-F925-63D5D5223CF5`

مثال امتحانی
G
Example 2 — CEnT style
A survey of 150 tourists found that 90 visited the museum, 70 visited the beach, and 40 visited both. How many tourists visited NEITHER the museum nor the beach?
A) 20
B) 30
C) 40
D) 50
از کجا شروع کنیم؟
مشخص کن چی داریم: Total=150, |Museum|=90, |Beach|=70, Both=40. مجهول: Neither.
چه اطلاعاتی مهمه؟
اول «حداقل یکی» رو با فرمولِ شمول-عدم‌شمول حساب کن: ۹۰+۷۰−۴۰ = ۱۲۰. بعد: هیچ‌کدام = ۱۵۰−۱۲۰ = ۳۰.
چی حواس‌پرت‌کنه؟
گزینه‌ی C دقیقاً برابرِ عددِ «Both» است — یک عددِ دیگرِ صورتِ سؤال که ممکنه با هیچ‌کدام قاطی بشه. گزینه‌ی D هم از فراموش کردنِ کم کردنِ «Both» به‌دست میاد (۹۰+۷۰=۱۶۰، ۱۵۰−۱۶۰ منفی می‌شه که غیرممکنه، ولی اگه کسی اشتباهاً ۱۶۰−۱۵۰=۱۰ رو با یک محاسبه‌ی دیگه قاطی کنه به ۵۰ می‌رسه).
چرا این روش مطمئن‌تره؟
چون به‌جای حدس زدن، مستقیم از جعبه‌ابزارِ فرمولِ قدم ۴ (ردیفِ دوم جدول) استفاده کردیم.
🎯 EXAM TIP
همیشه یک نمودارِ ونِ ساده (دو دایره‌ی هم‌پوشان داخلِ یک مستطیل) روی کاغذ بکش و بلافاصله هر عددی که می‌دونی رو داخلش بنویس. حتی اگه مجبور باشی مجهول رو با یک حرف (مثلِ x) نشون بدی، دیدنِ بصریِ مسئله از اشتباهاتِ محاسباتی جلوگیری می‌کنه.
⚡ QUICK METHOD
فرمولِ فشرده رو حفظ کن:
. هر سه مقدارِ دیگه رو که داشته باشی، مجهولِ چهارم رو مستقیم از همین یک معادله به‌دست میاری — نیازی به نوشتنِ مراحلِ جدا نیست.
کل − هیچ‌کدام = |A| + |B| − هر دو
⚠️ COMMON MISTAKES
جمع زدنِ مستقیمِ |A| و |B| بدون کم کردنِ «هر دو» — یعنی فرض کردنِ اینکه این دو گروه هیچ هم‌پوشانی‌ای ندارن.
اشتباه:
وقتی دو عددِ جدا (مثلِ «۶۰ ماشین‌دار» و «۸۰ گوشی‌دار») می‌بینیم، ذهن به‌طور طبیعی سعی می‌کنه فقط جمعشون بزنه، بدون توجه به این‌که بعضی خانواده‌ها ممکنه در هر دو گروه باشن (پس دوبار شمرده می‌شن).
چرا اتفاق می‌افته:
همیشه فرمولِ کاملِ شمول-عدم‌شمول رو به‌کار ببر:
، نه فقط
.
چطور جلوش رو بگیریم:
|A|+|B|−هر دو
|A|+|B|
🪤 QUESTION TRAP
گاهی سؤال به‌جای |A| و |B| کامل، مستقیماً «فقط A» و «فقط B» رو می‌ده (بدون احتسابِ هم‌پوشانی). اگه این رو با |A| و |B| کامل اشتباه بگیری و مستقیم در فرمولِ شمول-عدم‌شمول جایگذاری کنی، هم‌پوشانی رو دوبار کم می‌کنی. همیشه دقت کن آیا عددی که دادن شاملِ هم‌پوشانی هست یا نه.
🧠 MUST REMEMBER
.
. همیشه اول یک نمودارِ ون بکش و اعدادِ داده‌شده رو داخلش بنویس.
کل = فقط A + فقط B + هر دو + هیچ‌کدام
کل − هیچ‌کدام = |A| + |B| − هر دو

## 📝تمرین

Section ID: `39FCBB71-6F95-15F2-E8E0-5CCA07D04662`

Import key: `logic/ch18-venn.html#section-07`

Topic ID: `8A081DCC-ADFE-58E5-D694-D5202EBB0344`

Source: [logic/ch18-venn.html](../../../database-sources/logic/A6FED340-4FB2-DF1A-F925-63D5D5223CF5.html) — ID `A6FED340-4FB2-DF1A-F925-63D5D5223CF5`

تمرین
📝
آسان
In a group of 60 people, 35 speak English, 30 speak French, and 10 speak neither. How many speak both languages?
A) 5
B) 15
C) 20
D) 25
نمایش پاسخ و توضیح
حداقل یکی = ۶۰−۱۰=۵۰. معادله: ۳۵+۳۰−x=۵۰ ⟹ ۶۵−x=۵۰ ⟹ x=۱۵.
پاسخ درست: B.
متوسط
A company has 120 employees. 70 work remotely at least one day a week, 55 use a company car, and 25 do both. How many employees do NEITHER (never work remotely AND never use a company car)?
A) 5
B) 10
C) 20
D) 30
نمایش پاسخ و توضیح
حداقل یکی = ۷۰+۵۵−۲۵=۱۰۰. هیچ‌کدام = ۱۲۰−۱۰۰=۲۰.
پاسخ درست: C.
سخت
In a survey of 200 people, 45 like ONLY tea (not coffee), 60 like ONLY coffee (not tea), and 35 like neither. How many people like BOTH tea and coffee?
A) 45
B) 55
C) 60
D) 95
نمایش پاسخ و توضیح
اینجا اعدادِ داده‌شده «فقط تی» و «فقط قهوه» هستن، نه |A| و |B| کامل — دقیقاً همون دامِ این فصل. باید از فرمولِ اصلی استفاده کنیم: کل = فقط تی + فقط قهوه + هر دو + هیچ‌کدام. پس: ۲۰۰ = ۴۵ + ۶۰ + هر دو + ۳۵ ⟹ هر دو = ۲۰۰−۱۴۰ = ۶۰.
پاسخ درست: C.

## 🚀مرور سریع — فصل ۱۸

Section ID: `CACFB622-C1BE-9B40-493B-456E164413C4`

Import key: `logic/ch18-venn.html#section-08`

Topic ID: `8A081DCC-ADFE-58E5-D694-D5202EBB0344`

Source: [logic/ch18-venn.html](../../../database-sources/logic/A6FED340-4FB2-DF1A-F925-63D5D5223CF5.html) — ID `A6FED340-4FB2-DF1A-F925-63D5D5223CF5`

مرور سریع — فصل ۱۸
🚀
مفاهیم اصلی
کل = فقط A + فقط B + هر دو + هیچ‌کدام.
کل − هیچ‌کدام = |A| + |B| − هر دو.
روش
چهار مقدارِ کلیدی رو مشخص کن، مجهول رو پیدا کن.
یک نمودارِ ون بکش.
اشتباهات رایج
جمع زدنِ |A|+|B| بدون کم کردنِ هم‌پوشانی.
دام‌های تستی
دادنِ «فقط A»/«فقط B» به‌جای |A|/|B| کامل.
