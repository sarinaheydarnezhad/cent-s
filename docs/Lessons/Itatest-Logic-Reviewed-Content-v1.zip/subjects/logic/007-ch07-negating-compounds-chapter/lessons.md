# فصل ۷: نقیض گزاره‌های ترکیبی (De Morgan's Rules)

Original chapter ID: `85595E57-954D-FCFC-8853-AE13B13CA761`

Original chapter import key: `logic/ch07-negating-compounds.html#chapter`

## فصل ۷: نقیض گزاره‌های ترکیبی (De Morgan's Rules)

Section ID: `8C1E0730-6F75-179E-013A-9BA05FF1DEE1`

Import key: `logic/ch07-negating-compounds.html#intro`

Topic ID: `BC9707DD-B7E7-F2C8-7C16-3910A542358F`

Source: [logic/ch07-negating-compounds.html](../../../database-sources/logic/FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3.html) — ID `FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3`

CENT LOGIC — PART A · CHAPTER 7 / 13 · 🔴 CHALLENGE
فصل ۷: نقیض گزاره‌های ترکیبی (De Morgan's Rules)
تا اینجا یاد گرفتی چطور نقیضِ یک گزاره‌ی ساده رو بسازی. اما وقتی گزاره ترکیبیه (and, or, if…then)، نقیض گرفتن یک قانون خاص و بسیار پرکاربرد داره:
. این یکی از باارزش‌ترین قوانینیه که در کل بخش Logic حفظ می‌کنی.
عملگر عوض می‌شه

## Bاین مبحث چیست؟

Section ID: `CA92E4D5-A181-83E2-A6D9-0CBFBC942E59`

Import key: `logic/ch07-negating-compounds.html#section-01`

Topic ID: `BC9707DD-B7E7-F2C8-7C16-3910A542358F`

Source: [logic/ch07-negating-compounds.html](../../../database-sources/logic/FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3.html) — ID `FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3`

این مبحث چیست؟
B
سؤالات «نقیض این گزاره چیه؟»
در آزمون CEnT خیلی رایجن. وقتی گزاره‌ی اصلی یک عطف، فصل، یا شرطیه، نقیضش با گذاشتن ساده‌ی «not» جلوی کل جمله ساخته نمی‌شه — باید طبق قوانین
بازنویسیش کنی.
(Write the contradictory of...)
De Morgan's Rules

## Cمفهوم اصلی

Section ID: `D8D5FA49-0254-5A37-0B34-4DD2C96A26F3`

Import key: `logic/ch07-negating-compounds.html#section-02`

Topic ID: `BC9707DD-B7E7-F2C8-7C16-3910A542358F`

Source: [logic/ch07-negating-compounds.html](../../../database-sources/logic/FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3.html) — ID `FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3`

C
مفهوم اصلی
قاعده‌های دمورگان در این فصل برای or شمولی هستند. اگر «یا» دقیقاً یکی از دو حالت را مجاز کند (exclusive OR)، نقیض آن هم‌ارزی دو ارزش درستی است: هر دو درست یا هر دو غلط.
قدم ۱ — نقیض مضاعف: not-(not-A) = A.
دو تا «not» پشت سر هم، همدیگه رو خنثی می‌کنن.
نمونه
A = "Sarah makes good coffee."not-A = "Sarah does not make good coffee."not-(not-A) = "Sarah makes good coffee." (= A)
⚠️ هشدار: این قانون فقط وقتی درست کار می‌کنه که واقعاً یک نقیضِ درست ساخته باشی، نه یک contrary (طبق فصل ۵). مثال: اگر گزارهٔ اولیه «Neither Sarah nor Tom went bike riding» باشد، نقیض آن «At least one of Sarah and Tom went bike riding» است؛ نه الزاماً هر دو. برای نقیض مضاعف از گزارهٔ صریح not-(not-A) استفاده کن.
قدم ۲ — نقیض عطف: not-(A and B) = (not-A) or (not-B).
برای غلط کردن یک ادعای «هر دو درست»، کافیه
حداقل یکی
غلط باشه — برای همین نتیجه یک فصل می‌شه.
نمونه
A = "Dan got an A in physics and a B in history."Contradictory = "Either Dan didn't get an A in physics or he didn't get a B in history."
قدم ۳ — نقیض فصل: not-(A or B) = (not-A) and (not-B).
برای غلط کردن یک ادعای «حداقل یکی درست»، باید
هر دو
غلط باشن — برای همین نتیجه یک عطف می‌شه. به این دو قانون (قدم ۲ و ۳) با هم
De Morgan's Rules
می‌گن.
نمونه
A = "Dan will go to law school or become a priest (inclusive OR)."Contradictory = "Dan will not go to law school and he will not become a priest." (= "Dan will neither go to law school nor become a priest.")
قدم ۴ — نقیض شرطی: not-(if A then B) = A and not-B.
یادت باشه از فصل ۴: شرطی فقط در یک حالت غلطه — مقدم درست و تالی غلط. پس نقیضِ شرطی دقیقاً همون یک حالتِ خاصه، به‌فرم یک عطف.
نمونه
A = "If I pay for dinner, then you'll pay for drinks."Contradictory = "I pay for dinner, but you don't pay for drinks."
این تطابق با جدول درستی فصل ۴ کاملاً هم‌خونیه: تنها ردیفی که شرطی رو غلط می‌کنه، دقیقاً همینه.

## Dقوانین و اصول مهم — جدول تبدیل

Section ID: `C1F7A6CA-25CA-C924-A846-79D303143A5C`

Import key: `logic/ch07-negating-compounds.html#section-03`

Topic ID: `BC9707DD-B7E7-F2C8-7C16-3910A542358F`

Source: [logic/ch07-negating-compounds.html](../../../database-sources/logic/FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3.html) — ID `FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3`

D
قوانین و اصول مهم — جدول تبدیل
گزاره‌ی اصلی
نقیضش
not-(not-A)
A
not-(A and B)
(not-A) or (not-B)
not-(A or B)
(not-A) and (not-B)
not-(if A then B)
A and (not-B)
نقیض عطف به فصل شمولی و نقیض فصل شمولی به عطف تبدیل می‌شود — عملگر «عوض» می‌شه.
نقیض یک شرطی، همیشه یک عطفه — و مقدم دست‌نخورده می‌مونه، فقط تالی نقیض می‌شه.
در همه‌ی این قوانین، «not» به‌جای اینکه جلوی کل جمله بمونه، به داخل جمله
پخش می‌شه
و در همین حین عملگر رو عوض می‌کنه.

## Eروش حل

Section ID: `A9EAA9D9-CDE3-803C-B08A-789E8722929E`

Import key: `logic/ch07-negating-compounds.html#section-04`

Topic ID: `BC9707DD-B7E7-F2C8-7C16-3910A542358F`

Source: [logic/ch07-negating-compounds.html](../../../database-sources/logic/FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3.html) — ID `FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3`

روش حل
E
مشخص کن گزاره‌ی اصلی چه ساختاری داره: عطف، فصل، یا شرطی.
طبق جدول بالا، قانون تبدیلِ مناسب رو انتخاب کن.
اجزای داخلی رو هم — طبق قانونِ همون قانون — نقیض کن (فقط برای عطف/فصل هر دو جزء نقیض می‌شن؛ برای شرطی، فقط تالی نقیض می‌شه و مقدم دست‌نخورده می‌مونه).
نتیجه رو با یک مثال عددی/واقعی چک کن تا مطمئن بشی درسته.
→ جواب: نقیضِ درستِ گزاره‌ی ترکیبی.

## Fمثال آموزشی

Section ID: `EDDE7973-8688-031F-F97F-ACF11FFAA994`

Import key: `logic/ch07-negating-compounds.html#section-05`

Topic ID: `BC9707DD-B7E7-F2C8-7C16-3910A542358F`

Source: [logic/ch07-negating-compounds.html](../../../database-sources/logic/FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3.html) — ID `FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3`

مثال آموزشی
F
Example 1 — برای درک مفهوم
Write the contradictory of: "John and Mary went to the zoo."
"Either John didn't go to the zoo or Mary didn't go to the zoo." این یک عطفه («John went» and «Mary went»)، پس طبق قدم ۲، نقیضش یک فصل از نقیض هر دو جزء می‌شه.
پاسخ:

## Gمثال امتحانی

Section ID: `0021DC04-E621-CCAC-9262-D64B9045D6FA`

Import key: `logic/ch07-negating-compounds.html#section-06`

Topic ID: `BC9707DD-B7E7-F2C8-7C16-3910A542358F`

Source: [logic/ch07-negating-compounds.html](../../../database-sources/logic/FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3.html) — ID `FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3`

مثال امتحانی
G
Example 2 — CEnT style
"Sam loves hotdogs, but he doesn't like relish." What is the correct contradictory of this claim?
A) "Sam doesn't love hotdogs and he likes relish."
B) "Either Sam doesn't love hotdogs, or he likes relish."
C) "Sam doesn't love hotdogs or he doesn't like relish."
D) "Sam loves hotdogs and he likes relish."
از کجا شروع کنیم؟
اول یادت باشه «but» طبق فصل ۲ منطقاً همون «and» است. پس گزاره اینه: "Sam loves hotdogs AND he doesn't like relish."
چه اطلاعاتی مهمه؟
طبق قدم ۲، نقیضِ یک عطف، یک فصله از نقیضِ هر جزء: نقیضِ «loves hotdogs» می‌شه «doesn't love hotdogs»، و نقیضِ «doesn't like relish» می‌شه «likes relish». پس نتیجه: "Sam doesn't love hotdogs, OR he likes relish."
چی حواس‌پرت‌کنه؟
گزینه‌ی A دقیقاً همون رایج‌ترین اشتباهه: فقط اجزا رو نقیض کرده ولی عملگر «and» رو عوض نکرده به «or». گزینه‌ی C اجزا رو درست نقیض نکرده (جزء دوم رو دوباره نقیض کرده، در حالی که باید برگرده به حالت مثبت "likes relish"). گزینه‌ی D اصلاً هیچ نقیضی انجام نداده.
چرا این روش مطمئن‌تره؟
چون به‌جای حدس زدن، مستقیم از فرمول not-(A and B) = (not-A) or (not-B) استفاده کردیم و هر جزء رو جداگانه و دقیق نقیض کردیم.
🎯 EXAM TIP
یک قانون حفظی ساده برای همه‌ی این فصل:
and ⇄ or، و if…then تبدیل به and می‌شه (با فقط تالی نقیض‌شده). این یک قانون مکانیکیه — نیازی به فکر کردن دوباره از صفر نیست، فقط کافیه ساختار رو تشخیص بدی و قانون رو اعمال کنی.
«not» که وارد پرانتز می‌شه، عملگر رو برعکس می‌کنه.»
⚡ QUICK METHOD
برای چک کردن سریع جوابت، یک مثال عددی/واقعی با یک ترکیب خاص از T/F امتحان کن. مثلاً برای «not-(A and B)»، فرض کن A=True, B=False. گزاره‌ی اصلی «A and B» می‌شه False، پس نقیضش باید True باشه. حالا «(not-A) or (not-B)» = «False or True» = True. ✓ جواب تأیید شد.
⚠️ COMMON MISTAKES
نقیض کردن هر دو جزء ولی عملگر رو بدون تغییر نگه داشتن — یعنی نوشتن «not-(A and B) = (not-A) and (not-B)» به‌جای «or».
اشتباه:
ذهن به‌طور شهودی فکر می‌کنه چون «not» داخل پرانتز پخش شده، فقط باید اجزا عوض بشن، بدون توجه به اینکه خودِ رابط بین اجزا هم باید عوض بشه.
چرا اتفاق می‌افته:
همیشه جدول قدم ۴ رو مرور کن: and⇄or. این تبدیل، جدا از نقیض کردنِ اجزا، یک مرحله‌ی اضافه‌ست که هیچ‌وقت نباید فراموشش کنی.
چطور جلوش رو بگیریم:
🪤 QUESTION TRAP
برای نقیض شرطی، آزمون گاهی گزینه‌ای می‌ذاره به‌فرم «If not-A then not-B» — این اشتباهه و اصلاً نقیضِ شرطی نیست (این تبدیل، که بهش
می‌گن، موضوع فصل ۸ است و رابطه‌ی دیگه‌ای با گزاره‌ی اصلی داره). نقیضِ درستِ «If A then B» همیشه یک عطفه: «A and not-B» — نه یک شرطیِ دیگه.
inverse
🧠 MUST REMEMBER
|
|
. عملگر همیشه عوض می‌شه؛ نقیضِ شرطی همیشه یک عطفه با مقدم دست‌نخورده.
not-(A and B) = (not-A) or (not-B)
not-(A or B) = (not-A) and (not-B)
not-(if A then B) = A and not-B

## 📝تمرین

Section ID: `8A37812B-9666-7AC7-BF98-D2A620EA5C19`

Import key: `logic/ch07-negating-compounds.html#section-07`

Topic ID: `BC9707DD-B7E7-F2C8-7C16-3910A542358F`

Source: [logic/ch07-negating-compounds.html](../../../database-sources/logic/FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3.html) — ID `FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3`

📝
تمرین
آسان
What is the contradictory of "The package arrived on time and undamaged"?
A) "The package didn't arrive on time and it was damaged."
B) "The package didn't arrive on time, or it was damaged."
C) "The package arrived on time or undamaged."
D) "The package arrived late and undamaged."
نمایش پاسخ و توضیح
پاسخ درست: B.
این یک عطفه؛ طبق قانون، نقیضش یک فصله از نقیضِ هر جزء. گزینه‌ی A دقیقاً همون اشتباه رایجه (عملگر رو عوض نکرده).
متوسط
What is the negation of "The printer is out of paper or out of toner"? Assume inclusive OR.
A) "The printer is out of paper or out of toner."
B) "The printer is not out of paper, or it is not out of toner."
C) "The printer is not out of paper, and it is not out of toner."
D) "The printer is out of both paper and toner."
نمایش پاسخ و توضیح
پاسخ درست: C.
در فصل شمولی، نقیض A یا B برابر است با نه A و نه B. بنابراین چاپگر نه کاغذ کم دارد و نه تونر. اگر or انحصاری بود، قاعده متفاوت می‌شد.
سخت
What is the contradictory of "If the invoice is approved, then payment is processed within 48 hours"?
A) "If the invoice is not approved, then payment is not processed within 48 hours."
B) "The invoice is not approved, and payment is not processed within 48 hours."
C) "The invoice is approved, and payment is not processed within 48 hours."
D) "If payment is not processed within 48 hours, then the invoice was not approved."
نمایش پاسخ و توضیح
پاسخ درست: C.
طبق قدم ۴، نقیضِ «If A then B» همیشه «A and not-B» است — مقدم (تأیید فاکتور) دست‌نخورده می‌مونه و فقط تالی نقیض می‌شه. گزینه‌ی A دقیقاً همون دام «Question Trap» است — یک شرطیِ دیگه (inverse) که اصلاً نقیض نیست. گزینه‌ی D هم یک شرطیِ دیگه‌ست (contrapositive که در فصل ۸ می‌بینیم و در واقع با گزاره‌ی اصلی هم‌ارزه، نه نقیضش). گزینه‌ی B مقدم رو هم اشتباهاً نقیض کرده.

## 🚀مرور سریع — فصل ۷

Section ID: `63A5BFAC-8A56-EA07-A7D7-3CCF431E81F5`

Import key: `logic/ch07-negating-compounds.html#section-08`

Topic ID: `BC9707DD-B7E7-F2C8-7C16-3910A542358F`

Source: [logic/ch07-negating-compounds.html](../../../database-sources/logic/FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3.html) — ID `FF7D1F88-D281-635C-9F04-EDAD7FF6B4C3`

مرور سریع — فصل ۷
🚀
مفاهیم اصلی (جدول تبدیل)
not-(not-A) = A
not-(A and B) = (not-A) or (not-B)
not-(A or B) = (not-A) and (not-B)
not-(if A then B) = A and not-B
روش
ساختار رو تشخیص بده (and/or/if…then).
قانون تبدیل مناسب رو اعمال کن.
با یک مثال T/F جواب رو چک کن.
اشتباهات رایج
نقیض کردن اجزا بدون عوض کردن عملگر.
ساختن «If not-A then not-B» به‌جای «A and not-B».
دام‌های تستی
گزینه‌های inverse یا contrapositive به‌جای نقیضِ واقعی.
عوض نشدنِ and⇄or در گزینه‌های نادرست.
