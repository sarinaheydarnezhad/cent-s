# فصل ۱۵: خواندن نمودارهای دایره‌ای — Reading Pie Charts

Original chapter ID: `6D01499C-E650-2C71-A319-AB66703EF1AB`

Original chapter import key: `logic/ch15-piecharts.html#chapter`

## فصل ۱۵: خواندن نمودارهای دایره‌ای — Reading Pie Charts

Section ID: `9699D14D-B361-ABFE-3674-67DCB24BF15A`

Import key: `logic/ch15-piecharts.html#intro`

Topic ID: `068A5503-C91B-6EB5-87D1-1C73AC34B07F`

Source: [logic/ch15-piecharts.html](../../../database-sources/logic/24EDDFE0-94BC-8FCA-4158-6E6FD45480FD.html) — ID `24EDDFE0-94BC-8FCA-4158-6E6FD45480FD`

CENT LOGIC — PART B · CHAPTER 15 / 19
فصل ۱۵: خواندن نمودارهای دایره‌ای — Reading Pie Charts
نمودار دایره‌ای سهم هر بخش از یک کل رو نشون می‌ده. قانون طلایی: مجموع همه‌ی سهم‌ها همیشه باید ۱۰۰٪ بشه — و همین قانون، ابزار اصلیِ چک کردنِ سریعِ درستیِ جواب‌هاته.

## Bاین مبحث چیست؟

Section ID: `BE34D705-CDF7-B7FA-F09F-1C4EAA0B3B03`

Import key: `logic/ch15-piecharts.html#section-01`

Topic ID: `068A5503-C91B-6EB5-87D1-1C73AC34B07F`

Source: [logic/ch15-piecharts.html](../../../database-sources/logic/24EDDFE0-94BC-8FCA-4158-6E6FD45480FD.html) — ID `24EDDFE0-94BC-8FCA-4158-6E6FD45480FD`

این مبحث چیست؟
B
در نمودار دایره‌ای
، هر قطاع (slice) درصدی از کل رو نشون می‌ده. سؤالات معمولاً می‌خوان مقدارِ واقعیِ یک قطاع رو از روی درصد و کل حساب کنی، یا برعکس — از روی مقدار یک قطاع، کل رو پیدا کنی.
(pie chart)

## Cمفهوم اصلی

Section ID: `701771AA-0BBD-70A6-9760-9398299C99F1`

Import key: `logic/ch15-piecharts.html#section-02`

Topic ID: `068A5503-C91B-6EB5-87D1-1C73AC34B07F`

Source: [logic/ch15-piecharts.html](../../../database-sources/logic/24EDDFE0-94BC-8FCA-4158-6E6FD45480FD.html) — ID `24EDDFE0-94BC-8FCA-4158-6E6FD45480FD`

مفهوم اصلی
C
قدم ۱ — تبدیل درصد به مقدار:
.
مقدار = درصد × کل
نمونه
— Rent: 40%, Food: 25%, Transportation: 15%, Savings: 10%, Other: 10%
Monthly Budget of a Household
If the total budget is 50 million Tomans, how much is spent on food?
۲۵٪ × ۵۰,۰۰۰,۰۰۰ = ۱۲,۵۰۰,۰۰۰ تومان.
پاسخ:
قدم ۲ — همون فرمول برای شمارش افراد هم کار می‌کنه، نه فقط پول.
نمونه
— Tea: 45%, Coffee: 30%, Water: 15%, Juice: 10%
Favorite Beverage Survey
If 200 people participated, how many chose coffee?
۳۰٪ × ۲۰۰ = ۶۰ نفر.
پاسخ:
و اگه یک جدولِ اعداد خام (نه درصد) بهت دادن و پرسیدن «کدوم جدول با این نمودار جور در میاد؟»، باید هم اندازه‌ی نسبیِ قطاع‌ها رو چک کنی، هم اینکه مجموعشون با هم سازگاره.
قدم ۳ — ابزار چک کردنِ خودکار: چون همه‌ی سهم‌ها باید ۱۰۰٪ بشن، اگه یک عدد رو گم کردی، می‌تونی از باقی‌مونده حسابش کنی.
نمونه‌ی تشخیصی
Suppose a pie chart shows: "Vanilla" and "Mint" as the two smallest, clearly EQUAL slices; "Raspberry" as a medium slice; "Chocolate" and "Strawberry" as the two largest, clearly EQUAL slices.
هر جدولی که این توصیف رو نقض کنه — مثلاً «Vanilla» و «Mint» رو خیلی متفاوت نشون بده، یا «Raspberry» رو بزرگ‌تر از «Chocolate» نشون بده — نمی‌تونه با این نمودار مطابقت داشته باشه، فارغ از اینکه مجموع اعدادش درست باشه یا نه.

## Dقوانین و اصول مهم

Section ID: `C0A224E6-B45F-3662-DB16-09B5E48B7F1C`

Import key: `logic/ch15-piecharts.html#section-03`

Topic ID: `068A5503-C91B-6EB5-87D1-1C73AC34B07F`

Source: [logic/ch15-piecharts.html](../../../database-sources/logic/24EDDFE0-94BC-8FCA-4158-6E6FD45480FD.html) — ID `24EDDFE0-94BC-8FCA-4158-6E6FD45480FD`

قوانین و اصول مهم
D
مجموع همه‌ی سهم‌های یک نمودار دایره‌ای همیشه باید ۱۰۰٪ بشه.
؛ برعکسش:
.
مقدار یک قطاع = درصد × کل
کل = مقدار یک قطاع / درصد
برای تطبیقِ یک جدولِ اعداد خام با یک نمودار دایره‌ای، هم
باید مطابقت داشته باشه، هم
باید با هم سازگار باشه.
ترتیب نسبیِ اندازه‌ها
مجموع اعداد
قطاع‌هایی که در نمودار تقریباً مساوی به‌نظر می‌رسن، باید در جدولِ اعدادِ خام هم تقریباً مساوی باشن.

## Eروش حل

Section ID: `BF76F524-039C-2439-B1CE-3201B113362F`

Import key: `logic/ch15-piecharts.html#section-04`

Topic ID: `068A5503-C91B-6EB5-87D1-1C73AC34B07F`

Source: [logic/ch15-piecharts.html](../../../database-sources/logic/24EDDFE0-94BC-8FCA-4158-6E6FD45480FD.html) — ID `24EDDFE0-94BC-8FCA-4158-6E6FD45480FD`

روش حل
E
مشخص کن سؤال دنبال چیه: مقدار یک قطاع، کلِ مجموعه، یا تطبیقِ یک جدول با نمودار.
اگه دنبال مقدار یک قطاعی: درصدش رو در کل ضرب کن.
اگه دنبال کل هستی: مقدار قطاع رو بر درصدش تقسیم کن.
اگه باید یک جدول رو با نمودار تطبیق بدی: اول ترتیب نسبیِ بزرگی/کوچیکیِ قطاع‌ها رو با ترتیب اعداد جدول مقایسه کن، بعد مجموع رو چک کن.
→ جواب: طبق محاسبه یا تطبیقِ دقیق.

## Fمثال آموزشی

Section ID: `C3604941-3D99-C0DB-6EE3-6BBBA506BBC9`

Import key: `logic/ch15-piecharts.html#section-05`

Topic ID: `068A5503-C91B-6EB5-87D1-1C73AC34B07F`

Source: [logic/ch15-piecharts.html](../../../database-sources/logic/24EDDFE0-94BC-8FCA-4158-6E6FD45480FD.html) — ID `24EDDFE0-94BC-8FCA-4158-6E6FD45480FD`

مثال آموزشی
F
Example 1 — برای درک مفهوم
A pie chart shows a company's expenses: Salaries 50%, Rent 20%, Marketing 20%, Other 10%. If the amount spent on Rent is €40,000, what is the company's TOTAL expense?
کل = مقدار / درصد = ۴۰,۰۰۰ / ۰.۲۰ = ۲۰۰,۰۰۰ یورو. اینجا برخلاف مثال‌های قبلی، از یک قطاع به سمت کل حرکت کردیم، نه برعکس.
پاسخ:

## Gمثال امتحانی

Section ID: `E9A0876B-357D-4E7A-F613-C5CDF6327859`

Import key: `logic/ch15-piecharts.html#section-06`

Topic ID: `068A5503-C91B-6EB5-87D1-1C73AC34B07F`

Source: [logic/ch15-piecharts.html](../../../database-sources/logic/24EDDFE0-94BC-8FCA-4158-6E6FD45480FD.html) — ID `24EDDFE0-94BC-8FCA-4158-6E6FD45480FD`

مثال امتحانی
G
Example 2 — CEnT style
A pie chart shows the favorite ice cream flavor for a sample of students. Visually: "Vanilla" and "Mint" are the two smallest slices and look equal to each other; "Raspberry" is a medium-sized slice; "Chocolate" and "Strawberry" are the two largest slices and look equal to each other. Which row could show the number of students who chose each flavor?
Vanilla
Raspberry
Strawberry
Chocolate
Mint
A
23
41
35
35
16
B
5
34
36
35
10
C
15
29
32
31
13
D
26
61
73
73
37
E
36
55
71
72
36
از کجا شروع کنیم؟
قبل از هر محاسبه‌ای، توصیفِ نموداری رو به یک چک‌لیست تبدیل کن: (۱) Vanilla ≈ Mint (تقریباً مساوی و کوچیک)، (۲) Chocolate ≈ Strawberry (تقریباً مساوی و بزرگ)، (۳) Raspberry باید بینِ این دو گروه باشه (نه خیلی کوچیک، نه به بزرگیِ دو قطاع اصلی).
چه اطلاعاتی مهمه؟
ردیف E: Vanilla=36, Mint=36 (کاملاً مساوی ✓). Strawberry=71, Chocolate=72 (تقریباً مساوی ✓). Raspberry=55 (دقیقاً بین ۳۶ و ۷۱/۷۲ قرار داره ✓). همه‌ی سه شرط برقرارن.
چی حواس‌پرت‌کنه؟
ردیف A: Raspberry=41 بزرگ‌تر از Strawberry و Chocolate (هر دو ۳۵) است — این برخلاف توصیفِ نمودار (که Raspberry باید کوچیک‌تر از این دو باشه) است، رد می‌شه. ردیف D: Vanilla=26 در مقابل Mint=37 — این دو زیادی با هم فرق دارن تا «تقریباً مساوی» حساب بشن، در حالی که در نمودار این دو قطاع کاملاً یکسان به‌نظر می‌رسیدن.
چرا این روش مطمئن‌تره؟
چون به‌جای حدس زدن یا فقط چک کردنِ مجموع اعداد (که در چند ردیف ممکنه یکسان باشه)، مستقیماً روابطِ نسبیِ بینِ قطاع‌ها رو — که خودِ تصویر نمودار نشونمون داده — امتحان کردیم.
🎯 EXAM TIP
وقتی باید یک جدولِ اعداد رو با یک نمودار دایره‌ای تطبیق بدی، اول فقط به روابطِ نسبی نگاه کن (کدوم بزرگ‌تره، کدوم‌ها مساوی‌ان) — نه به اعداد دقیق. این کار خیلی سریع‌تر از محاسبه‌ی درصدِ دقیقِ هر ردیفه.
⚡ QUICK METHOD
اگه مقدارِ یک قطاع رو داری و می‌خوای مقدارِ قطاعِ دیگه‌ای رو پیدا کنی، لازم نیست حتماً از «کل» عبور کنی — می‌تونی مستقیماً نسبتِ دو درصد رو ضرب کنی:
. این یک مرحله رو حذف می‌کنه.
مقدارِ B = مقدارِ A × (درصد B / درصد A)
⚠️ COMMON MISTAKES
فراموش کردنِ اینکه درصدها باید به کل مجموعه اعمال بشن، نه به یک زیرمجموعه‌ی دیگه.
اشتباه:
وقتی چند درصد پشتِ سرِ هم در سؤال میان (مثلاً درصدِ زنان از کل، و بعد درصدِ یک رشته از زنان)، ذهن گاهی هر دو درصد رو مستقیم روی «کل» اعمال می‌کنه، در حالی که درصدِ دوم باید روی نتیجه‌ی درصدِ اول اعمال بشه (این دقیقاً همون منطقِ فصل «Percentages» در تیپِ ریاضیه که قبلاً دیدیم).
چرا اتفاق می‌افته:
همیشه با دقت مشخص کن هر درصد نسبت به کدوم مبناست — کلِ اصلی، یا یک زیرمجموعه‌ی قبلی.
چطور جلوش رو بگیریم:
🪤 QUESTION TRAP
در سؤالاتِ تطبیقِ جدول با نمودار، آزمون گزینه‌هایی می‌ذاره که مجموعشون دقیقاً با هم برابره (مثل ردیف‌های D و E که هر دو مجموعِ ۲۷۰ دارن)، ولی فقط یکی از اون‌ها روابطِ نسبیِ صحیح رو رعایت می‌کنه. مجموع بودنِ برابر، به‌تنهایی کافی نیست.
🧠 MUST REMEMBER
مجموعِ سهم‌ها = ۱۰۰٪.
. برای تطبیقِ جدول با نمودار، هم اندازه‌ی نسبیِ قطاع‌ها رو چک کن، هم مجموعِ کل رو.
مقدار قطاع = درصد × کل

## 📝تمرین

Section ID: `D4D510ED-2A54-6DD9-AC1E-C10A6AEC8935`

Import key: `logic/ch15-piecharts.html#section-07`

Topic ID: `068A5503-C91B-6EB5-87D1-1C73AC34B07F`

Source: [logic/ch15-piecharts.html](../../../database-sources/logic/24EDDFE0-94BC-8FCA-4158-6E6FD45480FD.html) — ID `24EDDFE0-94BC-8FCA-4158-6E6FD45480FD`

تمرین
📝
آسان
A pie chart shows a class's favorite subjects: Math 30%, Science 25%, Art 20%, History 15%, Other 10%. If there are 40 students, how many chose Science?
A) 8
B) 10
C) 12
D) 15
نمایش پاسخ و توضیح
۲۵٪ × ۴۰ = ۱۰.
پاسخ درست: B.
متوسط
A pie chart shows a store's inventory by category. "Electronics" makes up 35% of inventory, and there are 210 electronic items. How many total items are in the inventory?
A) 500
B) 550
C) 600
D) 650
نمایش پاسخ و توضیح
کل = مقدار / درصد = ۲۱۰ / ۰.۳۵ = ۶۰۰.
پاسخ درست: C.
سخت
A pie chart shows a household's monthly spending: Rent 45%, Food 20%, Utilities 15%, Entertainment 10%, Savings 10%. This month, the amount spent on Food was €300. Next month, if the total budget increases by 20% but the percentage breakdown stays exactly the same, how much will be spent on Rent next month?
A) €675
B) €810
C) €900
D) €945
نمایش پاسخ و توضیح
اول کلِ فعلی رو پیدا کن: کل = ۳۰۰ / ۰.۲۰ = ۱,۵۰۰ یورو. کلِ ماه بعد با ۲۰٪ افزایش: ۱,۵۰۰ × ۱.۲۰ = ۱,۸۰۰ یورو. چون درصدِ اجاره (۴۵٪) ثابت مونده: ۴۵٪ × ۱,۸۰۰ = ۸۱۰ یورو. این سؤال دو مرحله داره — اول برگشت به کل از روی یک قطاع، بعد رفتن به قطاعِ دیگه با کلِ جدید.
پاسخ درست: B.

## 🚀مرور سریع — فصل ۱۵

Section ID: `66860B8F-0FF9-65AC-6880-48C37A99689A`

Import key: `logic/ch15-piecharts.html#section-08`

Topic ID: `068A5503-C91B-6EB5-87D1-1C73AC34B07F`

Source: [logic/ch15-piecharts.html](../../../database-sources/logic/24EDDFE0-94BC-8FCA-4158-6E6FD45480FD.html) — ID `24EDDFE0-94BC-8FCA-4158-6E6FD45480FD`

مرور سریع — فصل ۱۵
🚀
مفاهیم اصلی
مجموعِ سهم‌ها = ۱۰۰٪.
مقدار قطاع = درصد × کل.
کل = مقدار قطاع / درصد.
روش
برای تطبیقِ جدول با نمودار، اول روابطِ نسبی رو چک کن.
اشتباهات رایج
اعمالِ یک درصدِ زیرمجموعه روی کلِ اصلی، به‌جای زیرمجموعه.
دام‌های تستی
گزینه‌هایی با مجموعِ برابر ولی روابطِ نسبیِ متفاوت.
