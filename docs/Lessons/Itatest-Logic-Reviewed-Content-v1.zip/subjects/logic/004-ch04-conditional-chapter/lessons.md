# فصل ۴: شرطی — «If A then B» (Conditional)

Original chapter ID: `C70F1F47-09F3-63A6-6C82-78CC9B3937A6`

Original chapter import key: `logic/ch04-conditional.html#chapter`

## فصل ۴: شرطی — «If A then B» (Conditional)

Section ID: `BA9054B6-9498-7674-F800-264FDF640DAD`

Import key: `logic/ch04-conditional.html#intro`

Topic ID: `FFB3F563-4CFB-6493-5EC7-833AA3140226`

Source: [logic/ch04-conditional.html](../../../database-sources/logic/A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8.html) — ID `A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8`

CENT LOGIC — PART A · CHAPTER 4 / 13
فصل ۴: شرطی — «If A then B» (Conditional)
شرطی
پرکاربردترین و پردام‌ترین ساختار در بخش Logic آزمونه. بیشتر اشتباهات داوطلب‌ها نه از ندونستن تعریف، بلکه از این میاد که فکر می‌کنن شرطی چیزی رو ادعا می‌کنه که در واقع ادعا نمی‌کنه.
(conditional)

## Bاین مبحث چیست؟

Section ID: `35084E3E-4AC9-252C-E142-B3AB4309E281`

Import key: `logic/ch04-conditional.html#section-01`

Topic ID: `FFB3F563-4CFB-6493-5EC7-833AA3140226`

Source: [logic/ch04-conditional.html](../../../database-sources/logic/A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8.html) — ID `A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8`

این مبحث چیست؟
B
هر جمله‌ای که با «If … then …» ساخته شده باشه، یک شرطیه. بخش بعد از «If» رو مقدم
و بخش بعد از «then» رو تالی
می‌گن.
(antecedent)
(consequent)
نمونه
"If I miss the bus, then I'll be late for work."
مقدم: "I miss the bus" — تالی: "I'll be late for work".

## Cمفهوم اصلی

Section ID: `BBEBCA74-4BA2-4E76-D5FC-FC58AB2EFB4D`

Import key: `logic/ch04-conditional.html#section-02`

Topic ID: `FFB3F563-4CFB-6493-5EC7-833AA3140226`

Source: [logic/ch04-conditional.html](../../../database-sources/logic/A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8.html) — ID `A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8`

مفهوم اصلی
C
این مهم‌ترین و بیشتر گم‌شده‌ترین نکته‌ی این فصله. «If A then B» ادعا نمی‌کنه A درسته، ادعا نمی‌کنه B درسته — فقط یک
بین A و B رو ادعا می‌کنه: «هر وقت A درست باشه، B هم باید درست باشه».
قدم ۱ — یک شرطی، هیچ‌کدوم از A یا B رو به‌تنهایی ادعا نمی‌کنه.
رابطه
نمونه
"If I drive drunk, then I'll get into a car accident."
این جمله نمی‌گه «من الان مست رانندگی می‌کنم» و نمی‌گه «من تصادف می‌کنم». فقط می‌گه: اگه اون اتفاق (مست رانندگی کردن) بیفته، این یکی (تصادف) هم به‌دنبالش میاد.
فقط در
حالت: وقتی مقدم درست باشه ولی تالی غلط باشه. یعنی چیزی که ادعا شده «اگه A بیفته B هم میاد» نقض شده باشه.
قدم ۲ — یک شرطی کِی غلطه؟
یک
نمونه
"If I study hard, then I'll pass the test." — Case: I studied hard (A = True). I didn't pass the test (B = False).
این تنها حالتیه که کل شرطی غلط می‌شه: قول (A→B) داده شده بود، ولی نقض شد.
این نکته با شهود روزمره در تضاده، ولی قانون منطقیه.
قدم ۳ — نکته‌ی مهم: اگه مقدم غلط باشه، کل شرطی همیشه درسته — حتی اگه تالی هم غلط باشه.
نمونه
"If I live in Beijing, then I live in China." — Suppose: I don't live in Beijing (A = False) and, hypothetically, I don't live in China either (B = False).
حتی در این حالت، کل جمله‌ی شرطی هنوز
در نظر گرفته می‌شه — چون شرطی فقط زمانی رو محک می‌زنه که مقدمش واقعاً درست باشه. وقتی مقدم اصلاً پیش نمیاد (غلطه)، ادعای شرطی هیچ‌وقت نقض نمی‌شه.
درست
قدم ۴ — جدول درستی کامل.
A
B
If A then B
T
T
T
T
F
F
F
T
T
F
F
T
فقط یک ردیف (دومی) کل شرطی رو غلط می‌کنه. (نسخه‌ی اسکن‌شده‌ی منبع در ردیف آخر این جدول به‌اشتباه «F» چاپ شده بود؛ نسخه‌ی بالا مطابق تعریف استاندارد منطق گزاره‌ای برای شرطیه — وقتی مقدم غلطه، شرطی همیشه درسته.)

## Dقوانین و اصول مهم

Section ID: `A72A0E7E-4CA3-A8D9-8C4C-F9B4DB0C6465`

Import key: `logic/ch04-conditional.html#section-03`

Topic ID: `FFB3F563-4CFB-6493-5EC7-833AA3140226`

Source: [logic/ch04-conditional.html](../../../database-sources/logic/A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8.html) — ID `A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8`

قوانین و اصول مهم
D
شرطی فقط در
حالت غلطه: مقدم درست، تالی غلط.
یک
در سه حالت دیگه (از جمله وقتی مقدم غلطه) شرطی همیشه درسته.
شرطی هیچ ادعایی درباره‌ی درست بودن A یا B به‌تنهایی نمی‌کنه — فقط رابطه بینشون رو ادعا می‌کنه.
وقتی مقدم غلطه، شرطی به‌طور خودکار درسته — این حالت رو «درستی پوچ»
می‌گن.
(vacuous truth)

## Eروش حل

Section ID: `734EC981-1551-8975-72BA-0FDD777C2D64`

Import key: `logic/ch04-conditional.html#section-04`

Topic ID: `FFB3F563-4CFB-6493-5EC7-833AA3140226`

Source: [logic/ch04-conditional.html](../../../database-sources/logic/A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8.html) — ID `A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8`

روش حل
E
مقدم (A) و تالی (B) رو مشخص کن — دقت کن که کدوم بعد از «if» و کدوم بعد از «then» اومده.
اگه ارزش درستی A و B رو داری: فقط چک کن آیا A=True و B=False است.
اگه این حالت برقرار بود، کل شرطی غلطه. در غیر این صورت (هر ترکیب دیگه‌ای)، کل شرطی درسته.
اگه سؤال می‌پرسه «چه چیزی این شرطی رو نقض می‌کنه؟»، دنبال سناریویی بگرد که در اون A درست ولی B غلط باشه.
→ جواب: بر اساس همین یک قانون تعیین می‌شه.

## Fمثال آموزشی

Section ID: `B8DDBE44-C262-61A0-6CDD-4653050F1BE1`

Import key: `logic/ch04-conditional.html#section-05`

Topic ID: `FFB3F563-4CFB-6493-5EC7-833AA3140226`

Source: [logic/ch04-conditional.html](../../../database-sources/logic/A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8.html) — ID `A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8`

مثال آموزشی
F
Example 1 — برای درک مفهوم
"If the alarm goes off, then the building will be evacuated." Suppose the alarm did NOT go off, and the building was NOT evacuated. Is the conditional true or false?
چون مقدم («the alarm goes off») غلطه، طبق قانون قدم ۳، کل شرطی به‌طور خودکار درست در نظر گرفته می‌شه — فارغ از اینکه تالی چی شده.
پاسخ: درسته.

## Gمثال امتحانی

Section ID: `80DEFEC6-4314-DECA-AE6B-2EADA9343CDC`

Import key: `logic/ch04-conditional.html#section-06`

Topic ID: `FFB3F563-4CFB-6493-5EC7-833AA3140226`

Source: [logic/ch04-conditional.html](../../../database-sources/logic/A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8.html) — ID `A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8`

مثال امتحانی
G
Example 2 — CEnT style
"If a candidate scores above 80%, then the candidate is admitted." Which of the following scenarios proves this conditional claim FALSE?
A) A candidate scores 75% and is not admitted.
B) A candidate scores 85% and is not admitted.
C) A candidate scores 90% and is admitted.
D) A candidate scores 60% and is admitted.
از کجا شروع کنیم؟
مقدم رو مشخص کن: "scores above 80%". تالی: "is admitted". طبق قانون قدم ۲، فقط یک سناریو این شرطی رو نقض می‌کنه: مقدم درست (نمره بالای ۸۰٪) ولی تالی غلط (پذیرفته نشدن).
چه اطلاعاتی مهمه؟
گزینه‌ی B دقیقاً همین سناریوست: نمره ۸۵٪ (بالای ۸۰٪، پس مقدم درسته) ولی پذیرفته نشده (تالی غلطه).
چی حواس‌پرت‌کنه؟
گزینه‌ی A مقدمش غلطه (۷۵٪ زیر ۸۰٪ است)، پس طبق قانون «درستیِ پوچ»، این سناریو هیچ تناقضی با شرطی نداره — حتی اگه پذیرفته نشده باشه. گزینه‌های C و D هر دو تالی‌شون درسته، پس نمی‌تونن ناقض شرطی باشن، چون شرطی فقط با «مقدم درست + تالی غلط» نقض می‌شه.
چرا این روش مطمئن‌تره؟
چون به‌جای بررسی همه‌ی گزینه‌ها با شهود، مستقیم دنبال تنها الگوی نقض‌کننده‌ (T,F) می‌گردیم — این کار زمان حل رو به‌شدت کم می‌کنه.
🎯 EXAM TIP
هر وقت سؤال پرسید «کدوم گزینه این ادعا رو نقض می‌کنه؟» یا «کدوم گزینه ثابت می‌کنه ادعا غلطه؟»، فقط دنبال یک الگو بگرد:
. بقیه‌ی گزینه‌ها رو سریع حذف کن.
مقدم درست + تالی غلط
⚡ QUICK METHOD
به‌جای حفظ کردن چهار ردیف جدول، فقط یک جمله رو حفظ کن: «شرطی همیشه درسته، مگر اینکه مقدم درست و تالی غلط باشه.» این یک قانون، جایگزین کل جدول می‌شه.
⚠️ COMMON MISTAKES
فکر کردن به اینکه وقتی مقدم غلطه، کل شرطی هم باید غلط باشه.
اشتباه:
در زبان روزمره، وقتی می‌گیم «اگه بارون بیاد، خیس می‌شیم» و بارون نمیاد، حس می‌کنیم جمله دیگه معنی نداره یا نه‌درست‌ونه‌غلطه. اما در منطق گزاره‌ای، این حالت رو صراحتاً
در نظر می‌گیریم.
چرا اتفاق می‌افته:
درست
همیشه جدول درستی رو مرور کن: تنها ردیفی که شرطی غلط می‌شه، ردیف «مقدم درست، تالی غلط»ه. سه ردیف دیگه — حتی وقتی مقدم غلطه — همیشه درستن.
چطور جلوش رو بگیریم:
🪤 QUESTION TRAP
آزمون گاهی گزینه‌ای می‌ذاره که با تعویض جای مقدم و تالی ساخته شده (یعنی معکوس شرطی — «If B then A» به‌جای «If A then B»). این دو از نظر منطقی
(این موضوع رو در فصل «معکوس و متضاد شرطی» با جزئیات بیشتر می‌بینی). فعلاً فقط حواست باشه که «مقدم» و «تالی» رو با هم اشتباه نگیری.
معادل هم نیستن
🧠 MUST REMEMBER
«If A then B» فقط در یک حالت غلطه:
. در همه‌ی حالت‌های دیگه — از جمله وقتی A غلطه — شرطی درسته. شرطی هیچ ادعایی درباره‌ی درست بودن واقعیِ A یا B نمی‌کنه، فقط رابطه‌ی بینشون رو ادعا می‌کنه.
A درست، B غلط

## 📝تمرین

Section ID: `DC81076A-F812-A748-7D94-9B78E797D196`

Import key: `logic/ch04-conditional.html#section-07`

Topic ID: `FFB3F563-4CFB-6493-5EC7-833AA3140226`

Source: [logic/ch04-conditional.html](../../../database-sources/logic/A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8.html) — ID `A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8`

تمرین
📝
آسان
"If the light is red, then cars must stop." A car sees a red light and stops. Is the conditional true or false in this case?
A) True
B) False
C) Cannot be determined
D) Neither true nor false
نمایش پاسخ و توضیح
مقدم (چراغ قرمزه) درسته و تالی (ماشین توقف کرد) هم درسته. طبق جدول درستی، ردیف اول (T,T) نتیجه‌اش True است.
پاسخ درست: A.
متوسط
"If a metal is heated, then it expands." A piece of metal was NOT heated, and it did NOT expand. What is the truth value of the conditional in this case?
A) True
B) False
C) Cannot be determined without more information
D) The claim is irrelevant in this case
نمایش پاسخ و توضیح
مقدم غلطه (فلز گرم نشده). طبق قانون قدم ۳ (درستیِ پوچ)، وقتی مقدم غلطه، شرطی همیشه درسته — فارغ از اینکه تالی چی شده. گزینه‌ی D اشتباهه چون شرطی هرگز «بی‌ربط» نمی‌شه؛ همیشه یک ارزش درستی مشخص داره.
پاسخ درست: A.
سخت
A company's policy states: "If an employee works more than 40 hours in a week, then the employee receives overtime pay." An employee worked 45 hours and did NOT receive overtime pay. Later, another employee worked 30 hours and also did NOT receive overtime pay. Which employee's case proves the policy claim FALSE?
A) Only the first employee (45 hours, no overtime pay)
B) Only the second employee (30 hours, no overtime pay)
C) Both employees
D) Neither employee
نمایش پاسخ و توضیح
کارمند اول: مقدم درسته (بیش از ۴۰ ساعت کار کرده) ولی تالی غلطه (اضافه‌کاری نگرفته) — این دقیقاً الگوی نقض‌کننده‌ی (T,F) است. کارمند دوم: مقدم غلطه (کمتر از ۴۰ ساعت کار کرده)، پس طبق قانون درستیِ پوچ، این مورد هیچ تناقضی با شرطی نداره — نداشتنِ اضافه‌کاری برای کسی که اصلاً بیش از ۴۰ ساعت کار نکرده، ادعای شرطی رو نقض نمی‌کنه. این تمرین دقیقاً همون دام رایج بالاست: قاطی کردن «مقدم غلط» با نقض شرطی.
پاسخ درست: A.

## 🚀مرور سریع — فصل ۴

Section ID: `31B68159-93CE-B82C-0862-E2B7EEA57553`

Import key: `logic/ch04-conditional.html#section-08`

Topic ID: `FFB3F563-4CFB-6493-5EC7-833AA3140226`

Source: [logic/ch04-conditional.html](../../../database-sources/logic/A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8.html) — ID `A9B4A6D8-4779-AA00-AFDF-4F3E31DE7DA8`

مرور سریع — فصل ۴
🚀
مفاهیم اصلی
شرطی ادعای درستیِ A یا B رو نمی‌کنه — فقط رابطه‌شون رو ادعا می‌کنه.
مقدم = بخش if، تالی = بخش then.
مقدم غلط ⇒ شرطی خودکار درسته.
روش
اول چک کن مقدم غلطه یا نه — اگه غلطه، تمام، شرطی درسته.
فقط دنبال ترکیب «مقدم درست، تالی غلط» بگرد.
اشتباهات رایج
فکر کردن که مقدم غلط یعنی شرطی هم غلط یا بی‌معنیه.
قاطی کردن «If A then B» با «If B then A».
دام‌های تستی
گزینه‌هایی که جهت شرطی رو برعکس می‌کنن (converse).
سناریوهایی که فقط تالی رو چک می‌کنن و مقدم رو نادیده می‌گیرن.
