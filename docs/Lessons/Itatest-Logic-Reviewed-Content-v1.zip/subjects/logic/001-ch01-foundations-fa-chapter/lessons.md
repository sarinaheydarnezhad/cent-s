# فصل ۱: مبانی — گزاره چیست؟ گزاره‌های ترکیبی چه هستند؟

Original chapter ID: `2C1FA436-1536-0B45-7160-5B9A98A3EA4C`

Original chapter import key: `logic/ch01-foundations-fa.html#chapter`

## فصل ۱: مبانی — گزاره چیست؟ گزاره‌های ترکیبی چه هستند؟

Section ID: `23599E66-3DEE-DAB4-D5E6-012DEB32DECE`

Import key: `logic/ch01-foundations-fa.html#intro`

Topic ID: `F3739AF3-25FA-521F-89C9-1DF9A50DACCE`

Source: [logic/ch01-foundations-fa.html](../../../database-sources/logic/0B42FE17-B855-76B8-08E2-BED445C24111.html) — ID `0B42FE17-B855-76B8-08E2-BED445C24111`

CENT LOGIC — PART A · CHAPTER 1 / 13
فصل ۱: مبانی — گزاره چیست؟ گزاره‌های ترکیبی چه هستند؟
قبل از اینکه بتونی هر سوال Logic آزمون CEnT رو حل کنی، باید بدونی دقیقاً با چه چیزی روبرو هستی: یک
(گزاره) ساده، یا گزاره‌ای که از چند گزاره‌ی ساده‌تر ساخته شده. این فصل، پایه‌ی همه‌ی فصل‌های بعدیه.
statement

## Bاین مبحث چیست؟

Section ID: `6236935E-7C12-60EE-FBD1-165BD402425D`

Import key: `logic/ch01-foundations-fa.html#section-01`

Topic ID: `F3739AF3-25FA-521F-89C9-1DF9A50DACCE`

Source: [logic/ch01-foundations-fa.html](../../../database-sources/logic/0B42FE17-B855-76B8-08E2-BED445C24111.html) — ID `0B42FE17-B855-76B8-08E2-BED445C24111`

این مبحث چیست؟
B
منطق گزاره‌ای
— که بهش
یا
هم می‌گن — رابطه‌ی بین گزاره‌ها رو بررسی می‌کنه؛ یعنی جمله‌هایی که یا درستن یا غلط. سوالات Logic آزمون CEnT تقریباً هیچ‌وقت ازت نمی‌خوان بگی یک گزاره در دنیای واقعی درسته یا نه. در عوض، درستی یا غلطی چند گزاره‌ی ساده رو بهت می‌دن و ازت می‌خوان درستی یا غلطی گزاره‌ای که
رو پیدا کنی.
(propositional logic)
sentential logic
statement logic
از اون‌ها ساخته شده

## Cمفهوم اصلی

Section ID: `0FA7BF9E-301E-B127-3B66-B213DB7D67E7`

Import key: `logic/ch01-foundations-fa.html#section-02`

Topic ID: `F3739AF3-25FA-521F-89C9-1DF9A50DACCE`

Source: [logic/ch01-foundations-fa.html](../../../database-sources/logic/0B42FE17-B855-76B8-08E2-BED445C24111.html) — ID `0B42FE17-B855-76B8-08E2-BED445C24111`

مفهوم اصلی
C
یعنی یا درسته یا غلط — هیچ‌وقت هر دو، هیچ‌وقت هیچ‌کدوم.
قدم ۱ — یک گزاره
جمله‌ایه که ارزش درستی داره.
(statement)
مثال گزاره
= "John is wearing a red coat."
J
این یک گزاره‌ست: هر روز، یا درسته یا غلط.
آزمون، گزاره‌های پیچیده رو از چهار عملگر پایه می‌سازه:
قدم ۲ — یک گزاره‌ی ترکیبی
از چند گزاره‌ی ساده‌تر که با یک عملگر منطقی
به هم وصل شدن ساخته می‌شه.
(compound claim)
(logical connective)
— عطف (conjunction)
A and B
— فصل (disjunction)
A or B
— شرطی (conditional)
If A then B
— نقیض (negation)
not-A
هر سوال Logic که در بخش A این جزوه می‌بینی، در نهایت فقط ترکیب و تودرتوی همین چهار عملگره.
هیچ‌وقت به دانش بیرونی درباره‌ی جان، کت قرمز، یا ماشین دزدی نیاز نداری. فقط به ارزش‌های درستی‌ای که بهت دادن (یا ازت خواستن فرض کنی) و قوانین ترکیب اون‌ها نیاز داری.
قدم ۳ — درستی یک گزاره‌ی ترکیبی فقط به درستی اجزاش بستگی داره.
نمونه
"John is wearing a red coat
he's stolen a jeep."
and
کل این جمله فقط وقتی درسته که
گزاره‌ی کوچک‌تر — «جان کت قرمز پوشیده» و «جان ماشین دزدیده» — درست باشن. فصل ۲ قانون دقیقش رو بهت می‌ده.
هر دو

## Dقوانین و اصول مهم

Section ID: `817EE05A-13FB-BA3E-C896-B3A1AF9C3983`

Import key: `logic/ch01-foundations-fa.html#section-03`

Topic ID: `F3739AF3-25FA-521F-89C9-1DF9A50DACCE`

Source: [logic/ch01-foundations-fa.html](../../../database-sources/logic/0B42FE17-B855-76B8-08E2-BED445C24111.html) — ID `0B42FE17-B855-76B8-08E2-BED445C24111`

قوانین و اصول مهم
D
یک گزاره در هر لحظه دقیقاً یک ارزش درستی داره:
یا
.
True (T)
False (F)
ارزش درستی یک گزاره‌ی ترکیبی، وقتی ارزش درستی اجزا و عملگر بین‌شون رو بدونی، کاملاً مشخص می‌شه.
گزاره‌های تودرتو هم دقیقاً به همون شکل، از داخل به بیرون، ارزیابی می‌شن. گزاره‌ای مثل
در واقع فقط یک شرطیه که مقدمش (antecedent) یک گزاره‌ی «or» و نتیجه‌اش (consequent) یک گزاره‌ی «and» هست.
If (A or B) then (C and not-D)

## Eروش حل هر گزاره‌ی ترکیبی

Section ID: `B10088E3-9A57-FE60-B42F-2CFA4104155B`

Import key: `logic/ch01-foundations-fa.html#section-04`

Topic ID: `F3739AF3-25FA-521F-89C9-1DF9A50DACCE`

Source: [logic/ch01-foundations-fa.html](../../../database-sources/logic/0B42FE17-B855-76B8-08E2-BED445C24111.html) — ID `0B42FE17-B855-76B8-08E2-BED445C24111`

روش حل هر گزاره‌ی ترکیبی
E
کوچک‌ترین گزاره‌های داخل جمله رو پیدا کن و بهشون حرف بده (A، B، C…).
مشخص کن چه عملگر(هایی) اون‌ها رو به هم وصل کرده و تودرتوشون چطوریه (چی داخل چیه).
گزاره رو به‌صورت نمادین بنویس؛ از داخلی‌ترین بخش به سمت بیرون.
وقتی ارزش درستی اجزای پایه رو داری، اول داخلی‌ترین عملگر رو ارزیابی کن، بعد به سمت بیرون برو.
→ جواب: ارزش درستی کل گزاره.

## Fمثال آموزشی

Section ID: `B366794F-FF87-1144-0F65-1FE56ED41042`

Import key: `logic/ch01-foundations-fa.html#section-05`

Topic ID: `F3739AF3-25FA-521F-89C9-1DF9A50DACCE`

Source: [logic/ch01-foundations-fa.html](../../../database-sources/logic/0B42FE17-B855-76B8-08E2-BED445C24111.html) — ID `0B42FE17-B855-76B8-08E2-BED445C24111`

مثال آموزشی
F
Example 1 — برای درک مفهوم
Break the following claim into its parts: "If John studies hard, then he will pass the test and make his parents proud."
= "John studies hard"
= "He will pass the test"
= "He will make his parents proud"
A
B
C
فرم نمادین:
— یک شرطی که نتیجه‌اش خودش یک عطفه.
If A then (B and C)

## Gمثال امتحانی

Section ID: `83F18F3F-0D24-FB20-732F-76744CEAF437`

Import key: `logic/ch01-foundations-fa.html#section-06`

Topic ID: `F3739AF3-25FA-521F-89C9-1DF9A50DACCE`

Source: [logic/ch01-foundations-fa.html](../../../database-sources/logic/0B42FE17-B855-76B8-08E2-BED445C24111.html) — ID `0B42FE17-B855-76B8-08E2-BED445C24111`

مثال امتحانی
G
Example 2 — CEnT style
Consider the claim: "If (A or B) then (C and not-D)." Which of the following correctly identifies its structure?
A) A conjunction whose parts are two conditionals
B) A conditional whose antecedent is a disjunction and whose consequent is a conjunction
C) A disjunction whose parts are two conjunctions
D) A negation of a conditional
از کجا شروع کنیم؟
اول عملگری رو پیدا کن که کل جمله رو کنترل می‌کنه — کلمه‌ای که سرتاسر جمله زیر پوشش اونه. اینجا «If … then …» هست، پس کل گزاره یک شرطیه.
چه اطلاعاتی مهمه؟
مقدم (قبل از «then») «(A or B)» است — یک فصل. نتیجه (بعد از «then») «(C and not-D)» است — یک عطف.
چی حواس‌پرت‌کنه؟
گزینه‌های A و C هر دو عملگر بیرونی رو اشتباه می‌فهمن — به‌جای اینکه به کلمه‌ی «If…then» که کل جمله رو نگه داشته توجه کنن، فقط پرانتزهای داخلی رو خوندن. گزینه D هم به‌غلط فرض می‌کنه کل جمله نقیض شده، در حالی که فقط D (داخل نتیجه) نقیض شده.
چرا این روش مطمئن‌تره؟
حرکت از بیرون به داخل تضمین می‌کنه که اول عملگری که کل گزاره رو کنترل می‌کنه پیدا کنی، قبل از اینکه ساختار داخلی حواست رو پرت کنه — این رایج‌ترین منبع اشتباه در خوندن ساختار سوالاته.
🎯 EXAM TIP
قبل از خوندن یک گزاره‌ی ترکیبی برای فهمیدن معنیش، یک بار فقط دنبال کلمات عملگر بگرد:
. زیرشون خط بکش. این کار پنج ثانیه طول می‌کشه ولی بزرگ‌ترین منبع اشتباه — یعنی اشتباه گرفتن عملگری که واقعاً کل جمله رو کنترل می‌کنه — رو از بین می‌بره.
and, or, if…then, not, unless, only if
⚠️ COMMON MISTAKES
عملگری که از نظر ظاهری وسط جمله قرار داره رو «عملگر اصلی» در نظر گرفتن، به‌جای عملگری که واقعاً کل گزاره رو کنترل می‌کنه.
اشتباه:
تحت فشار زمانی، داوطلب از چپ به راست می‌خونه و روی اولین کلمه‌ی عملگری که می‌بینه قفل می‌کنه، به‌جای اینکه چک کنه کدوم عملگر بیرون همه‌ی پرانتزها و بندهای جمله قرار داره.
چرا اتفاق می‌افته:
همیشه از خودت بپرس: «اگه همه‌ی جزئیات داخلی رو کنار بذارم، کدوم یک کلمه دو تکه‌ی بزرگ این جمله رو به هم وصل می‌کنه؟» اون کلمه، عملگر بیرونیه — بقیه همه داخل اون قرار دارن.
چطور جلوش رو بگیریم:
🧠 MUST REMEMBER
هر گزاره‌ی ترکیبی در این آزمون به چهار عملگر پایه ختم می‌شه:
. اول عملگر بیرونی رو پیدا کن — همون که ساختار کلی گزاره رو تعیین می‌کنه.
and, or, if…then, not

## 📝تمرین

Section ID: `0EF7B465-774E-D02F-E350-00255C01E5AC`

Import key: `logic/ch01-foundations-fa.html#section-07`

Topic ID: `F3739AF3-25FA-521F-89C9-1DF9A50DACCE`

Source: [logic/ch01-foundations-fa.html](../../../database-sources/logic/0B42FE17-B855-76B8-08E2-BED445C24111.html) — ID `0B42FE17-B855-76B8-08E2-BED445C24111`

تمرین
📝
آسان
"John is at the movies or he is at the library." What kind of compound claim is this?
A) Conjunction
B) Disjunction
C) Conditional
D) Negation
نمایش پاسخ و توضیح
کلمه‌ی «or» دو گزاره‌ی کامل («John is at the movies» و «he is at the library») رو به هم وصل کرده — این دقیقاً الگوی مشخص‌کننده‌ی یک disjunction است. نه عطفه (چون «and» نداره)، نه شرطیه (چون «if…then» نداره)، و چیزی هم نقیض نشده.
پاسخ درست: B.
متوسط
"If it is not the case that Sara is late, then the meeting will start on time." Identify A (the antecedent) in symbolic terms.
A) "Sara is late"
B) "not-(Sara is late)"
C) "The meeting will start on time"
D) "not-(the meeting will start on time)"
نمایش پاسخ و توضیح
مقدم (antecedent) هر چیزیه که بین «If» و «then» قرار داره. اینجا «it is not the case that Sara is late» است — یعنی نقیضِ گزاره‌ی «Sara is late». گزینه‌ی A نقیض رو حذف می‌کنه؛ C و D هر دو نتیجه (consequent) رو با مقدم اشتباه می‌گیرن.
پاسخ درست: B.
سخت
"Dan will go to law school and become a priest, or he will travel the world." What is the outermost connective?
A) and
B) or
C) if…then
D) not
نمایش پاسخ و توضیح
جمله رو به‌صورت دو تکه‌ی بزرگ بخون: «[Dan will go to law school and become a priest]»
«[he will travel the world]». «and» واقعیه، ولی
تکه‌ی اول قرار داره — فقط «go to law school» و «become a priest» رو به هم وصل می‌کنه. ویرگول قبل از «or» یک نشونه‌ی قویه که «or» همون عملگریه که کل جمله رو در بر می‌گیره. این دقیقاً همون نوع ساختار تودرتوییه که آزمون برای تست پیدا کردن عملگر واقعیِ بیرونی استفاده می‌کنه — طبق همون Exam Tip بالا.
پاسخ درست: B.
or
داخل

## 🚀مرور سریع — فصل ۱

Section ID: `96809741-F1B7-39BC-DA14-861E0F3BADBF`

Import key: `logic/ch01-foundations-fa.html#section-08`

Topic ID: `F3739AF3-25FA-521F-89C9-1DF9A50DACCE`

Source: [logic/ch01-foundations-fa.html](../../../database-sources/logic/0B42FE17-B855-76B8-08E2-BED445C24111.html) — ID `0B42FE17-B855-76B8-08E2-BED445C24111`

مرور سریع — فصل ۱
🚀
مفاهیم اصلی
هر گزاره یک ارزش درستی داره: T یا F.
گزاره‌های ترکیبی از ۴ عملگر ساخته می‌شن: and, or, if…then, not.
درستی کل گزاره فقط به درستی اجزا + قوانین عملگرها بستگی داره.
روش
اول کوچک‌ترین گزاره‌ها رو حرف‌گذاری کن.
عملگری که
جمله رو کنترل می‌کنه پیدا کن، نه فقط وسط جمله.
کل
از داخلی‌ترین بخش به بیرون حرکت کن.
اشتباهات رایج
چسبیدن به اولین عملگری که دیده می‌شه، نه عملگر بیرونی.
ندیدن ویرگولی که محل تقسیم واقعی جمله رو نشون می‌ده.
نکات امتحانی
قبل از خوندن برای معنی، زیر کلمات عملگر خط بکش.
بپرس: «کدوم یک کلمه دو تکه‌ی بزرگ رو به هم وصل می‌کنه؟»
