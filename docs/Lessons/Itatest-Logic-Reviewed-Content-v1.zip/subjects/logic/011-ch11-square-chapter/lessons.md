# فصل ۱۱: مربع تعارض — Square of Opposition

Original chapter ID: `FAFDCCF6-05DF-2E2E-9B0A-04DE276D7E3B`

Original chapter import key: `logic/ch11-square.html#chapter`

## فصل ۱۱: مربع تعارض — Square of Opposition

Section ID: `49C8CD19-5E39-548A-161D-9CB401092F95`

Import key: `logic/ch11-square.html#intro`

Topic ID: `1CDE6105-4E86-5A1A-60C3-E933C5AA7D62`

Source: [logic/ch11-square.html](../../../database-sources/logic/C567E022-D4EF-F1C6-B839-10579E95365D.html) — ID `C567E022-D4EF-F1C6-B839-10579E95365D`

CENT LOGIC — PART A · CHAPTER 11 / 13
فصل ۱۱: مربع تعارض — Square of Opposition
حالا که با نقیضِ گزاره‌های قیاسی آشنا شدی، این فصل همه‌شون رو در یک دیاگرام واحد کنار هم می‌ذاره — و دو رابطه‌ی جدید (contrary و subcontrary) رو معرفی می‌کنه که با contradictory فرق دارن.

## Bاین مبحث چیست؟

Section ID: `EB9DA3F1-8432-30F6-CDA1-4B9819D906B6`

Import key: `logic/ch11-square.html#section-01`

Topic ID: `1CDE6105-4E86-5A1A-60C3-E933C5AA7D62`

Source: [logic/ch11-square.html](../../../database-sources/logic/C567E022-D4EF-F1C6-B839-10579E95365D.html) — ID `C567E022-D4EF-F1C6-B839-10579E95365D`

این مبحث چیست؟
B
چهار گزاره‌ی پایه‌ی قیاسی — All A are B، No A are B، Some A are B، Some A are not B — رو می‌شه در چهار گوشه‌ی یک مربع فرضی چید. هر ضلع و هر قطر این مربع، یک رابطه‌ی منطقیِ متفاوت بین دو گوشه رو نشون می‌ده.
UNIVERSAL AFFIRMATIVE
All A are B
UNIVERSAL NEGATIVE
No A are B
PARTICULAR AFFIRMATIVE
Some A are B
PARTICULAR NEGATIVE
Some A are not B
بالا ↔ بالا:
• 
      پایین ↔ پایین:
• 
      قطرها (بالا-چپ ↔ پایین-راست، بالا-راست ↔ پایین-چپ):
contrary
subcontrary
contradictory

## Cمفهوم اصلی

Section ID: `D57C43DF-4A5C-2F84-BE50-EB1C100F8987`

Import key: `logic/ch11-square.html#section-02`

Topic ID: `1CDE6105-4E86-5A1A-60C3-E933C5AA7D62`

Source: [logic/ch11-square.html](../../../database-sources/logic/C567E022-D4EF-F1C6-B839-10579E95365D.html) — ID `C567E022-D4EF-F1C6-B839-10579E95365D`

C
مفهوم اصلی
نکتهٔ مهم: روابط بالایی و پایینی مربع تعارض سنتی (contrary و subcontrary و استنتاج‌های وابسته به آن‌ها) فقط با فرض وجود دست‌کم یک عضو در دستهٔ A برقرارند. در منطق محمولات جدید اگر A تهی باشد، All A are B و No A are B هر دو درست و هر دو گزارهٔ Some غلط‌اند. روابط قطری نقیض، حتی در این حالت نیز معتبرند.
قدم ۱ — روابط قطری (contradictory) را از فصل ۱۰ می‌شناسی.
«All A are B» ↔ «Some A are not B» (نقیض هم هستن)
«No A are B» ↔ «Some A are B» (نقیض هم هستن)
یادت باشه از فصل ۵: رابطه‌ی contradictory یعنی دقیقاً یکی درست و یکی غلط — همیشه، بدون استثنا. این یعنی اگه ارزش درستیِ یکی رو بدونی، ارزش درستیِ اون یکیِ قطری رو
قطعاً و کاملاً
می‌دونی.
قدم ۲ — رابطه‌ی contrary (ضلع بالا): «All A are B» و «No A are B» نمی‌تونن هم‌زمان هر دو درست باشن، ولی می‌تونن هم‌زمان هر دو غلط باشن.
نمونه
"All dogs are brown." (False) — "No dogs are brown." (also False, since SOME dogs are brown and some aren't)
این دقیقاً همون تعریف contrary از فصل ۵ است، فقط اینجا روی دو گزاره‌ی قیاسیِ کلی (universal) اعمال شده.
قدم ۳ — رابطه‌ی subcontrary (ضلع پایین): «Some A are B» و «Some A are not B» نمی‌تونن هم‌زمان هر دو غلط باشن، ولی می‌تونن هم‌زمان هر دو درست باشن.
این دقیقاً برعکسِ contrary است.
نمونه
"Some dogs are brown." (True) — "Some dogs are not brown." (also True, if the group of dogs is mixed)
اگه دسته‌ی A حداقل یک عضو داشته باشه، همیشه یا «Some A are B» یا «Some A are not B» (یا هر دو) درسته — نمی‌شه هر دو هم‌زمان غلط باشن.
قدم ۴ — تفاوت کلیدی: contradictory جهت رو کاملاً مشخص می‌کنه، ولی contrary و subcontrary فقط یک جهت رو مشخص می‌کنن.
اگه «All A are B» درست باشه (contrary)، مطمئنی «No A are B» غلطه — ولی اگه «All A are B» غلط باشه، از این تنها نمی‌تونی بگی «No A are B» چیه (می‌تونه درست یا غلط باشه).
اگه «Some A are B» غلط باشه (subcontrary)، مطمئنی «Some A are not B» درسته — ولی اگه «Some A are B» درست باشه، از این تنها نمی‌تونی بگی «Some A are not B» چیه.

## Dقوانین و اصول مهم

Section ID: `88D43490-34F3-8253-397C-7CEDEF64D70C`

Import key: `logic/ch11-square.html#section-03`

Topic ID: `1CDE6105-4E86-5A1A-60C3-E933C5AA7D62`

Source: [logic/ch11-square.html](../../../database-sources/logic/C567E022-D4EF-F1C6-B839-10579E95365D.html) — ID `C567E022-D4EF-F1C6-B839-10579E95365D`

D
قوانین و اصول مهم
رابطه
دو گوشه
قانون
Contradictory
All↔Some-not ، No↔Some
همیشه دقیقاً یکی درست، یکی غلط
Contrary
All ↔ No
با فرض وجود عضو در A، هر دو نمی‌تونن درست باشن؛ هر دو می‌تونن غلط باشن
Subcontrary
Some ↔ Some-not
با فرض وجود عضو در A، هر دو نمی‌تونن غلط باشن؛ هر دو می‌تونن درست باشن

## Eروش حل

Section ID: `0C35B594-8907-017B-205E-F32266FDDCC5`

Import key: `logic/ch11-square.html#section-04`

Topic ID: `1CDE6105-4E86-5A1A-60C3-E933C5AA7D62`

Source: [logic/ch11-square.html](../../../database-sources/logic/C567E022-D4EF-F1C6-B839-10579E95365D.html) — ID `C567E022-D4EF-F1C6-B839-10579E95365D`

روش حل
E
مشخص کن دو گزاره‌ی داده‌شده در کدوم گوشه‌های مربع قرار می‌گیرن.
رابطه‌شون رو تشخیص بده: قطری (contradictory)، بالا (contrary)، یا پایین (subcontrary).
اگه contradictory بود، ارزش درستیِ دومی رو کاملاً و مستقیم از اولی بگیر (برعکسش کن).
اگه contrary یا subcontrary بود، فقط طبق قانون یک‌طرفه‌ی مربوطه نتیجه بگیر — در جهت دیگه، «cannot be determined» جواب درسته.
→ جواب: طبق نوع رابطه.

## Fمثال آموزشی

Section ID: `7ACDAAC7-008A-2782-6840-10E866DCDF02`

Import key: `logic/ch11-square.html#section-05`

Topic ID: `1CDE6105-4E86-5A1A-60C3-E933C5AA7D62`

Source: [logic/ch11-square.html](../../../database-sources/logic/C567E022-D4EF-F1C6-B839-10579E95365D.html) — ID `C567E022-D4EF-F1C6-B839-10579E95365D`

مثال آموزشی
F
Example 1 — برای درک مفهوم
If "All students passed the exam" is FALSE, what can we conclude about "No students passed the exam"?
این دو گزاره رابطه‌ی contrary دارن. طبق قدم ۴، وقتی یکی از دو contrary غلط باشه، اون یکی می‌تونه درست یا غلط باشه — مثلاً ممکنه بعضی دانش‌آموزها قبول شده باشن و بعضی نه (که هر دو گزاره غلط می‌شن)، یا ممکنه هیچ‌کس قبول نشده باشه (که «No students passed» درست می‌شه).
پاسخ: نمی‌تونیم چیزی قطعی نتیجه بگیریم.

## Gمثال امتحانی

Section ID: `73F07421-C2BF-8EB6-C7D9-148D496020B7`

Import key: `logic/ch11-square.html#section-06`

Topic ID: `1CDE6105-4E86-5A1A-60C3-E933C5AA7D62`

Source: [logic/ch11-square.html](../../../database-sources/logic/C567E022-D4EF-F1C6-B839-10579E95365D.html) — ID `C567E022-D4EF-F1C6-B839-10579E95365D`

مثال امتحانی
G
Example 2 — CEnT style
We are told: "Some applicants were rejected" is FALSE. What must be true about "Some applicants were not rejected"?
A) It must also be false.
B) It must be true.
C) It cannot be determined.
D) It is true only if all applicants applied on the same day.
از کجا شروع کنیم؟
این دو گزاره — «Some applicants were rejected» و «Some applicants were not rejected» — رابطه‌ی subcontrary دارن (هر دو از فرم «Some»، یکی مثبت یکی منفی).
چه اطلاعاتی مهمه؟
طبق قانون subcontrary در قدم ۴، این دو نمی‌تونن هم‌زمان هر دو غلط باشن. چون یکیشون («Some…rejected») غلطه، اون یکی («Some…not rejected») مجبوره درست باشه.
چی حواس‌پرت‌کنه؟
گزینه‌ی A دقیقاً برعکسِ قانون subcontrary است — انگار فکر کرده رابطه‌شون contrary یا contradictory با همون جهته. گزینه‌ی D هم اطلاعات کاملاً بی‌ربطی اضافه می‌کنه.
چرا این روش مطمئن‌تره؟
چون به‌جای حدس زدن، مستقیماً نوع رابطه (subcontrary) رو تشخیص دادیم و قانون یک‌طرفه‌ی دقیقش رو اعمال کردیم.
🎯 EXAM TIP
برای به‌خاطر سپردن جهت‌ها:
این دو دقیقاً آینه‌ی هم هستن.
Contrary «بالای مربع» (هر دو کلی/universal) — نمی‌تونن با هم درست باشن.
Subcontrary «پایین مربع» (هر دو جزئی/particular) — نمی‌تونن با هم غلط باشن.
⚡ QUICK METHOD
اگه سؤال از رابطه‌ی قطری (contradictory) پرسید، جواب همیشه قطعی و مستقیمه (برعکس کردن ارزش درستی). اگه از رابطه‌ی بالا یا پایین (contrary/subcontrary) پرسید، اول چک کن کدوم جهت اطلاعات قطعی می‌ده — قانونش فقط یک‌طرفه‌ست، نه دوطرفه.
⚠️ COMMON MISTAKES
برخورد با رابطه‌ی contrary یا subcontrary مثل contradictory — یعنی فرض کردن که دونستنِ ارزش درستیِ یکی، همیشه ارزش درستیِ اون یکی رو هم قطعاً مشخص می‌کنه.
اشتباه:
هر سه رابطه (contradictory، contrary، subcontrary) شبیه به‌هم به‌نظر می‌رسن چون همه درباره‌ی جفت گزاره‌های مرتبطن، ولی فقط contradictory قدرتِ استنتاجِ کامل و دوطرفه داره.
چرا اتفاق می‌افته:
همیشه اول نوع دقیق رابطه رو مشخص کن (با جدول قدم ۴)، و فقط طبق همون یک قانونِ خاص جلو برو — نه با قیاس با contradictory.
چطور جلوش رو بگیریم:
🪤 QUESTION TRAP
سؤال ممکنه یک گزاره‌ی contrary یا subcontrary رو غلط بده و از تو بخواد نتیجه بگیری اون یکی هم غلطه یا درسته، در جهتی که قانونش اجازه‌ی این استنتاج رو نمی‌ده. همیشه دقت کن که آیا سؤال داره از جهتِ «مجازِ» رابطه سؤال می‌کنه یا از جهتِ «نامشخص»ش — جواب درست در جهتِ نامشخص همیشه «cannot be determined» است.
🧠 MUST REMEMBER
(All ↔ No): نمی‌تونن با هم درست باشن؛ می‌تونن با هم غلط باشن.
(Some ↔ Some-not): نمی‌تونن با هم غلط باشن؛ می‌تونن با هم درست باشن.
(قطرها): همیشه دقیقاً یکی درست، یکی غلط.
Contrary
Subcontrary
Contradictory

## 📝تمرین

Section ID: `A7A6A65A-9C6C-9FA3-FCE9-C7202DBE4EAA`

Import key: `logic/ch11-square.html#section-07`

Topic ID: `1CDE6105-4E86-5A1A-60C3-E933C5AA7D62`

Source: [logic/ch11-square.html](../../../database-sources/logic/C567E022-D4EF-F1C6-B839-10579E95365D.html) — ID `C567E022-D4EF-F1C6-B839-10579E95365D`

📝
تمرین
آسان
"No committee members voted against the proposal" is TRUE. What follows about "Some committee members voted against the proposal"?
A) It must be false (contradictory relation).
B) It must be true.
C) It cannot be determined.
D) It is true only if the vote was unanimous.
نمایش پاسخ و توضیح
پاسخ درست: A.
«No A are B» و «Some A are B» رابطه‌ی قطری (contradictory) دارن. چون یکی درسته، اون یکی قطعاً غلطه.
متوسط
At least one flight operated. "All flights were delayed" is TRUE. What follows about "No flights were delayed"?
A) It must be true.
B) It must be false.
C) It cannot be determined.
D) It is true only for international flights.
نمایش پاسخ و توضیح
پاسخ درست: B.
چون دست‌کم یک پرواز وجود دارد و همهٔ پروازها تأخیر داشته‌اند، گزارهٔ «هیچ پروازی تأخیر نداشت» غلط است. بدون فرض وجود، هر دو گزارهٔ کلی ممکن است به‌صورت تهی درست باشند.
سخت
We only know: "Some reviewers approved the manuscript" is TRUE. Which of the following can we determine with certainty about "Some reviewers did not approve the manuscript"?
A) It must be true, since they are subcontraries.
B) It must be false.
C) It cannot be determined from this information alone.
D) It is automatically true if there are at least two reviewers.
نمایش پاسخ و توضیح
پاسخ درست: C.
این دو گزاره رابطه‌ی subcontrary دارن. قانونِ subcontrary فقط جهت «هر دو نمی‌تونن غلط باشن» رو تضمین می‌کنه — یعنی اگه یکی غلط بود، اون یکی حتماً درسته. اما اینجا داریم گفته می‌شه یکی («Some…approved»)
درسته
، نه غلط — و از درست بودنِ یکی از دو subcontrary، هیچ اطلاعاتِ قطعی‌ای درباره‌ی اون یکی به‌دست نمیاد (می‌تونه همه‌ی داوران تأیید کرده باشن، که در این صورت "Some did not approve" غلط می‌شه؛ یا بعضی تأیید نکرده باشن، که در این صورت درست می‌شه). گزینه‌ی A دقیقاً همون اشتباه رایج «اعمال قانون در جهتِ اشتباه» است.

## 🚀مرور سریع — فصل ۱۱

Section ID: `D12FC680-67FA-9A93-1CB3-F725C543F6B8`

Import key: `logic/ch11-square.html#section-08`

Topic ID: `1CDE6105-4E86-5A1A-60C3-E933C5AA7D62`

Source: [logic/ch11-square.html](../../../database-sources/logic/C567E022-D4EF-F1C6-B839-10579E95365D.html) — ID `C567E022-D4EF-F1C6-B839-10579E95365D`

مرور سریع — فصل ۱۱
🚀
مفاهیم اصلی
Contrary (All↔No): هر دو درست نمی‌شن؛ هر دو غلط می‌تونن بشن.
Subcontrary (Some↔Some-not): هر دو غلط نمی‌شن؛ هر دو درست می‌تونن بشن.
Contradictory (قطرها): همیشه دقیقاً یکی درست، یکی غلط.
روش
اول نوع رابطه رو مشخص کن.
فقط قانونِ همون رابطه رو اعمال کن — نه قیاس با contradictory.
اشتباهات رایج
فرض کردن استنتاج دوطرفه در contrary/subcontrary.
دام‌های تستی
سؤال از جهتِ «نامشخص» یک رابطه‌ی یک‌طرفه.
