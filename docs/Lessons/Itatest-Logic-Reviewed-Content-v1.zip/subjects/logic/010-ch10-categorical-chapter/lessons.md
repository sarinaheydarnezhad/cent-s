# فصل ۱۰: گزاره‌های قیاسی — Categorical Claims (All / Some / No / Only A are B)

Original chapter ID: `07043965-DF1E-6937-86F1-2D61A77E15D3`

Original chapter import key: `logic/ch10-categorical.html#chapter`

## فصل ۱۰: گزاره‌های قیاسی — Categorical Claims (All / Some / No / Only A are B)

Section ID: `92BF04C9-AA79-075C-D995-6D5FF6EBC1F9`

Import key: `logic/ch10-categorical.html#intro`

Topic ID: `95C4CB1C-1CCA-626D-C2CE-8A76B5C80485`

Source: [logic/ch10-categorical.html](../../../database-sources/logic/040CA2F5-3BDB-8995-C114-54E4EE8F53AC.html) — ID `040CA2F5-3BDB-8995-C114-54E4EE8F53AC`

CENT LOGIC — PART A · CHAPTER 10 / 13
فصل ۱۰: گزاره‌های قیاسی — Categorical Claims (All / Some / No / Only A are B)
تا اینجا با گزاره‌هایی سروکار داشتیم که کل جمله رو یک واحد در نظر می‌گرفتن. حالا وارد منطق قیاسی
می‌شیم — جایی که گزاره‌ها درباره‌ی رابطه‌ی بین دو
یا
صحبت می‌کنن.
(categorical logic)
دسته
گروه

## Bاین مبحث چیست؟

Section ID: `ECE1DE59-385E-E62C-387B-F92D3574F4B1`

Import key: `logic/ch10-categorical.html#section-01`

Topic ID: `95C4CB1C-1CCA-626D-C2CE-8A76B5C80485`

Source: [logic/ch10-categorical.html](../../../database-sources/logic/040CA2F5-3BDB-8995-C114-54E4EE8F53AC.html) — ID `040CA2F5-3BDB-8995-C114-54E4EE8F53AC`

این مبحث چیست؟
B
یک گزاره‌ی قیاسی، رابطه‌ی بین دو دسته (مثل «انسان‌ها» و «فانی‌ها») رو توصیف می‌کنه. این‌جور استدلال‌ها پایه‌ی سؤالات کلاسیک منطقی هستن:
نمونه‌ی استدلال
1. All humans are mortal.
2. Simon is human.
Therefore, Simon is mortal.
Form: 1. All H are M. 2. x is an H. Therefore, x is an M.
در این فصل روی سه فرم پایه‌ی «All»، «Some» و «Only» و نقیض هرکدوم تمرکز می‌کنیم — این‌ها ۶ نوع گزاره‌ی قیاسی رو می‌سازن (All A are B، Some A are B، No A are B، و نسخه‌های not-B اون‌ها).

## Cمفهوم اصلی

Section ID: `9BAAC24D-C5DD-8491-0240-AA71597C5D53`

Import key: `logic/ch10-categorical.html#section-02`

Topic ID: `95C4CB1C-1CCA-626D-C2CE-8A76B5C80485`

Source: [logic/ch10-categorical.html](../../../database-sources/logic/040CA2F5-3BDB-8995-C114-54E4EE8F53AC.html) — ID `040CA2F5-3BDB-8995-C114-54E4EE8F53AC`

C
مفهوم اصلی
در منطق کلاسیک، گزارهٔ کلی وجود اعضای دسته را تضمین نمی‌کند. برای اثبات وجود یک عضو باید داده یا گزارهٔ وجودی جداگانه داشته باشیم.
قدم ۱ — «All A are B»: هر عضو دسته‌ی A، عضو دسته‌ی B هم هست.
نمونه
"All humans are mortal." "All whales are mammals."
برای غلط کردن یک ادعای «All»، کافیه
یک استثنا
پیدا کنی. برای همین:
not-(All A are B) = Some A are not-B
.
نمونه‌های نقیض
"All humans are mortal." → "Some humans are not mortal.""All dogs bark." → "Some dogs don't bark."
قدم ۲ — «Some A are B»: حداقل یک عضو از A هست که عضو B هم هست.
«Some» یعنی «at least one» — نه لزوماً «بعضی ولی نه همه» (این معنی فقط گاهی از زمینه‌ی جمله برداشت می‌شه، نه از خودِ کلمه).
نمونه
"Some dogs have long hair." "There is a bird in that tree." (= "Some birds are in that tree")
برای غلط کردن یک ادعای «Some»، باید نشون بدی
هیچ
عضوی این ویژگی رو نداره. برای همین:
not-(Some A are B) = No A are B
.
نمونه‌های نقیض
"Some dogs have long hair." → "No dogs have long hair.""Some dogs don't have long hair." → "No dogs don't have long hair." (= "All dogs have long hair.")
قدم ۳ — «Only A are B»: این فرمِ گول‌زننه‌ست — جهتش برعکسِ چیزیه که در نگاه اول به‌نظر میاد!
«Only A are B» در واقع یعنی
All B are A
— یعنی هر عضو B، عضو A هم هست (نه برعکس).
نمونه
"Only dogs make good pets." = "All good pets are dogs.""Only Great White sharks are dangerous." = "All dangerous sharks are Great Whites."
این دقیقاً همون منطقیه که در فصل ۸ با «A only if B = B if A» دیدیم — کلمه‌ی «only» جهت رو برعکس می‌کنه.
چون «Only A are B» = «All B are A»، نقیضش هم از همون قانون قدم ۱ پیروی می‌کنه، فقط با جای A و B عوض‌شده:
not-(Only A are B) = Some B are not-A
.
نمونه‌های نقیض
"Only dogs make good pets." → "Some good pets are not dogs.""Only Starbucks makes good coffee." → "Some good coffee is not made by Starbucks."

## Dقوانین و اصول مهم — جدول جامع

Section ID: `536C28A0-14FB-C2F1-79C2-CD5AA1358CFE`

Import key: `logic/ch10-categorical.html#section-03`

Topic ID: `95C4CB1C-1CCA-626D-C2CE-8A76B5C80485`

Source: [logic/ch10-categorical.html](../../../database-sources/logic/040CA2F5-3BDB-8995-C114-54E4EE8F53AC.html) — ID `040CA2F5-3BDB-8995-C114-54E4EE8F53AC`

D
قوانین و اصول مهم — جدول جامع
گزاره
نقیضش
All A are B
Some A are not-B
Some A are B
No A are B
Only A are B
(=
All B are A
)
Some B are not-A
نقیضِ «All» همیشه یک «Some…not» است — فقط یک استثنا کافیه.
نقیضِ «Some» همیشه یک «No» است — باید نشون بدی هیچ عضوی از A ویژگی B را ندارد؛ ممکن است خود A اعضایی داشته باشد.
«Only A are B» را همیشه اول به «All B are A» تبدیل کن، بعد قوانین «All» رو روش اعمال کن.

## Eروش حل

Section ID: `85786BE5-E42A-21FF-7894-536AEEC74D1D`

Import key: `logic/ch10-categorical.html#section-04`

Topic ID: `95C4CB1C-1CCA-626D-C2CE-8A76B5C80485`

Source: [logic/ch10-categorical.html](../../../database-sources/logic/040CA2F5-3BDB-8995-C114-54E4EE8F53AC.html) — ID `040CA2F5-3BDB-8995-C114-54E4EE8F53AC`

روش حل
E
مشخص کن گزاره از کدوم فرم استفاده کرده: All، Some، یا Only.
اگه «Only» بود، اول جای دو دسته رو عوض کن و به فرم «All B are A» برگردون.
طبق جدول بالا، قانون نقیضِ مناسب رو اعمال کن.
با یک مثال ذهنی (یک عضو فرضی از دسته) جواب رو چک کن.
→ جواب: نقیضِ درستِ گزاره‌ی قیاسی.

## Fمثال آموزشی

Section ID: `5B5AB4C5-DC89-AF0F-AD94-BE349B1C507C`

Import key: `logic/ch10-categorical.html#section-05`

Topic ID: `95C4CB1C-1CCA-626D-C2CE-8A76B5C80485`

Source: [logic/ch10-categorical.html](../../../database-sources/logic/040CA2F5-3BDB-8995-C114-54E4EE8F53AC.html) — ID `040CA2F5-3BDB-8995-C114-54E4EE8F53AC`

مثال آموزشی
F
Example 1 — برای درک مفهوم
Write the contradictory of: "All Michael Moore films are not good."
"Some Michael Moore films are good." این گزاره از فرم «All A are not-B» است (A = فیلم‌های مایکل مور، not-B = خوب نبودن)؛ طبق قدم ۱، نقیضش «Some A are B» می‌شه — یعنی نقیضِ «not-B» که خودش «B» است.
پاسخ:

## Gمثال امتحانی

Section ID: `9271C94C-9206-BFF7-635B-82CAB44359BE`

Import key: `logic/ch10-categorical.html#section-06`

Topic ID: `95C4CB1C-1CCA-626D-C2CE-8A76B5C80485`

Source: [logic/ch10-categorical.html](../../../database-sources/logic/040CA2F5-3BDB-8995-C114-54E4EE8F53AC.html) — ID `040CA2F5-3BDB-8995-C114-54E4EE8F53AC`

G
مثال امتحانی
Example 2 — CEnT style
"Only certified electricians are permitted to install this equipment." Which of the following is logically equivalent to this claim?
A) "All certified electricians are permitted to install this equipment."
B) "All people permitted to install this equipment are certified electricians."
C) "Some certified electricians are not permitted to install this equipment."
D) "No certified electricians are permitted to install this equipment."
از کجا شروع کنیم؟
یادت باشه «Only A are B» = «All B are A» — جهت برعکس می‌شه. اینجا A = "certified electricians"، B = "people permitted to install this equipment".
چه اطلاعاتی مهمه؟
پس معادلش می‌شه: "All (people permitted to install this equipment) are (certified electricians)" — دقیقاً گزینه‌ی B.
چی حواس‌پرت‌کنه؟
گزینه‌ی A دقیقاً همون دام رایجیه که این فصل هشدارش رو می‌ده — جهت رو برعکس نکرده و A و B رو دست‌نخورده به فرم «All» چسبونده. گزینه‌های C و D هم اصلاً نقیضِ اصل ادعا هستن، نه معادلش.
چرا این روش مطمئن‌تره؟
چون به‌جای شهود، مستقیماً از فرمول «Only A are B = All B are A» استفاده کردیم که در فصل ۸ هم ریشه‌ی منطقی مشابهی داشت.
🎯 EXAM TIP
هر وقت به «Only A are B» رسیدی، فوراً در ذهنت بازنویسیش کن به «All B are A» — یعنی دسته‌ای که بعد از «are» اومده، دسته‌ی محدودکننده‌ست و همه‌ی اعضای دسته‌ی اول باید داخلش باشن.
⚡ QUICK METHOD
برای چک کردن سریعِ نقیضِ «All»، فقط دنبال یک استثنای فرضی بگرد: «آیا می‌تونم یک عضو از A تصور کنم که عضو B نباشه؟» اگه بله، همون یک استثنا نقیض «All A are B» رو می‌سازه: «Some A are not-B».
⚠️ COMMON MISTAKES
اشتباه:
خوندن «Only A are B» انگار همون «All A are B» است.
چرا اتفاق می‌افته:
هر دو جمله ظاهراً شبیه هم شروع می‌شن و ترتیب کلماتِ A و B هم یکسانه، پس ذهن به‌راحتی فکر می‌کنه معنیشون هم یکیه — در حالی که جهت رابطه‌شون کاملاً برعکسه.
چطور جلوش رو بگیریم:
همیشه قبل از هر تحلیلی، «Only A are B» رو دستی به «All B are A» تبدیل کن؛ این یک قدم اجباریه، نه اختیاری.
🪤 QUESTION TRAP
دقت کن «No A are B» با «All A are not-B» یکی هستن (هر دو می‌گن هیچ عضو مشترکی بین A و B نیست)، ولی «All A are not-B» با «not-(All A are B)» کاملاً فرق دارن — دومی یعنی «Some A are not B» (طبق قدم ۱)! این شباهت ظاهریِ کلمات، یکی از رایج‌ترین دام‌های طراحی‌شده در گزینه‌های امتحانه.
🧠 MUST REMEMBER
not-(All A are B) = Some A are not-B
|
not-(Some A are B) = No A are B
|
Only A are B = All B are A
(جهت برعکس!)  |  نقیضِ «Only A are B» =
Some B are not-A
.

## 📝تمرین

Section ID: `92ADDED4-50EB-D54E-C694-D12D2964B725`

Import key: `logic/ch10-categorical.html#section-07`

Topic ID: `95C4CB1C-1CCA-626D-C2CE-8A76B5C80485`

Source: [logic/ch10-categorical.html](../../../database-sources/logic/040CA2F5-3BDB-8995-C114-54E4EE8F53AC.html) — ID `040CA2F5-3BDB-8995-C114-54E4EE8F53AC`

📝
تمرین
آسان
What is the contradictory of "Some employees received a bonus this year"?
A) "All employees received a bonus this year."
B) "No employees received a bonus this year."
C) "Some employees did not receive a bonus this year."
D) "All employees did not receive a bonus this year."
نمایش پاسخ و توضیح
پاسخ درست: B.
طبق قدم ۲، نقیضِ «Some A are B» همیشه «No A are B» است.
متوسط
"Only members with a gold pass can access the VIP lounge." Which is logically equivalent?
A) "All members with a gold pass can access the VIP lounge."
B) "Everyone who can access the VIP lounge is a member with a gold pass."
C) "Some members with a gold pass cannot access the VIP lounge."
D) "No members with a gold pass can access the VIP lounge."
نمایش پاسخ و توضیح
پاسخ درست: B.
Only A are B یعنی All B are A. هر فرد دارای دسترسی باید هم عضو باشد و هم کارت طلایی داشته باشد؛ صرف داشتن کارت کافی نیست.
سخت
A company policy states: "Only senior engineers are authorized to approve deployments." An audit reveals: "At least one non-senior engineer was authorized to approve deployments." Does this finding contradict the policy?
A) Yes — it provides an authorized approver who is not a senior engineer.
B) No — authorization is unrelated to the policy.
C) Cannot be determined without knowing how many deployments were approved.
D) No — only-statements cannot be contradicted.
نمایش پاسخ و توضیح
پاسخ درست: A.
سیاست دربارهٔ مجاز بودن است، نه صرف انجام عمل. وجود فرد غیرارشدِ دارای مجوز نقیض مستقیم سیاست است.

## 🚀مرور سریع — فصل ۱۰

Section ID: `3AE9FEBF-583D-AC3C-93F5-F722A3992D90`

Import key: `logic/ch10-categorical.html#section-08`

Topic ID: `95C4CB1C-1CCA-626D-C2CE-8A76B5C80485`

Source: [logic/ch10-categorical.html](../../../database-sources/logic/040CA2F5-3BDB-8995-C114-54E4EE8F53AC.html) — ID `040CA2F5-3BDB-8995-C114-54E4EE8F53AC`

مرور سریع — فصل ۱۰
🚀
مفاهیم اصلی
All A are B ↔ نقیض: Some A are not-B
Some A are B ↔ نقیض: No A are B
Only A are B = All B are A (جهت برعکس)
روش
«Only» رو همیشه اول به «All B are A» تبدیل کن.
برای نقیضِ «All»، دنبال یک استثنا بگرد.
اشتباهات رایج
خوندن «Only A are B» مثل «All A are B».
قاطی کردن «All A are not-B» با «not-(All A are B)».
دام‌های تستی
شباهت ظاهریِ «No A are B» و نقیض‌های نزدیک به هم.
