# فصل ۹: شرط لازم و کافی — Necessary and Sufficient Conditions

Original chapter ID: `1B9F9E73-DCC2-56A9-79C8-3B61C31FD9C7`

Original chapter import key: `logic/ch09-necessary-sufficient.html#chapter`

## فصل ۹: شرط لازم و کافی — Necessary and Sufficient Conditions

Section ID: `EB1B4CE8-F80B-A5C7-BB77-33E6D638D7B1`

Import key: `logic/ch09-necessary-sufficient.html#intro`

Topic ID: `11ECE97E-6CB5-A8AA-68B9-FD269C7AE1B5`

Source: [logic/ch09-necessary-sufficient.html](../../../database-sources/logic/2D0B80D9-A16D-5BF5-FD86-DA0844DF0087.html) — ID `2D0B80D9-A16D-5BF5-FD86-DA0844DF0087`

CENT LOGIC — PART A · CHAPTER 9 / 13 · 🔴 CHALLENGE
فصل ۹: شرط لازم و کافی — Necessary and Sufficient Conditions
کلمات «necessary» و «sufficient» فقط یک زبان دیگه برای گفتن همون «If A then B» هستن — ولی هر کدوم از یک زاویه‌ی متفاوت به رابطه نگاه می‌کنن. این فصل مستقیماً روی چیزی که در فصل ۸ یاد گرفتی بنا می‌شه.

## Bاین مبحث چیست؟

Section ID: `39B07325-94C8-FE4A-848F-4057C6096FA4`

Import key: `logic/ch09-necessary-sufficient.html#section-01`

Topic ID: `11ECE97E-6CB5-A8AA-68B9-FD269C7AE1B5`

Source: [logic/ch09-necessary-sufficient.html](../../../database-sources/logic/2D0B80D9-A16D-5BF5-FD86-DA0844DF0087.html) — ID `2D0B80D9-A16D-5BF5-FD86-DA0844DF0087`

این مبحث چیست؟
B
وقتی سؤال می‌گه «X برای Y لازمه (necessary)» یا «X برای Y کافیه (sufficient)»، در واقع داره یک گزاره‌ی شرطی رو توصیف می‌کنه — فقط باید بدونی هر کلمه به کدوم جهت اشاره می‌کنه.

## Cمفهوم اصلی

Section ID: `8C2AA631-29B2-FB0C-F570-C372BA977613`

Import key: `logic/ch09-necessary-sufficient.html#section-02`

Topic ID: `11ECE97E-6CB5-A8AA-68B9-FD269C7AE1B5`

Source: [logic/ch09-necessary-sufficient.html](../../../database-sources/logic/2D0B80D9-A16D-5BF5-FD86-DA0844DF0087.html) — ID `2D0B80D9-A16D-5BF5-FD86-DA0844DF0087`

مفهوم اصلی
C
یعنی وجود A به‌تنهایی برای تضمین B کافیه — هرچند ممکنه B از راه‌های دیگه هم اتفاق بیفته.
قدم ۱ — «A sufficient for B» (A برای B کافیه) = «If A then B».
نمونه
"If I become rich, then I'll be happy."
→ "Becoming rich" is
for "being happy."
sufficient
پولدار شدن به‌تنهایی کافیه تا خوشحال بشم — ولی شاید از راه‌های دیگه‌ای هم (بدون پولدار شدن) بشه خوشحال بود.
(که هم‌ارزه با «If not-A then not-B»). یعنی بدون A، رسیدن به B غیرممکنه — A یک پیش‌نیازه.
قدم ۲ — «A necessary for B» (A برای B لازمه) = «If B then A»
نمونه
"Oxygen is necessary for combustion."
= "If there's combustion, then there's oxygen."
= "If there's no oxygen, then there's no combustion."
قدم ۳ — نکته‌ی کلیدی: یک شرطیِ واحد، هم‌زمان می‌تونه هم «sufficient» و هم «necessary» توصیف بشه — فقط بستگی داره از کدوم طرف نگاهش کنی.
نمونه
"If I have a driver's license, then I passed a driver's test."
این یک گزاره‌ی شرطیه، ولی دو تا توصیف داره:
"Passing a driver's test" is
for "having a driver's license." (چون بدون قبولی در آزمون، نمی‌شه گواهینامه داشت)
necessary
"Having a driver's license" is
for "passing a driver's test." (چون داشتن گواهینامه به‌تنهایی تضمین می‌کنه که آزمون رو قبول شدی)
sufficient
هر دو جمله دقیقاً همون یک شرطی رو توصیف می‌کنن — فقط از دو زاویه.
یعنی هر دو جهت («If A then B» و «If B then A») هم‌زمان برقرارن — همون بایکاندیشنالِ فصل ۸.
قدم ۴ — «A necessary AND sufficient for B» = «A if and only if B».

## Dقوانین و اصول مهم

Section ID: `6BBB0F74-3AB2-4056-AFB5-08F1446EB2F1`

Import key: `logic/ch09-necessary-sufficient.html#section-03`

Topic ID: `11ECE97E-6CB5-A8AA-68B9-FD269C7AE1B5`

Source: [logic/ch09-necessary-sufficient.html](../../../database-sources/logic/2D0B80D9-A16D-5BF5-FD86-DA0844DF0087.html) — ID `2D0B80D9-A16D-5BF5-FD86-DA0844DF0087`

قوانین و اصول مهم
D
توصیف
معادل شرطی
A necessary for B
If B then A
A sufficient for B
If A then B
A necessary and sufficient for B
If A then B
If B then A
and
«Sufficient» همیشه با مقدم (بخش if) یک شرطی مچ می‌شه.
«Necessary» همیشه با تالی (بخش then) یک شرطی مچ می‌شه.
یک شرطیِ واحد، هم‌زمان از دو زاویه قابل توصیفه: «مقدم برای تالی کافیه» و «تالی برای مقدم لازمه».

## Eروش حل

Section ID: `C4FCF94C-AF30-FCF3-A779-C2A8A9F83225`

Import key: `logic/ch09-necessary-sufficient.html#section-04`

Topic ID: `11ECE97E-6CB5-A8AA-68B9-FD269C7AE1B5`

Source: [logic/ch09-necessary-sufficient.html](../../../database-sources/logic/2D0B80D9-A16D-5BF5-FD86-DA0844DF0087.html) — ID `2D0B80D9-A16D-5BF5-FD86-DA0844DF0087`

روش حل
E
مشخص کن کلمه‌ی «necessary» به‌کار رفته یا «sufficient».
اگه «sufficient»، همون چیزیه که مقدمِ شرطیه (If X then Y). اگه «necessary»، همون چیزیه که تالیه (If Y then X).
جمله رو به فرم استاندارد «If…then» بازنویسی کن.
اگه لازم شد، از هم‌ارزیِ contrapositive (فصل ۸) هم برای بیان دیگه‌ای از همون رابطه استفاده کن.
→ جواب: گزاره‌ی شرطیِ استاندارد.

## Fمثال آموزشی

Section ID: `4A041795-C919-4166-EE20-B0BC4338BCE3`

Import key: `logic/ch09-necessary-sufficient.html#section-05`

Topic ID: `11ECE97E-6CB5-A8AA-68B9-FD269C7AE1B5`

Source: [logic/ch09-necessary-sufficient.html](../../../database-sources/logic/2D0B80D9-A16D-5BF5-FD86-DA0844DF0087.html) — ID `2D0B80D9-A16D-5BF5-FD86-DA0844DF0087`

مثال آموزشی
F
Example 1 — برای درک مفهوم
"Having a valid ticket is necessary for boarding the train." Rewrite this in standard "If...then" form.
"If a person boards the train, then they have a valid ticket." طبق قدم ۲، «necessary» همیشه تالیِ شرطیه — یعنی «boarding the train» مقدمه و «having a valid ticket» تالی.
پاسخ:

## Gمثال امتحانی

Section ID: `33C70BA1-224D-F441-4E99-C7B9317659CE`

Import key: `logic/ch09-necessary-sufficient.html#section-06`

Topic ID: `11ECE97E-6CB5-A8AA-68B9-FD269C7AE1B5`

Source: [logic/ch09-necessary-sufficient.html](../../../database-sources/logic/2D0B80D9-A16D-5BF5-FD86-DA0844DF0087.html) — ID `2D0B80D9-A16D-5BF5-FD86-DA0844DF0087`

مثال امتحانی
G
Example 2 — CEnT style
"Being a licensed pharmacist is sufficient to dispense prescription medication." Which of the following must be true, based only on this claim?
A) If a person is a licensed pharmacist, they can dispense prescription medication.
B) Only licensed pharmacists can dispense prescription medication.
C) If a person can dispense prescription medication, they are a licensed pharmacist.
D) Being a licensed pharmacist is also necessary to dispense prescription medication.
از کجا شروع کنیم؟
کلمه‌ی «sufficient» یعنی همون مقدمِ شرطیه. پس: "If (a person is a licensed pharmacist) then (they can dispense prescription medication)."
چه اطلاعاتی مهمه؟
این دقیقاً همون گزینه‌ی A است. سؤال فقط از یک جهت (sufficient) صحبت کرده — هیچ ادعایی درباره‌ی جهت برعکس (necessary) نکرده.
چی حواس‌پرت‌کنه؟
گزینه‌های B، C و D همه فرض می‌کنن که پروانه‌ی داروسازی
هم هست (یعنی راه دیگه‌ای برای تجویز دارو وجود نداره) — که این یک ادعای اضافه‌ست که در متن اصلی سؤال نیومده. شاید افراد دیگه‌ای (مثل پزشکان) هم بتونن دارو تجویز کنن؛ «sufficient» این امکان رو رد نمی‌کنه.
لازم
چرا این روش مطمئن‌تره؟
چون به‌جای فرض کردن یک رابطه‌ی دوطرفه، دقیقاً فقط همون یک جهتی که کلمه‌ی «sufficient» تضمین می‌کنه رو نتیجه گرفتیم.
🎯 EXAM TIP
یک ترفند حفظی:
(به‌تنهایی کافیه، پس مقدمه) و
(بدونش نمی‌شه، پس تالیه که باید همراه باشه). هر بار قبل از حل، این دو کلمه رو با معادل فارسیشون («کافی» و «لازم») تطبیق بده تا جهت رو گم نکنی.
Sufficient = Enough
Necessary = Needed
⚡ QUICK METHOD
یادت باشه از فصل ۸: «X only if Y» = «X is sufficient for Y» (چون هر دو یعنی «If X then Y»)، و «X if Y» = «X is necessary for Y» (چون هر دو یعنی «If Y then X»). اگه جمله‌ی «only if» یا «if» رو راحت‌تر می‌فهمی، همیشه می‌تونی بین این دو زبان جابه‌جا بشی.
⚠️ COMMON MISTAKES
جابه‌جا کردن جهت «necessary» و «sufficient» — مثلاً فکر کردن «A sufficient for B» یعنی «If B then A».
اشتباه:
این دو کلمه از نظر شهودی خیلی به هم شبیهن و بدون یک قاعده‌ی ثابت، ذهن به‌راحتی جهتشون رو با هم قاطی می‌کنه.
چرا اتفاق می‌افته:
همیشه اول جمله رو به فرم «If…then» ساده برگردون (طبق جدول قدم ۴)، و فقط بعد از اون با فرم استانداردی که بلدی (فصل ۴ و ۷) کار کن — به‌جای اینکه مستقیم با کلمات «necessary/sufficient» استدلال کنی.
چطور جلوش رو بگیریم:
🪤 QUESTION TRAP
وقتی سؤال فقط ادعای «necessary» (یا فقط «sufficient») می‌کنه، آزمون گزینه‌ای می‌ذاره که انگار رابطه دوطرفه‌ست (یعنی هم لازمه هم کافیه). همیشه چک کن که آیا متن سؤال واقعاً هر دو جهت رو گفته یا فقط یکی — دقیقاً مثل مثال امتحانی بالا.
🧠 MUST REMEMBER
=
|
=
|  هر دو با هم = بایکاندیشنال (iff). Sufficient ↔ مقدم، Necessary ↔ تالی.
A necessary for B
If B then A
A sufficient for B
If A then B

## 📝تمرین

Section ID: `B856B9D1-568A-EBCB-2FCD-BACF95569D30`

Import key: `logic/ch09-necessary-sufficient.html#section-07`

Topic ID: `11ECE97E-6CB5-A8AA-68B9-FD269C7AE1B5`

Source: [logic/ch09-necessary-sufficient.html](../../../database-sources/logic/2D0B80D9-A16D-5BF5-FD86-DA0844DF0087.html) — ID `2D0B80D9-A16D-5BF5-FD86-DA0844DF0087`

📝
تمرین
آسان
Assume that having a valid ticket is necessary for entering the venue. Which is the correct standard form?
A) If a person has a valid ticket, they enter the venue.
B) If a person enters the venue, they have a valid ticket.
C) A person enters the venue if and only if they have a valid ticket.
D) Having a valid ticket guarantees entry.
نمایش پاسخ و توضیح
پاسخ درست: B.
شرط لازم تالی شرطی است: اگر فرد وارد محل شود، باید بلیت معتبر داشته باشد. داشتن بلیت به‌تنهایی ورود را تضمین نمی‌کند.
متوسط
"Scoring above 90% is sufficient to receive an A grade." A student scored 95% but did NOT receive an A (due to an unrelated academic misconduct penalty). Does this contradict the original claim?
A) Yes — the claim guarantees an A for any score above 90%, with no stated exceptions.
B) No — "sufficient" only means it's possible to get an A, not guaranteed.
C) No — academic misconduct is a necessary condition, so it overrides sufficiency.
D) Cannot be determined without knowing the full grading policy.
نمایش پاسخ و توضیح
پاسخ درست: A.
«Sufficient» طبق تعریف یعنی «If A then B» بدون قید و شرط اضافه — یعنی نمره‌ی بالای ۹۰٪ به‌تنهایی باید A رو تضمین کنه. وقتی این اتفاق نمی‌افته، طبق جدول درستی فصل ۴ (مقدم درست، تالی غلط)، خودِ گزاره‌ی اصلی نقض شده. گزینه‌ی B معنای «sufficient» رو اشتباه، به‌عنوان «ممکنه» به‌جای «تضمین‌شده» تفسیر کرده.
سخت
"Being a mammal is necessary for being a dog, but it is not sufficient." Which of the following best captures what this claim tells us?
A) Every mammal is a dog.
B) Every dog is a mammal, but not every mammal is a dog.
C) No mammal can be a dog.
D) Being a mammal and being a dog are logically equivalent.
نمایش پاسخ و توضیح
پاسخ درست: B.
«Being a mammal is necessary for being a dog» = «If (is a dog) then (is a mammal)» — یعنی هر سگی پستاندار است. «but not sufficient» یعنی «If (is a mammal) then (is a dog)» برقرار
نیست
— یعنی هر پستانداری لزوماً سگ نیست (مثل گربه یا فیل). گزینه‌ی D اشتباهه چون دقیقاً می‌گه رابطه یک‌طرفه‌ست، نه دوطرفه (iff)؛ اگه دوطرفه بود، «sufficient» هم برقرار می‌بود.

## 🚀مرور سریع — فصل ۹

Section ID: `375EF7B2-8D37-60EE-0001-25E1E34F10C2`

Import key: `logic/ch09-necessary-sufficient.html#section-08`

Topic ID: `11ECE97E-6CB5-A8AA-68B9-FD269C7AE1B5`

Source: [logic/ch09-necessary-sufficient.html](../../../database-sources/logic/2D0B80D9-A16D-5BF5-FD86-DA0844DF0087.html) — ID `2D0B80D9-A16D-5BF5-FD86-DA0844DF0087`

مرور سریع — فصل ۹
🚀
مفاهیم اصلی
A necessary for B = If B then A
A sufficient for B = If A then B
هر دو با هم = بایکاندیشنال (iff)
روش
Sufficient ↔ مقدم، Necessary ↔ تالی.
اول به فرم «If…then» ساده برگردون.
اشتباهات رایج
جابه‌جا کردن جهت necessary/sufficient.
استدلال مستقیم با کلمات، بدون بازنویسیِ شرطی.
دام‌های تستی
فرض کردن رابطه‌ی دوطرفه وقتی فقط یک جهت گفته شده.
