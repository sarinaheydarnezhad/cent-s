# فصل ۱۴: خواندن نمودارهای میله‌ای — Reading Bar Charts

Original chapter ID: `7CE953C5-B6CA-3789-4649-D089C88FCC16`

Original chapter import key: `logic/ch14-barcharts.html#chapter`

## فصل ۱۴: خواندن نمودارهای میله‌ای — Reading Bar Charts

Section ID: `5D8591C3-221B-852A-76CE-055B0F607CF9`

Import key: `logic/ch14-barcharts.html#intro`

Topic ID: `515A9EA8-AE74-14E3-D9E3-0F1B240E88C4`

Source: [logic/ch14-barcharts.html](../../../database-sources/logic/27C6F8B1-8C19-E424-5E42-F16F99BCAB79.html) — ID `27C6F8B1-8C19-E424-5E42-F16F99BCAB79`

CENT LOGIC — PART B · CHAPTER 14 / 19
فصل ۱۴: خواندن نمودارهای میله‌ای — Reading Bar Charts
وارد بخش دوم جزوه شدیم: تفسیر داده
. اینجا دیگه استدلال منطقیِ محض نیست — مهارت اصلی، خوندنِ
و
اطلاعاته، بدون افتادن در دام‌های رایجِ نمودارخوانی.
(Data Interpretation)
دقیق
سریع

## Bاین مبحث چیست؟

Section ID: `97142638-C3F0-A709-7193-FB3255ADD6BA`

Import key: `logic/ch14-barcharts.html#section-01`

Topic ID: `515A9EA8-AE74-14E3-D9E3-0F1B240E88C4`

Source: [logic/ch14-barcharts.html](../../../database-sources/logic/27C6F8B1-8C19-E424-5E42-F16F99BCAB79.html) — ID `27C6F8B1-8C19-E424-5E42-F16F99BCAB79`

این مبحث چیست؟
B
در نمودار میله‌ای
، طول یا ارتفاع هر میله نشون‌دهنده‌ی مقدار اون دسته‌ست. سؤالات معمولاً می‌خوان بیشترین/کمترین مقدار رو پیدا کنی، دو یا چند دسته رو مقایسه کنی، یا مجموع/تفاضلشون رو حساب کنی.
(bar chart)

## Cمفهوم اصلی

Section ID: `40A38FAA-C97F-C547-4961-9B9FD8DC710A`

Import key: `logic/ch14-barcharts.html#section-02`

Topic ID: `515A9EA8-AE74-14E3-D9E3-0F1B240E88C4`

Source: [logic/ch14-barcharts.html](../../../database-sources/logic/27C6F8B1-8C19-E424-5E42-F16F99BCAB79.html) — ID `27C6F8B1-8C19-E424-5E42-F16F99BCAB79`

مفهوم اصلی
C
قدم ۱ — خوندنِ ساده: هر میله رو با محور مقایسه کن.
نمونه
Number of Books Borrowed from a Library in a Week
Day
Sat
Sun
Mon
Tue
Wed
Books
35
50
20
30
40
On which day were the most books borrowed?
فقط بلندترین میله رو پیدا کردیم — ساده‌ترین نوعِ این سؤالات.
پاسخ: یکشنبه (Sunday)، ۵۰ کتاب.
این رایج‌ترین دامِ سطح‌بالای نمودار میله‌ایه. یک دسته می‌تونه در حال حاضر بیشترین مقدار رو داشته باشه، ولی کمترین رشد رو نسبت به قبل داشته باشه — یا برعکس.
قدم ۲ — دام مهم: «بیشترین مقدار» با «بیشترین افزایش» فرق داره.
نمونه‌ی امتحانی سخت‌تر
Electricity Generation (Millions of units)
Category
1990
2000
Coal, Oil & Gas
242,300
245,700
Nuclear
37,000
65,700
Gas Turbines
500
400
Hydro (Natural)
3,900
5,100
Hydro (Pumped)
1,200
2,000
Which category made the LARGEST CONTRIBUTION to the increase in total units generated over these years?
اگه فقط دنبال بزرگ‌ترین
بگردی، «Coal, Oil & Gas» (۲۴۵,۷۰۰) به‌نظر برنده میاد. ولی سؤال از
پرسیده، نه مقدار نهایی. باید تفاضل هر ردیف رو جداگانه حساب کنی: Coal +3,400 | Nuclear +28,700 | Gas Turbines −100 | Hydro Natural +1,200 | Hydro Pumped +800. برنده‌ی واقعی
است، با اختلاف زیاد — دقیقاً برعکسِ حدسِ اولیه‌ای که فقط بر اساس مقدار نهایی می‌زدیم.
عدد نهایی
افزایش
Nuclear
وقتی چند سری داده (مثل «تولد» و «مرگ») روی یک نمودار کنار هم یا روی هم نشون داده شدن، قبل از هر مقایسه‌ای، اول هر سری رو جدا از بقیه در نظر بگیر.
قدم ۳ — نمودارهای گروهی/انباشته (grouped / stacked): اول ساختار رو بشکن.

## Dقوانین و اصول مهم

Section ID: `F0C6EC10-0AE3-AAFC-966F-93C8A4DBE814`

Import key: `logic/ch14-barcharts.html#section-03`

Topic ID: `515A9EA8-AE74-14E3-D9E3-0F1B240E88C4`

Source: [logic/ch14-barcharts.html](../../../database-sources/logic/27C6F8B1-8C19-E424-5E42-F16F99BCAB79.html) — ID `27C6F8B1-8C19-E424-5E42-F16F99BCAB79`

قوانین و اصول مهم
D
طول/ارتفاع میله = مقدار؛ همیشه اول واحد و مقیاس محور رو دقیق بخون.
«بیشترین مقدار» (highest value) و «بیشترین افزایش» (largest increase) دو سؤال کاملاً متفاوتن — همیشه اول ببین سؤال دقیقاً کدوم رو می‌خواد.
برای سؤالات افزایش/کاهش، همیشه تفاضلِ دو نقطه‌ی زمانی رو حساب کن، نه فقط مقدار نهایی رو نگاه کن.
در نمودارهای چنددسته‌ای، هر سری رو جدا از بقیه تحلیل کن.

## Eروش حل

Section ID: `BC7C435D-F303-DED1-210D-ED6F2F52DFAC`

Import key: `logic/ch14-barcharts.html#section-04`

Topic ID: `515A9EA8-AE74-14E3-D9E3-0F1B240E88C4`

Source: [logic/ch14-barcharts.html](../../../database-sources/logic/27C6F8B1-8C19-E424-5E42-F16F99BCAB79.html) — ID `27C6F8B1-8C19-E424-5E42-F16F99BCAB79`

روش حل
E
دقیقاً مشخص کن سؤال چی می‌خواد: یک مقدار، یک مجموع، یک تفاضل، یا بیشترین/کمترین رشد.
عنوان نمودار، واحد و مقیاس محورها رو بخون.
اگه سؤال درباره‌ی تغییر/رشد بود، برای هر دسته‌ی مرتبط، تفاضل دو نقطه رو جداگانه حساب کن.
اگه نمودار چنددسته‌ایه، ساختارش رو بشکن و فقط دسته‌ی مرتبط با سؤال رو بررسی کن.
→ جواب: بر اساس دقیقاً همون چیزی که سؤال پرسیده، نه شبیه‌ترین چیزی که در نگاه اول به‌چشم میاد.

## Fمثال آموزشی

Section ID: `741A2768-0015-78AF-733D-94E0B66CE0D8`

Import key: `logic/ch14-barcharts.html#section-05`

Topic ID: `515A9EA8-AE74-14E3-D9E3-0F1B240E88C4`

Source: [logic/ch14-barcharts.html](../../../database-sources/logic/27C6F8B1-8C19-E424-5E42-F16F99BCAB79.html) — ID `27C6F8B1-8C19-E424-5E42-F16F99BCAB79`

مثال آموزشی
F
Example 1 — برای درک مفهوم
Sales of Products (Thousand Units)
Product
A
B
C
D
Sales
120
85
150
95
What is the total sales of Products A and C?
۱۲۰ + ۱۵۰ = ۲۷۰. یک سؤال ساده‌ی «مجموع» — نه بیشترین رشد، نه مقایسه.
پاسخ: ۲۷۰ هزار واحد.

## Gمثال امتحانی

Section ID: `5DFA1E0D-FB15-87EE-5622-9B5342C846A3`

Import key: `logic/ch14-barcharts.html#section-06`

Topic ID: `515A9EA8-AE74-14E3-D9E3-0F1B240E88C4`

Source: [logic/ch14-barcharts.html](../../../database-sources/logic/27C6F8B1-8C19-E424-5E42-F16F99BCAB79.html) — ID `27C6F8B1-8C19-E424-5E42-F16F99BCAB79`

مثال امتحانی
G
Example 2 — CEnT style
Monthly Revenue by Department (€ thousands)
Department
January
June
Sales
80
92
Marketing
45
50
Support
30
60
Which department had the largest PERCENTAGE increase in revenue from January to June?
A) Sales
B) Marketing
C) Support
D) All three had the same percentage increase.
از کجا شروع کنیم؟
سؤال دقیقاً از درصد افزایش پرسیده، نه از مقدار مطلق افزایش. باید برای هر دپارتمان، درصد رشد رو جداگانه حساب کنیم.
چه اطلاعاتی مهمه؟
Sales: (92−80)/80 = 15%. Marketing: (50−45)/45 ≈ 11.1%. Support: (60−30)/30 = 100%. با اختلاف زیاد، Support بیشترین درصد رشد رو داره.
چی حواس‌پرت‌کنه؟
اگه فقط به مقدار مطلق افزایش نگاه کنیم (Sales: +12، Marketing: +5، Support: +30)، باز هم Support برنده‌ست، ولی این توافق تصادفیه — در بسیاری از سؤالات مشابه، دپارتمانی با کمترین مقدار مطلقِ افزایش می‌تونه بیشترین درصد رشد رو داشته باشه (دقیقاً چون مبنای اولیه‌اش کوچیک‌تره). همیشه باید مطمئن بشی کدوم نوع سؤال (مطلق یا درصدی) پرسیده شده.
چرا این روش مطمئن‌تره؟
چون فرمول درصد تغییر —
— رو مستقیماً برای هر سه دسته اعمال کردیم، به‌جای قضاوت چشمی بر اساس ارتفاع میله‌ها.
(جدید − قدیم) / قدیم
🎯 EXAM TIP
قبل از دست زدن به داده‌ها، صورتِ سؤال رو دوبار بخون و مشخص کن دقیقاً دنبال چی هستی: «مقدار»، «مجموع»، «تفاضل مطلق»، یا «درصد تغییر». این چهار تا جواب‌های کاملاً متفاوتی می‌دن.
⚡ QUICK METHOD
برای پیدا کردنِ سریعِ بیشترین/کمترین مقدار در یک نگاه، اول با چشم بلندترین/کوتاه‌ترین میله‌ها رو شناسایی کن و فقط بین ۲ یا ۳ کاندیدای برتر محاسبه‌ی دقیق انجام بده — نیازی نیست همه‌ی میله‌ها رو دقیقاً محاسبه کنی.
⚠️ COMMON MISTAKES
جواب دادن به سؤالِ «بیشترین افزایش» با گزینه‌ای که فقط بیشترین مقدارِ نهایی رو داره.
اشتباه:
دسته‌ای که از قبل بزرگ‌تر بوده، معمولاً بلندترین میله رو داره و چشم به‌طور طبیعی اول به همون جلب می‌شه — بدون توجه به این‌که سؤال درباره‌ی
پرسیده، نه مقدار فعلی.
چرا اتفاق می‌افته:
تغییر
همیشه برای سؤالات «افزایش/کاهش»، تفاضل دو نقطه رو برای
گزینه‌ها به‌طور جداگانه بنویس، حتی اگه یکیشون در نگاه اول واضح به‌نظر برسه.
چطور جلوش رو بگیریم:
همه‌ی
🪤 QUESTION TRAP
در جدول‌ها و نمودارهای پیچیده، آزمون گاهی سطر یا ستونِ مشابه رو کنار هم می‌ذاره تا داوطلب رو به خوندنِ سطر/ستونِ اشتباه وسوسه کنه. قبل از خوندنِ عدد، همیشه اول عنوانِ دقیقِ سطر و ستون رو با انگشت یا خط‌کش دنبال کن.
🧠 MUST REMEMBER
بیشترین مقدار ≠ بیشترین افزایش. برای افزایش/کاهش، همیشه تفاضل بگیر. برای درصدِ تغییر، فرمولِ
رو به‌کار ببر، نه فقط مقدار مطلق.
(جدید−قدیم)/قدیم

## 📝تمرین

Section ID: `FC9C0391-3377-452A-B19C-744126745400`

Import key: `logic/ch14-barcharts.html#section-07`

Topic ID: `515A9EA8-AE74-14E3-D9E3-0F1B240E88C4`

Source: [logic/ch14-barcharts.html](../../../database-sources/logic/27C6F8B1-8C19-E424-5E42-F16F99BCAB79.html) — ID `27C6F8B1-8C19-E424-5E42-F16F99BCAB79`

تمرین
📝
آسان
A bar chart shows website visits: Mon 200, Tue 350, Wed 280, Thu 400, Fri 310. On which day were the fewest visits recorded?
A) Monday
B) Tuesday
C) Wednesday
D) Friday
نمایش پاسخ و توضیح
۲۰۰ کمترین مقدار بین همه‌ی روزهاست — یک سؤال ساده‌ی خوندنِ مستقیم مقدار.
پاسخ درست: A.
متوسط
A bar chart shows annual production (in tons): Farm A: 2019=400, 2023=460. Farm B: 2019=150, 2023=210. Which farm had the larger ABSOLUTE increase in production?
A) Farm A (increase of 60 tons)
B) Farm B (increase of 60 tons)
C) Both had the same absolute increase.
D) Cannot be determined.
نمایش پاسخ و توضیح
Farm A: 460−400 = 60. Farm B: 210−150 = 60. جالبه که مقدار
افزایش برای هر دو یکسانه (۶۰ تن) — پس گزینه‌ی درست در واقع C است! این سؤال دقیقاً برای این طراحی شده که نشون بده گاهی با وجود تفاوت زیاد در مقیاس اولیه، مقدار مطلقِ تغییر می‌تونه یکسان باشه؛ اگه سؤال از
افزایش می‌پرسید (Farm A: 15%, Farm B: 40%)، Farm B برنده می‌شد.
پاسخ درست: A.
مطلقِ
درصد
سخت
A stacked bar chart shows total monthly sales split into "Online" and "In-Store." March: Online=60, In-Store=90 (Total=150). April: Online=100, In-Store=80 (Total=180). Which statement is correct?
A) In-Store sales increased from March to April.
B) Total sales increased, even though In-Store sales decreased.
C) Online sales decreased from March to April.
D) Total sales decreased from March to April.
نمایش پاسخ و توضیح
طبق قدم ۳، باید هر سری رو جدا بررسی کنیم: Online از ۶۰ به ۱۰۰ افزایش یافته (+40)، In-Store از ۹۰ به ۸۰ کاهش یافته (−10). مجموع کل از ۱۵۰ به ۱۸۰ افزایش یافته (+30) — یعنی با اینکه یکی از دو بخش کم شده، رشدِ بخشِ دیگه اون رو جبران کرده و مجموع رو هم بالا برده. این دقیقاً نشون می‌ده که نگاه کردن فقط به یک سری، بدون شکستنِ کامل ساختار نمودار انباشته، می‌تونه نتیجه‌ی گمراه‌کننده بده.
پاسخ درست: B.

## 🚀مرور سریع — فصل ۱۴

Section ID: `4358640F-83F3-984F-5CF4-7FCB1CCBA8F0`

Import key: `logic/ch14-barcharts.html#section-08`

Topic ID: `515A9EA8-AE74-14E3-D9E3-0F1B240E88C4`

Source: [logic/ch14-barcharts.html](../../../database-sources/logic/27C6F8B1-8C19-E424-5E42-F16F99BCAB79.html) — ID `27C6F8B1-8C19-E424-5E42-F16F99BCAB79`

مرور سریع — فصل ۱۴
🚀
مفاهیم اصلی
طول/ارتفاع میله = مقدار.
بیشترین مقدار ≠ بیشترین افزایش.
مطلق ≠ درصد.
روش
اول مشخص کن سؤال دقیقاً چی می‌خواد.
برای رشد، تفاضل دو نقطه رو حساب کن.
نمودار انباشته رو اول بشکن.
اشتباهات رایج
جواب دادن به سؤال رشد با مقدار نهایی.
دام‌های تستی
سطر/ستون مشابه که به اشتباه می‌اندازه.
یکسان بودنِ مقدار مطلق با اختلاف زیادِ درصدی.
