# Mock 1 — Chemistry · 10 questions · 20 minutes

1. A 10 g solid at its melting temperature absorbs 1500 J while completely melting. What is its specific latent heat?
   A. 15000 J/g
   B. 0.0067 J/g
   C. 1500 J/g
   D. 150 J/g
   E. 15 J/g

2. What is the total valence electron count of NO3⁻?
   A. 23
   B. 26
   C. 18
   D. 22
   E. 24

3. How many unpaired electrons does a ground-state neutral carbon atom have (1s²2s²2p²)?
   A. 1
   B. 0
   C. 2
   D. 3
   E. 4

4. For 2CO + O2 → 2CO2, 4 mol CO reacts with 1.5 mol O2. What is the maximum amount of CO2?
   A. 5.5 mol
   B. 3 mol
   C. 2 mol
   D. 1.5 mol
   E. 4 mol

5. An ideal gas at 2 atm occupies 3 L at 300 K. At constant n, it occupies 6 L at 600 K. New pressure?
   A. 8 atm
   B. 0.5 atm
   C. 1 atm
   D. 2 atm
   E. 4 atm

6. What is the formula of copper(I) oxide?
   A. CuO
   B. Cu2O
   C. Cu(OH)2
   D. Cu2O3
   E. CuO2

7. At 25 °C, what is the approximate pH of fully dissociated 0.005 M Ca(OH)2?
   A. 10
   B. 11.7
   C. 7
   D. 12
   E. 2

8. What is the oxidation state of Mn in MnO2?
   A. −4
   B. +2
   C. 0
   D. +7
   E. +4

9. In complete combustion, 2 mol of C2H4 consumes how much oxygen?
   A. 3 mol
   B. 4 mol
   C. 6 mol
   D. 8 mol
   E. 2 mol

10. A 500 mL beverage has 12 g carbohydrate per 100 mL. Total carbohydrate?
   A. 12 g
   B. 6 g
   C. 24 g
   D. 60 g
   E. 120 g

# Mock 2 — Chemistry · 10 questions · 20 minutes

1. A pure compound contains 8 g of X per 12 g of Y. How much X accompanies 30 g of Y in the same compound?
   A. 18 g
   B. 12 g
   C. 45 g
   D. 20 g
   E. 30 g

2. What is the ideal bond angle in a trigonal planar arrangement?
   A. 109.5°
   B. 60°
   C. 180°
   D. 90°
   E. 120°

3. An element has 25% mass-40 isotope and 75% mass-42 isotope. Approximate Ar?
   A. 41.0
   B. 42.5
   C. 41.5
   D. 40.5
   E. 82

4. How much solute is present in 250 mL of a 12 g/L solution?
   A. 3 g
   B. 48 g
   C. 30 g
   D. 12 g
   E. 0.048 g

5. ΔH=−10 kJ/mol, ΔS=−100 J/(mol K), T=200 K. What is ΔG?
   A. +10 kJ/mol
   B. 0
   C. +30 kJ/mol
   D. −30 kJ/mol
   E. −10 kJ/mol

6. An ideal dilute 0.20 molal KCl solution has i=2 and Kf=1.86 K kg/mol. Freezing-point depression?
   A. 0.372 K
   B. 1.86 K
   C. 0.186 K
   D. 0.744 K
   E. 3.72 K

7. A buffer has pKa=4.5 and [A⁻]/[HA]=0.1. Approximate pH?
   A. 5.5
   B. 4.5
   C. 1.0
   D. 3.5
   E. 0.45

8. Reduction potentials for A and B are −0.10 V and −0.90 V. Which E°cell is obtained with A as cathode?
   A. +1.00 V
   B. −0.80 V
   C. +0.80 V
   D. −1.00 V
   E. +0.09 V

9. Which is the formula of methyl ethanoate?
   A. CH3CH2OH
   B. CH3OCH2CH3
   C. CH3COCH3
   D. CH3CH2COOH
   E. CH3COOCH3

10. Which report preserves three significant figures for 0.00320 kg expressed in g?
   A. 0.320 g
   B. 3.20 g
   C. 3.2000 g
   D. 320 g
   E. 3.2 g

# Mock 3 — Chemistry · 10 questions · 20 minutes

1. Which method uses a difference in affinity for a stationary phase and a mobile phase?
   A. Magnetic separation
   B. Chromatography
   C. Evaporation to dryness
   D. Filtration by size
   E. Simple decantation

2. How many oxygen atoms occur in 2 formula units of Al2(SO4)3?
   A. 8
   B. 24
   C. 18
   D. 6
   E. 12

3. Which generally has the larger radius, Cl or Cl⁻?
   A. Cl⁻
   B. Both have zero radius
   C. They are necessarily identical
   D. Cl
   E. Neither has electrons

4. A compound has empirical formula NH2 and molar mass 32 g/mol (N=14,H=1). Molecular formula?
   A. NH2
   B. N3H6
   C. N2H2
   D. N2H4
   E. NH3

5. For A(g) ⇌ 2B(g), what shift is favoured by decreasing volume at constant T?
   A. Both reactions stop
   B. Toward A
   C. No shift in any case
   D. Toward B
   E. K must double

6. Solubility is 40 g per 100 g water. If 25 g solute is added to 50 g water at that T, how much remains undissolved at equilibrium?
   A. 5 g
   B. 0 g
   C. 15 g
   D. 20 g
   E. 25 g

7. How many moles of HCl neutralise 0.025 mol of fully dissolved Ba(OH)2?
   A. 0.100 mol
   B. 0.025 mol
   C. 0.250 mol
   D. 0.050 mol
   E. 0.0125 mol

8. In acidic solution, the half-reaction NO3⁻ + 4H⁺ + xe⁻ → NO + 2H2O has x equal to:
   A. 2
   B. 5
   C. 1
   D. 3
   E. 4

9. Which pair has the same molecular formula but different connectivity?
   A. Methane and methanol
   B. Butane and 2-methylpropane
   C. Propane and butane
   D. Ethane and ethene
   E. Ethanol and ethanoic acid

10. Which statement correctly distinguishes stratospheric ozone from ground-level ozone?
   A. Both are always harmless at any concentration
   B. They are different elements
   C. Ground-level ozone is required to block all UV
   D. Stratospheric ozone is carbon dioxide
   E. Stratospheric ozone absorbs harmful UV; ground-level ozone is a pollutant

# Mock 4 — Chemistry · 10 questions · 20 minutes

1. A 120 g liquid occupies 150 cm³. What is its density?
   A. 30 g/cm³
   B. 270 g/cm³
   C. 1.25 g/cm³
   D. 0.80 g/cm³
   E. 18000 g/cm³

2. Which interaction explains attraction of polar HCl molecules beyond London dispersion?
   A. Conventional strong N–H hydrogen bonding
   B. Ionic crystal lattice between molecules
   C. Permanent dipole-dipole interactions
   D. Metallic bonding
   E. Nuclear fusion

3. Which subshell corresponds to n=4,l=1?
   A. 3p
   B. 4f
   C. 4p
   D. 4d
   E. 4s

4. What is the sum of smallest whole-number coefficients for balanced 2Al + 6HCl → 2AlCl3 + 3H2?
   A. 11
   B. 7
   C. 12
   D. 10
   E. 13

5. A system releases 120 J heat while 40 J of work is done on it. ΔU?
   A. −80 J
   B. +80 J
   C. −160 J
   D. +160 J
   E. −120 J

6. Which normally does not release hydrogen when placed in dilute nonoxidising HCl under ordinary conditions?
   A. Zn
   B. Mg
   C. Ca
   D. Fe
   E. Cu

7. A weak acid has pKa=3. Its Ka is:
   A. 10⁻¹¹
   B. 3
   C. 10⁻³
   D. 0.3
   E. 10³

8. In the balanced basic half-reaction MnO4⁻ + 2H2O + 3e⁻ → MnO2 + xOH⁻, x is:
   A. 8
   B. 6
   C. 4
   D. 3
   E. 2

9. How many carbon atoms are in 3-methylhexane?
   A. 8
   B. 7
   C. 3
   D. 9
   E. 6

10. A label shows a corrosion pictogram. Which interpretation is appropriate?
   A. It guarantees no health risk
   B. It means it is only an environmental nutrient
   C. It may cause severe skin/eye damage or corrode metals; read the full label
   D. It indicates only compressed gas
   E. It is necessarily edible

# Mock 5 — Chemistry · 10 questions · 20 minutes

1. Which is a chemical transformation rather than a phase transition?
   A. Freezing of liquid nitrogen
   B. Sublimation of dry ice
   C. Melting of pure wax without decomposition
   D. Formation of silver sulfide on silver
   E. Vaporisation of water

2. What is the neutral formula for Mg²⁺ and N³⁻?
   A. MgN2
   B. Mg3N
   C. Mg3N2
   D. MgN
   E. Mg2N3

3. An element has configuration [Ne]3s²3p⁶. Which group does it belong to?
   A. 16
   B. 1
   C. 17
   D. 18
   E. 2

4. How many moles of oxygen atoms are present in 44 g CO2 (M=44 g/mol)?
   A. 44 mol
   B. 0.5 mol
   C. 2 mol
   D. 4 mol
   E. 1 mol

5. For A → 2B, B concentration rises by 0.20 M in 10 s. What is the average stoichiometric reaction rate?
   A. 0.010 M/s
   B. 0.040 M/s
   C. 0.020 M/s
   D. 0.20 M/s
   E. 0.002 M/s

6. Which ions remain spectators when Ba(NO3)2 and Na2SO4 form BaSO4(s)?
   A. Ba²⁺ and Na⁺
   B. No ions
   C. Na⁺ and NO3⁻
   D. SO4²⁻ and NO3⁻
   E. Ba²⁺ and SO4²⁻

7. In HCO3⁻ + H2O ⇌ H2CO3 + OH⁻, HCO3⁻ acts as:
   A. An oxidant necessarily
   B. A Brønsted base
   C. A Brønsted acid
   D. A spectator ion
   E. A reducing agent necessarily

8. In 2Na + Cl2 → 2NaCl, how many moles of electrons are transferred per mole Cl2?
   A. 0 mol
   B. 4 mol
   C. 1 mol
   D. 6 mol
   E. 2 mol

9. How many hydrogen atoms are in acyclic butyne with one triple bond?
   A. 12
   B. 10
   C. 6
   D. 8
   E. 4

10. Why does a carbonate-containing scale react with acid?
   A. Carbonate becomes elemental chlorine
   B. All atoms vanish
   C. Only water evaporates without reaction
   D. The acid changes nuclear charge
   E. Carbonate consumes protons and can form CO2 and water