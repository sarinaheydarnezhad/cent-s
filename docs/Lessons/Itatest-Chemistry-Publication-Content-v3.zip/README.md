# Itatest Chemistry — publication content handoff (v3)

**Scope:** educational content only. No database, import code, backend, frontend or deployment changes. All 50 canonical lessons contain Persian teaching text, English exam terms, worked examples, common traps and independent exercises. All MCQs have five English options and Persian explanations. New content is original Itatest practice, not official CISIA questions.

## What to import
- `chapters/01` through `chapters/10`: chapter.json, lessons.json, questions.json, exercises.json. JSON is canonical; Markdown is a human-readable view. The `Html` field contains semantic HTML and inline SVG when appropriate. `Text` and `Markdown` are alternate content views, not additional lessons.
- `assessments.json` and `mock-questions.json`: ten chapter reviews reuse practice questions intentionally; five 10-question/20-minute chemistry mocks use a separate item set. Keep mock answers out of learner-facing question payloads until grading. Raw practice scoring is not CISIA normalisation.
- `figures/`: original standalone SVG teaching figures. The same visuals are embedded in canonical lesson HTML. No external assets needed for these figures.
- `provenance/section-mapping.json` and `question-mapping.json`: use these to reconcile legacy IDs with the new hierarchy. The old section archive contains superseded language and must NOT be published or imported as live lessons. All 81 original question IDs, 10 previous addition IDs and 66 linked exercise IDs are retained. New chapter/lesson IDs are deterministic. Old section IDs are mapped, not silently reused for different content. Linked exercise records are aliases of bank questions, not additional independent items.

## Editorial and delivery boundaries
The prior export was consulted and the complete lesson set was rewritten; R1/R2 summaries are incorporated by topic. Some original examples and figures are archived rather than reproduced verbatim. The new material includes a few supporting introductory concepts beyond the literal syllabus (e.g. empirical formula, formal charge, electrochemical cell calculations and atom economy); the curriculum map identifies the required coverage. Difficulty labels are editorial estimates, not empirical item calibration. Structural checks were run; this is not an independent review by a chemistry specialist and no live rendering, production import, entitlement or assessment behaviour was tested. The content is complete as an authored handoff, not a guarantee of error-free publication. Codex should map the schema, validate rendering and ensure the superseded content is no longer served; a subject expert should review before charging students.

## Sources and date
CISIA CEnT-S structure and syllabus, accessed 2026-11-24: https://www.cisiaonline.it/en/cent/cent-s/structure-and-syllabus
CISIA rules: https://www.cisiaonline.it/en/cent/all-about-CEnT/CEnT-rules
General chemistry reference for further independent review: OpenStax Chemistry 2e, https://openstax.org/details/books/chemistry-2e (not a claim that every line was independently source-checked).
