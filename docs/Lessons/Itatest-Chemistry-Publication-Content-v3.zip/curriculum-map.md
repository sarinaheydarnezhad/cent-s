# CISIA Chemistry curriculum crosswalk — 2026-11-24

Coverage is a content-location map against the official chemistry syllabus, not a psychometric or independent accuracy certification. Supporting concepts are included where useful, without implying that CISIA explicitly lists them. All lesson numbers refer to canonical authored content.

| Area | Required concept (paraphrased) | Lesson(s) |
|---|---|---|
| Matter | Particle model and physical/chemical changes | 1.1, 1.2 |
| Matter | Observable properties of the three states | 1.1, 1.3 |
| Matter | Mixture classification and separation | 1.4 |
| Matter | Lavoisier, Proust, combining volumes, Avogadro | 1.5 |
| Microscopic | Atom constituents, ions, formulas, relative masses | 2.1 |
| Microscopic | Valence electrons and Lewis representation | 2.2 |
| Microscopic | Ionic, covalent and metallic bonding; bond polarity | 2.3 |
| Microscopic | VSEPR geometry and hybridisation | 2.4 |
| Microscopic | Intermolecular attractions and hydrogen bonding | 2.5 |
| Periodic | Groups, periods and electron configuration | 3.1, 3.4 |
| Periodic | Atomic models and quantum numbers | 3.2 |
| Periodic | Isotopes | 3.3 |
| Periodic | Aufbau, Pauli and periodic trends | 3.4, 3.5 |
| Stoichiometry | Equation balancing | 4.3 |
| Stoichiometry | Mole, Avogadro constant, mass conversions | 4.1 |
| Stoichiometry | Limiting reagent and theoretical yield | 4.4 |
| Stoichiometry | mol/L, g/L, percent concentration and calculations | 4.5 |
| Thermodynamics | Ideal gas relationships, partial pressures, molecular speed | 5.1 |
| Thermodynamics | Internal energy, enthalpy, endo/exothermic processes | 5.2 |
| Thermodynamics | Entropy, Gibbs energy and spontaneity | 5.3 |
| Thermodynamics | Dynamic equilibrium, K and Q | 5.4 |
| Kinetics | Activation, catalysis, rate and effects of T and pressure | 5.5 |
| Compounds | Inorganic formulas, systematic and traditional naming | 6.1 |
| Solutions | Electrolytes, nonelectrolytes and solubility | 6.2 |
| Solutions | Conductivity and colligative properties | 6.3, 6.4 |
| Compounds | Chemical properties of metals | 6.5 |
| Acid/base | Theories, conjugate species and reactions | 7.1 |
| Acid/base | Strength and equilibrium | 7.2 |
| Acid/base | pH and indicators | 7.3 |
| Acid/base | Neutralisation, salts and hydrolysis | 7.4 |
| Acid/base | Buffers | 7.5 |
| Redox | Oxidation numbers, valence and agents | 8.1, 8.2 |
| Redox | Balancing simple redox reactions | 8.3, 8.4 |
| Redox | Redox potential scale | 8.5 |
| Organic | Carbon bonding and basic structures | 9.1, 9.2 |
| Organic | Alkanes, cycloalkanes, alkenes, alkynes, benzene/aromatics | 9.1, 9.2 |
| Organic | Combustion and structure–property relationships | 9.3 |
| Organic | Alcohols, aldehydes, ketones, ethers, esters, carboxylic acids | 9.4 |
| Organic | Isomerism | 9.5 |
| Applied | Measurement, units, uncertainty | 10.1 |
| Applied | Everyday chemical transformations | 10.2 |
| Applied | Commercial labels | 10.3 |
| Applied | Acid rain, greenhouse effect, smog, sustainability | 10.4 |
| Applied | Chemical hazard communication and safety | 10.5 |

Supporting material: 1.1 heat calculations; 1.5 multiple proportions; 2.2 formal charge and resonance; 4.2 empirical formula; 8.5 cells and electrolysis; 10.4 atom economy. These are teaching extensions, not all individually named requirements.
