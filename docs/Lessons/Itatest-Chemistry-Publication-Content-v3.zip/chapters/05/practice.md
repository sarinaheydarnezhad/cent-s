# ترمودینامیک، سینتیک و تعادل — تمرین و تست

1. گاز ۳۰۰ K در حجم ثابت به ۴۵۰ K می‌رسد؛ نسبت فشار؟

2. ۱ mol گاز در ۲۷۳٫۱۵ K و ۱ atm تقریباً چه حجم دارد؟

3. فشار کل ۸ bar و x=0.25؛ فشار جزئی؟

4. q=−50 J,w=+20 J؛ ΔU؟

5. دو مرحله ΔH=+10 و −40 kJ؛ مجموع؟

6. چرا در فشار ثابت q=ΔH تنها با فرض کار PV است؟

7. ΔH=−20 kJ، ΔS=−50 J/K، T=200 K

8. تبخیر در حالت معمول چه اثری بر S ماده دارد؟

9. در تعادل چه مقدار ΔG داریم؟

10. برای CaCO3(s)⇌CaO(s)+CO2(g) عبارت Kp؟

11. K=10 برای A⇌B؛ K معکوس؟

12. Q=8,K=2؛ جهت؟

13. چرا پودر جامد ممکن است سریع‌تر واکنش دهد؟

14. اگر نرخ مصرف A=0.12 و ضریب A=3 باشد، سرعت واکنش؟

15. افزایش فشار گاز در حجم کمتر چه اثری می‌تواند داشته باشد؟

## Multiple-choice questions

1. At constant n and T, a gas volume doubles. Its pressure becomes:
   A. Double
   B. Four times
   C. Zero
   D. Half
   E. Unchanged

2. At constant pressure and n, 2 L gas at 300 K is warmed to 600 K. Volume?
   A. 4 L
   B. 1 L
   C. 6 L
   D. 2 L
   E. 0.5 L

3. A mixture has 3 mol A and 1 mol B at total pressure 4 bar. Partial pressure of B?
   A. 4 bar
   B. 0.25 bar
   C. 16 bar
   D. 1 bar
   E. 3 bar

4. What temperature scale is required in PV=nRT?
   A. Fahrenheit
   B. Any scale with no conversion
   C. Celsius
   D. Percent
   E. Kelvin

5. At the same temperature, which ideal gas has the greatest rms speed?
   A. Ar
   B. He
   C. Ne
   D. Xe
   E. Kr

6. A system absorbs 80 J heat and does 20 J work on surroundings. ΔU?
   A. 60 J
   B. −100 J
   C. 20 J
   D. −60 J
   E. 100 J

7. Which sign identifies an exothermic reaction at constant pressure?
   A. ΔG>0 necessarily
   B. ΔH=0 always
   C. ΔH>0
   D. ΔS<0 necessarily
   E. ΔH<0

8. If a reaction with ΔH=−50 kJ is reversed, its new ΔH is:
   A. +50 kJ
   B. −100 kJ
   C. +25 kJ
   D. 0
   E. −50 kJ

9. Which is a state function?
   A. Heating duration
   B. Enthalpy
   C. Power of a burner
   D. Work along a path
   E. Heat transferred

10. Breaking a covalent bond in an isolated molecule generally requires:
   A. Energy input
   B. No energy
   C. A change in nuclear charge
   D. Energy release only
   E. A catalyst in every case

11. At fixed T and P, which ΔG indicates a thermodynamically favourable forward reaction?
   A. Equal to activation energy
   B. Equal to temperature
   C. Positive
   D. Always zero
   E. Negative

12. ΔH=20 kJ/mol, ΔS=100 J/(mol K), T=300 K. ΔG?
   A. −10 kJ/mol
   B. +50 kJ/mol
   C. +10 kJ/mol
   D. +20 kJ/mol
   E. −30 kJ/mol

13. Which process usually increases the entropy of a pure substance?
   A. Condensation
   B. Deposition
   C. Crystallisation from a melt
   D. Freezing
   E. Sublimation

14. At chemical equilibrium at fixed T and P, the reaction Gibbs energy ΔG is:
   A. Always positive
   B. The same as ΔH necessarily
   C. The activation energy
   D. Zero
   E. Always negative

15. A reaction has ΔH>0 and ΔS>0, both approximately constant. Increasing temperature generally makes ΔG:
   A. More negative
   B. Equal to zero at every temperature
   C. More positive
   D. Equal to ΔH at every temperature
   E. Unchanged

16. At equilibrium in a closed reversible system, what is equal?
   A. All partial pressures
   B. Forward and reverse reaction rates
   C. Reactant and product concentrations necessarily
   D. Activation energies necessarily
   E. All stoichiometric coefficients

17. For A ⇌ B with K=5 and Q=2, the net reaction proceeds:
   A. Toward A
   B. In neither direction
   C. Toward B
   D. Only if catalyst is added
   E. Only if K changes

18. Which species is omitted from the usual equilibrium expression?
   A. An ideal gas product
   B. A pure solid phase
   C. A dissolved reactant
   D. A dissolved ion
   E. A gaseous reactant

19. Which changes the equilibrium constant for a fixed reaction?
   A. Removing product at fixed T
   B. Catalyst amount
   C. Initial reactant amount at fixed T
   D. Temperature
   E. Container volume at fixed T

20. If K=4 for A ⇌ B, what is K for 2A ⇌ 2B?
   A. 0.25
   B. 2
   C. 8
   D. 16
   E. 4

21. A catalyst usually increases reaction rate by:
   A. Increasing the total number of atoms
   B. Providing an alternative pathway with a lower effective activation barrier
   C. Increasing the equilibrium constant
   D. Changing the reaction enthalpy
   E. Making all collisions successful

22. For 2A → B, A disappears at 0.08 mol/L/s. B forms at:
   A. 0.40 mol/L/s
   B. 0.16 mol/L/s
   C. 0.02 mol/L/s
   D. 0.04 mol/L/s
   E. 0.08 mol/L/s

23. Why does warming usually speed a reaction with positive activation energy?
   A. The reactants gain mass
   B. The equilibrium constant always rises
   C. The activation energy becomes exactly zero
   D. All molecules become ions
   E. A larger fraction of collisions can overcome the energy barrier

24. For a complex overall reaction, how is its rate law generally established?
   A. By reading all overall coefficients as orders
   B. By assuming first order in every reactant
   C. From equilibrium colour only
   D. From atomic masses only
   E. Experimentally

25. A concentration falls from 0.9 M to 0.3 M in 20 s. Average disappearance rate?
   A. 0.015 M/s
   B. 0.045 M/s
   C. 0.06 M/s
   D. 0.03 M/s
   E. 0.6 M/s

26. At fixed temperature, a catalyst changes which property of a reversible reaction?
   A. The activation pathway and rate of reaching equilibrium
   B. The equilibrium ratio by removing products
   C. The equilibrium constant
   D. The conservation of atoms
   E. The standard reaction enthalpy

27. For a reaction at a fixed temperature, the reaction quotient Q is less than K. In which direction does the net reaction proceed?
   A. Towards products
   B. It must stop irreversibly
   C. Neither direction because all rates are zero
   D. The direction depends only on a catalyst
   E. Towards reactants

28. At constant amount and volume, an ideal gas is warmed from 300 K to 450 K. Its pressure becomes:
   A. two-thirds of its initial value
   B. 1.5 times its initial value
   C. unchanged
   D. three times its initial value
   E. one-third of its initial value

29. An ideal gas mixture has total pressure 5.0 bar and oxygen mole fraction 0.20. What is the oxygen partial pressure?
   A. 0.040 bar
   B. 1.0 bar
   C. 25 bar
   D. 0.20 bar
   E. 4.0 bar

30. For a reaction at 300 K, Delta H=-40 kJ/mol and Delta S=-0.100 kJ/(mol K). What is Delta G?
   A. +30 kJ/mol
   B. -40 kJ/mol
   C. -10 kJ/mol
   D. +10 kJ/mol
   E. -70 kJ/mol

31. At equilibrium, what must be equal?
   A. Reactant and product concentrations
   B. Forward and reverse rates
   C. Reactant and product masses
   D. Activation energies
   E. All partial pressures
