# ساختار میکروسکوپی و پیوندها — تمرین و تست

1. ³⁵Cl⁻ با Z=17 چند الکترون و نوترون دارد؟

2. Mr(H2SO4) با H=1,S=32,O=16؟

3. در 3Ca(OH)2 چند اتم O وجود دارد؟

4. NH3 چند الکترون ظرفیت و چند جفت تنها روی N دارد؟

5. NH4⁺ چند الکترون ظرفیت دارد؟

6. بار رسمی O در OH⁻ با سه جفت تنها و یک پیوند؟

7. فرمول Ca²⁺ و NO3⁻؟

8. چرا فلز مس رساناست؟

9. در CO کدام اتم معمولاً الکترونگاتیوتر است؟

10. هندسه NH3؟

11. هیبریداسیون کربن در CO2 در مدل ساده؟

12. چرا CH2Cl2 با هندسه چهاروجهی می‌تواند قطبی باشد؟

13. آیا N2 نیروی بین‌مولکولی دارد؟

14. آیا CH3OCH3 با آب پیوند هیدروژنی برقرار می‌کند؟

15. نوع جاذبه غالب در آب‌پوشی Na⁺؟

## Multiple-choice questions

1. An ion has 12 protons and 10 electrons. Its charge is:
   A. −10
   B. −2
   C. 0
   D. +12
   E. +2

2. What does the mass number count?
   A. All electrons
   B. Only neutrons
   C. Isotopes in a sample
   D. Electrons plus protons
   E. Protons plus neutrons

3. Using C=12 and H=1, what is Mr of C2H6?
   A. 24
   B. 36
   C. 26
   D. 14
   E. 30

4. Which particle determines the identity of an element through its number?
   A. Photon
   B. Neutron
   C. Proton
   D. Molecule
   E. Electron

5. Two atoms of the same element differ in neutron number. They are:
   A. Different elements
   B. Isotopes
   C. Isomers of a molecule
   D. Ions necessarily
   E. Identical mass numbers

6. How many valence electrons are counted for CO3²⁻?
   A. 18
   B. 20
   C. 22
   D. 24
   E. 26

7. How many lone pairs are on oxygen in the usual Lewis structure of H2O?
   A. 0
   B. 4
   C. 1
   D. 3
   E. 2

8. Which common molecule has an incomplete octet at its central atom in its simplest Lewis structure?
   A. H2O
   B. CH4
   C. CO2
   D. BF3
   E. NH3

9. What moves when drawing valid resonance contributors?
   A. Only protons
   B. Entire molecules in space
   C. All atomic nuclei
   D. Electrons, not the atomic connectivity
   E. The atomic number

10. What is the formal charge of N in NH4⁺ with four single bonds and no lone pair?
   A. +4
   B. −4
   C. 0
   D. −1
   E. +1

11. Which formula is charge-neutral for Al³⁺ and SO4²⁻?
   A. Al(SO4)2
   B. AlSO4
   C. Al2(SO4)3
   D. Al3SO4
   E. Al3(SO4)2

12. Which bonding model best describes solid copper?
   A. Discrete CuH molecules
   B. Ionic between Cu⁺ and Cl⁻
   C. Metallic
   D. Van der Waals only
   E. Hydrogen bonding only

13. Which bond is nonpolar by symmetry?
   A. H–Cl
   B. C–O
   C. N–H
   D. O–H
   E. Cl–Cl

14. Which substance is normally an ionic solid?
   A. KBr
   B. Cl2
   C. O2
   D. CH4
   E. CO2

15. Why is dry solid NaCl normally a poor electrical conductor?
   A. Its sodium atoms are neutral and gaseous
   B. It contains no charged particles
   C. It has no chemical bonds
   D. It contains only electrons
   E. Its ions cannot move freely through the lattice

16. What is the molecular geometry of NH3?
   A. Trigonal planar
   B. Linear
   C. Square planar
   D. Tetrahedral with four atoms bonded to N
   E. Trigonal pyramidal

17. What hybridisation is assigned to each carbon in ethene in the usual model?
   A. d²sp³
   B. sp
   C. sp²
   D. No orbital overlap
   E. sp³

18. Which molecule is linear in its equilibrium geometry?
   A. SO2
   B. H2O
   C. NH3
   D. CH4
   E. CO2

19. How many electron domains are around O in H2O?
   A. 1
   B. 4
   C. 3
   D. 6
   E. 2

20. Which has a permanent dipole moment in its usual geometry?
   A. BF3
   B. Cl2
   C. CH4
   D. H2O
   E. CO2

21. Which interaction occurs even between two nonpolar molecules?
   A. Hydrogen bonding necessarily
   B. London dispersion
   C. Ionic bonding necessarily
   D. Permanent dipole-dipole necessarily
   E. Metallic bonding

22. Which pure substance is a conventional hydrogen-bond donor and acceptor?
   A. Methane
   B. Ethane
   C. Methanol
   D. Neon
   E. Carbon tetrachloride

23. Which interaction describes Na⁺ surrounded by water molecules?
   A. Metallic bonding
   B. Ion-dipole
   C. Nuclear attraction only
   D. A peptide bond
   E. Covalent O–H cleavage

24. For comparable liquids, stronger intermolecular attraction generally causes:
   A. Lower enthalpy of vaporisation always
   B. Lower vapour pressure at the same temperature
   C. Zero boiling point
   D. Higher vapour pressure always
   E. Loss of all molecular bonds

25. What is primarily overcome when molecular iodine sublimes?
   A. All atomic masses
   B. Intermolecular attractions
   C. Nuclear binding
   D. Electron shells
   E. The covalent I–I bond in every molecule

26. Which statement correctly compares the molecular shapes of CO2 and H2O?
   A. Both are linear
   B. CO2 is linear and H2O is bent
   C. CO2 is bent and H2O is linear
   D. Both are trigonal planar
   E. Both are tetrahedral

27. Which pure substance can form an extended network of hydrogen bonds between its own molecules?
   A. Carbon tetrachloride, CCl4
   B. Hydrogen, H2
   C. Water, H2O
   D. Methane, CH4
   E. Carbon dioxide, CO2

28. What is the electrically neutral formula formed from Al3+ and O2- ions?
   A. Al3O2
   B. AlO
   C. AlO3
   D. Al2O3
   E. Al2O

29. In the usual valence-bond model, what geometry and carbon hybridisation describe CH4?
   A. Tetrahedral; sp3
   B. Bent; sp
   C. Square planar; sp3
   D. Trigonal planar; sp2
   E. Linear; sp

30. Why does an isolated CO2 molecule have no permanent dipole moment in its equilibrium geometry?
   A. Its C=O bonds are nonpolar
   B. Its equal bond dipoles cancel in a linear geometry
   C. It has a tetrahedral molecular shape
   D. It contains no electrons
   E. All molecules containing oxygen are nonpolar

31. What is the molecular shape of NH3?
   A. Linear
   B. Trigonal planar
   C. Trigonal pyramidal
   D. Square planar
   E. Tetrahedral
