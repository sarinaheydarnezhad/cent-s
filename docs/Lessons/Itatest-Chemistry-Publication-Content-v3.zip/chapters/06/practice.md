# ترکیبات و محلول‌ها — تمرین و تست

1. نام CuCl2؟

2. فرمول ammonium carbonate؟

3. نام N2O3؟

4. حلالیت ۱۵ g/100 g آب؛ در ۲۰۰ g آب؟

5. آیا افزودن جامد اضافی به محلول اشباع در دمای ثابت غلظت را بالا می‌برد؟

6. چرا نوشابه پس از باز شدن گاز آزاد می‌کند؟

7. آیا محلول گلوکز حامل بار فراوان دارد؟

8. رسوب از Ca²⁺ و CO3²⁻؟

9. یون‌های تماشاگر HCl+KOH؟

10. ۰٫۲ mol در ۵۰۰ g حلال چه مولالیته؟

11. در مولالیته برابر CaCl2 یا KCl ایده‌آل کدام کاهش انجماد بیشتر؟

12. اگر x_water=0.9 و p°=20 kPa، فشار بخار آب؟

13. در Zn+2H⁺→Zn²⁺+H2 کدام گونه اکسید می‌شود؟

14. چرا Al در هوا سریع از بین نمی‌رود؟

15. آیا همه اکسیدهای فلزی بازی‌اند؟

## Multiple-choice questions

1. What is the name of FeO?
   A. Iron(III) oxide
   B. Iron hydroxide
   C. Iron(II) oxide
   D. Iron(I) oxide
   E. Iron dioxide

2. Which is the formula of ammonium sulfate?
   A. (NH4)SO3
   B. (NH4)2SO4
   C. NH4SO4
   D. N2H4SO4
   E. NH4(SO4)2

3. Which traditional name corresponds to iron(III)?
   A. Ferric
   B. Ferrous
   C. Cuprous
   D. Cupric
   E. Stannous

4. What is the molecular compound N2O5 named?
   A. Sodium nitrate
   B. Nitrogen dioxide
   C. Nitrogen monoxide
   D. Dinitrogen pentoxide
   E. Dinitrogen trioxide

5. Which ion is nitrate?
   A. NH4⁺
   B. NO2⁻
   C. NO3⁻
   D. SO3²⁻
   E. CO3²⁻

6. Which solute is ordinarily a non-electrolyte in water?
   A. NaOH
   B. NaCl
   C. KNO3
   D. HCl
   E. Sucrose

7. At fixed T, solubility is 25 g per 100 g water. How much dissolves at saturation in 200 g water?
   A. 25 g
   B. 200 g
   C. 12.5 g
   D. 50 g
   E. 75 g

8. What does a weak electrolyte do in aqueous solution?
   A. Never forms any ion
   B. Always precipitates completely
   C. Always has high concentration
   D. Conducts only as a metal
   E. Ionises only partially

9. Which salt is commonly sparingly soluble in water?
   A. NaCl
   B. NH4NO3
   C. KCl
   D. NaNO3
   E. AgCl

10. For a dilute dissolved gas at fixed T, raising its partial pressure generally does what to its equilibrium solubility?
   A. Has no effect under Henry's law
   B. Increases it
   C. Changes its atomic number
   D. Decreases it
   E. Makes it always zero

11. What carries current in molten KCl?
   A. Mobile K⁺ and Cl⁻ ions
   B. Photons exclusively
   C. Stationary nuclei
   D. Neutral KCl molecules exclusively
   E. Only free protons

12. Which mixture produces a precipitate of BaSO4?
   A. KCl and NaNO3
   B. Glucose and water
   C. HCl and NaCl
   D. NaCl and KNO3
   E. Aqueous BaCl2 and Na2SO4

13. Which is a spectator ion when AgNO3 reacts with NaCl in water?
   A. Na⁺
   B. Ag⁺
   C. AgCl(s)
   D. No ion is a spectator
   E. Cl⁻

14. What enables electrical conduction in a copper wire?
   A. Water molecules only
   B. Mobile chloride ions
   C. Dissolved glucose
   D. Mobile delocalised electrons
   E. Moving copper nuclei through the wire

15. Which normally has the lowest conductivity at comparable dilute concentration in water?
   A. HCl solution
   B. Glucose solution
   C. KCl solution
   D. NaOH solution
   E. NaCl solution

16. Which concentration unit is used in ΔTf=iKfb?
   A. g/L solution
   B. mol/kg solvent
   C. mol/L solution
   D. Percent by volume
   E. kg/mol solute

17. At equal molality and ideal complete dissociation, which gives the largest freezing point depression?
   A. Sucrose
   B. CaCl2
   C. Glucose
   D. KCl
   E. NaCl

18. Adding a nonvolatile solute to water generally causes its vapour pressure at fixed T to:
   A. Equal its osmotic pressure
   B. Remain identical in every solution
   C. Become infinite
   D. Increase
   E. Decrease

19. Which process involves solvent movement through a semipermeable membrane?
   A. Electrolysis necessarily
   B. Osmosis
   C. Crystallisation necessarily
   D. Sublimation
   E. Combustion

20. For an ideal dilute nonelectrolyte at b=0.5 mol/kg and Kf=2 K kg/mol, ΔTf equals:
   A. 0.25 K
   B. 4 K
   C. 0 K
   D. 1 K
   E. 2 K

21. Which metal can normally displace Cu²⁺ from dilute aqueous solution?
   A. Ag
   B. Au
   C. Cu itself with no other driving force
   D. Pt
   E. Zn

22. Which oxide is amphoteric?
   A. SO3
   B. K2O
   C. CO2
   D. Al2O3
   E. Na2O

23. Which conditions usually promote ordinary rusting of iron?
   A. Dry inert gas only
   B. Absence of oxidants
   C. Vacuum with no moisture
   D. Water and oxygen
   E. Pure dry nitrogen only

24. What is passivation of aluminium associated with?
   A. Loss of all aluminium nuclei
   B. Conversion into pure carbon
   C. Complete removal of electrons
   D. Formation of a gas-only metal
   E. A protective surface oxide film

25. Which gas is commonly formed when zinc reacts with dilute nonoxidising acid?
   A. N2
   B. O2
   C. CO2
   D. H2
   E. Cl2

26. What is the formula of iron(III) chloride?
   A. Fe2Cl
   B. Fe3Cl
   C. FeCl3
   D. FeCl2
   E. FeCl

27. For equally dilute aqueous NaCl and glucose solutions at the same molality, assume ideal behaviour and complete NaCl dissociation. Which solution has the larger freezing-point depression?
   A. They cannot be compared without the mass of the container
   B. Glucose
   C. They must be equal
   D. Neither can change freezing point
   E. NaCl

28. Which solute is a non-electrolyte when dissolved in water under ordinary conditions?
   A. Glucose
   B. Sodium chloride
   C. Potassium nitrate
   D. Calcium chloride
   E. Hydrochloric acid

29. Why can molten sodium chloride conduct electricity while its dry solid normally cannot?
   A. Its solid contains no charged particles
   B. Its electrons disappear on melting
   C. Its ions become uncharged atoms
   D. Its sodium nuclei split on melting
   E. Its ions are mobile in the melt

30. At fixed temperature, a saturated solution is in equilibrium with excess undissolved solute. Adding more of the same solid will normally:
   A. Double the dissolved concentration automatically
   B. Leave the dissolved concentration unchanged at equilibrium
   C. Make the solvent disappear
   D. Remove all dissolved solute
   E. Prove that dissolution has stopped at the molecular level
