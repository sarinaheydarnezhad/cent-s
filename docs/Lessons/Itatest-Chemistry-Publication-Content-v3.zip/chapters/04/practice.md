# واکنش‌ها و استوکیومتری — تمرین و تست

1. جرم ۰٫۵ mol CO2 با M=44؟

2. در ۲ mol NH3 چند مول اتم H؟

3. 3.011×10²³ مولکول چند مول است؟

4. ۱۲ g C و ۴ g H؛ فرمول تجربی؟

5. فرمول تجربی NO2 و M=92؟

6. درصد جرمی N در NH3 با N=14,H=1؟

7. موازنه Al+O2→Al2O3

8. موازنه CH4+O2→CO2+H2O

9. یون تماشاگر در BaCl2+Na2SO4→BaSO4(s)+2NaCl؟

10. N2+3H2→2NH3؛ 2 mol N2 و 3 mol H2

11. ۴ g H2 با O2 اضافی؛ M(H2)=2، M(H2O)=18

12. بازده ۸۰٪ و نظری ۵۰ g؛ واقعی؟

13. ۲ g حل‌شونده در ۲۰۰ g محلول چه درصد جرمی؟

14. ۰٫۱۵ mol در ۳۰۰ mL محلول؟

15. برای تهیه ۱۰۰ mL محلول ۰٫۱ M از ۱ M چقدر محلول مادر؟

## Multiple-choice questions

1. How many moles are in 36 g of H2O (M=18 g/mol)?
   A. 18 mol
   B. 648 mol
   C. 36 mol
   D. 0.5 mol
   E. 2 mol

2. How many moles of oxygen atoms are in 0.5 mol CO2?
   A. 0.25 mol
   B. 0.5 mol
   C. 1 mol
   D. 2 mol
   E. 3 mol

3. Which unit is appropriate for molar mass?
   A. g/L only
   B. g²
   C. mol/L
   D. mol/g
   E. g/mol

4. How many particles are in 2 mol of a specified entity?
   A. 6.022×10²³
   B. 1.2044×10²⁴
   C. 3.011×10²³
   D. 2
   E. 12.044

5. What mass is 0.25 mol O2 (M=32 g/mol)?
   A. 8 g
   B. 32 g
   C. 4 g
   D. 16 g
   E. 128 g

6. What is the empirical formula of C6H12O6?
   A. C2H4O2
   B. CHO
   C. CH2O
   D. CH3O
   E. C6H12O6

7. A compound has empirical formula CH and molar mass 78 g/mol (C=12,H=1). Its molecular formula is:
   A. C6H6
   B. C3H3
   C. CH
   D. C2H2
   E. C7H7

8. Which operation should precede finding an empirical atom ratio from masses?
   A. Add atomic numbers
   B. Multiply all masses by temperature
   C. Convert each mass to moles
   D. Use masses directly as subscripts
   E. Divide all masses by density

9. A sample contains 2 mol X and 3 mol Y. Its simplest formula ratio is:
   A. XY
   B. X2Y
   C. X3Y2
   D. X4Y6
   E. X2Y3

10. Using H=1 and O=16, the mass percentage of H in H2O is approximately:
   A. 88.9%
   B. 50.0%
   C. 2.0%
   D. 11.1%
   E. 18.0%

11. What coefficients balance H2 + O2 → H2O in smallest integers?
   A. 2,2,1
   B. 1,2,1
   C. 1,1,1
   D. 2,1,2
   E. 1,1,2

12. Which may be changed when balancing a chemical equation?
   A. Element symbols
   B. Formula subscripts
   C. Atomic numbers
   D. The identity of products
   E. Stoichiometric coefficients

13. What is the coefficient of O2 in balanced C3H8 + O2 → CO2 + H2O with C3H8 coefficient 1?
   A. 5
   B. 6
   C. 4
   D. 7
   E. 3

14. Which net ionic equation describes precipitation of silver chloride?
   A. Ag + Cl → AgCl2
   B. Ag⁺ → Ag²⁺
   C. Cl⁻ → Cl2
   D. Ag⁺ + Cl⁻ → AgCl(s)
   E. Na⁺ + NO3⁻ → NaNO3(s)

15. What must be conserved in a balanced ionic equation?
   A. Only coefficients of liquids
   B. Each element's atoms and total charge
   C. Only oxygen atoms
   D. Only total number of molecules
   E. Only volume

16. For 2A + B → 3C, starting with 4 mol A and 3 mol B, what amount of C forms if reaction completes?
   A. 12 mol
   B. 3 mol
   C. 6 mol
   D. 4 mol
   E. 9 mol

17. Which determines the theoretical product amount when both reactants are supplied in known quantities?
   A. The smallest available mole-to-coefficient ratio
   B. The largest volume regardless of conditions
   C. The greatest reactant mass
   D. The greatest number of atoms per molecule
   E. The highest molar mass

18. Actual yield is 12 g and theoretical yield 16 g. Percentage yield?
   A. 25%
   B. 80%
   C. 133%
   D. 4%
   E. 75%

19. For N2 + 3H2 → 2NH3, how many moles of NH3 can form from 6 mol H2 and excess N2?
   A. 2 mol
   B. 4 mol
   C. 12 mol
   D. 6 mol
   E. 3 mol

20. In 2Mg + O2 → 2MgO, 1 mol Mg reacts with 1 mol O2. How much O2 remains after completion?
   A. 0.25 mol
   B. 2 mol
   C. 1 mol
   D. 0.5 mol
   E. 0 mol

21. What is the molarity of 0.30 mol solute in 600 mL solution?
   A. 0.50 mol/L
   B. 0.18 mol/L
   C. 180 mol/L
   D. 2.0 mol/L
   E. 0.0005 mol/L

22. A 10% by mass solution has total mass 250 g. Solute mass?
   A. 10 g
   B. 225 g
   C. 250 g
   D. 2.5 g
   E. 25 g

23. 50 mL of 0.8 M solution is diluted to 200 mL. Final concentration?
   A. 0.80 M
   B. 3.2 M
   C. 0.20 M
   D. 0.05 M
   E. 0.40 M

24. A 0.25 M solute has M=40 g/mol. Its mass concentration is:
   A. 25 g/L
   B. 40.25 g/L
   C. 0.00625 g/L
   D. 160 g/L
   E. 10 g/L

25. What is conserved when adding pure solvent to a solution without reaction or loss?
   A. Solution volume
   B. Solvent amount
   C. Total solution mass
   D. Molar concentration
   E. Moles of solute

26. A reaction has a theoretical yield of 8.0 g and an actual yield of 6.0 g. What is its percentage yield?
   A. 75%
   B. 25%
   C. 50%
   D. 80%
   E. 133%

27. A solution contains 0.100 mol of solute in a final volume of 500 mL. What is its molar concentration?
   A. 0.0500 mol/L
   B. 0.000200 mol/L
   C. 200 mol/L
   D. 50.0 mol/L
   E. 0.200 mol/L

28. For 2H2 + O2 -> 2H2O, a mixture has 3.0 mol H2 and 2.0 mol O2. What is the theoretical amount of water?
   A. 2.0 mol
   B. 4.0 mol
   C. 1.0 mol
   D. 1.5 mol
   E. 3.0 mol

29. 25.0 mL of a 0.400 mol/L solution is diluted to a final volume of 100.0 mL without reaction. What is its final concentration?
   A. 0.400 mol/L
   B. 1.60 mol/L
   C. 0.100 mol/L
   D. 0.0250 mol/L
   E. 4.00 mol/L

30. For 2H2 + O2 -> 2H2O, 4.0 g of H2 reacts with excess O2. Use M(H2)=2.0 g/mol and M(H2O)=18.0 g/mol. What is the theoretical water mass?
   A. 4.0 g
   B. 18 g
   C. 2.0 g
   D. 36 g
   E. 72 g

31. How many moles are in 44 g of CO2 (M=44 g/mol)?
   A. 0.5
   B. 1
   C. 2
   D. 22
   E. 44

32. What is the molarity of 0.30 mol in 1.5 L?
   A. 0.02 M
   B. 0.20 M
   C. 0.45 M
   D. 2.0 M
   E. 5.0 M

33. A 250 g solution is 4% solute by mass. What is the solute mass?
   A. 1 g
   B. 4 g
   C. 6.25 g
   D. 10 g
   E. 100 g
