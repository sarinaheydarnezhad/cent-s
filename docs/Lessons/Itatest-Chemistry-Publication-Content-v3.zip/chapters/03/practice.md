# ساختار اتم و جدول تناوبی — تمرین و تست

1. Mg در کدام گروه و دوره است؟

2. کدام گروه گازهای نجیب است؟

3. عنصر با [He]2s²2p² در کدام بلوک؟

4. چند اوربیتال در p؟

5. l=3 چه زیرلایه‌ای است؟

6. n=1 چه l و m_l دارد؟

7. ۸۰٪ جرم ۲۰ و ۲۰٪ جرم ۲۲؛ Ar؟

8. ²H و ¹H چند پروتون دارند؟

9. میانگین ۶۳٫۵ برای ایزوتوپ‌های ۶۳ و ۶۵؛ سهم ۶۵؟

10. آرایش Cl⁻؟

11. N با 2p³ چند الکترون جفت‌نشده دارد؟

12. آرایش Mg²⁺؟

13. شعاع Na یا Na⁺؟

14. بین F و Cl کدام الکترونگاتیوتر است؟

15. چرا پایین گروه شعاع بزرگ‌تر است؟

## Multiple-choice questions

1. Which group contains the halogens?
   A. 1
   B. 13
   C. 18
   D. 17
   E. 2

2. An element has valence configuration 3s²3p¹. Which period is it in?
   A. 1
   B. 13
   C. 4
   D. 3
   E. 2

3. Which element is an alkaline earth metal?
   A. Al
   B. Na
   C. Mg
   D. Cl
   E. Ne

4. What defines elements' ordering in the modern periodic table?
   A. Alphabetical order
   B. Increasing atomic radius
   C. Increasing density
   D. Increasing atomic mass without exception
   E. Increasing atomic number

5. Which configuration is typical of a neutral Group 17 atom's valence shell?
   A. ns²
   B. ns²np⁶
   C. ns¹
   D. ns²np¹
   E. ns²np⁵

6. Which experiment led to the nuclear model of the atom?
   A. Alpha-particle scattering through thin foil
   B. Electrolysis of molten salt alone
   C. Measuring boiling water
   D. Acid-base titration
   E. Gas chromatography

7. How many orbitals are in a d subshell?
   A. 3
   B. 10
   C. 2
   D. 5
   E. 7

8. Which pair (n,l) is allowed?
   A. 2,2
   B. 0,0
   C. 3,3
   D. 1,1
   E. 3,2

9. What are the possible spin quantum numbers of an electron?
   A. −1,0,+1
   B. Only +1
   C. Any integer
   D. 0 and 1
   E. +1/2 and −1/2

10. What is the maximum electron capacity of the n=3 shell?
   A. 18
   B. 9
   C. 10
   D. 8
   E. 32

11. An element has 60% isotope mass 10 and 40% mass 11. Approximate Ar?
   A. 10.5
   B. 11.4
   C. 10.4
   D. 10.6
   E. 21

12. Which is shared by all isotopes of carbon?
   A. Six neutrons
   B. Identical nuclear stability
   C. Identical mass numbers
   D. Identical mass
   E. Six protons

13. If isotope masses are 24 and 26 and Ar≈25.5, which is more abundant?
   A. Both equally
   B. Mass 24
   C. Mass 26
   D. Cannot be 26
   E. Neither exists

14. How many neutrons are in ²³Na (Z=11)?
   A. 11
   B. 34
   C. 23
   D. 10
   E. 12

15. What distinguishes a neutral atom from its positive ion of the same isotope?
   A. Proton count
   B. Neutron count
   C. Electron count
   D. Atomic number
   E. Mass number

16. What is the ground-state configuration of neutral Na?
   A. [Ne]3s²
   B. [He]2s¹
   C. [Ne]3s¹
   D. [Ar]3s¹
   E. [Ne]3p¹

17. Which rule favours singly occupying degenerate orbitals before pairing?
   A. Proust's law
   B. Le Chatelier's principle
   C. Avogadro's law
   D. Hund's rule
   E. Boyle's law

18. What is the maximum number of electrons in a p subshell?
   A. 8
   B. 3
   C. 10
   D. 6
   E. 2

19. Which is the configuration of Fe²⁺ given neutral Fe=[Ar]3d⁶4s²?
   A. [Ar]3d⁶
   B. [Ar]3d⁸
   C. [Ar]3d⁵4s¹
   D. [Ar]3d⁴4s²
   E. [Ar]4s²

20. Which species is isoelectronic with Ne?
   A. F
   B. Na
   C. F⁻
   D. O⁻
   E. Mg⁺

21. Which neutral atom is generally largest among Li, Na, K, Rb and Cs?
   A. K
   B. Li
   C. Cs
   D. Na
   E. Rb

22. Which element has the greatest electronegativity among F, Cl, Br, I and H?
   A. I
   B. H
   C. Br
   D. Cl
   E. F

23. Which has the smallest radius in this isoelectronic set?
   A. F⁻
   B. O²⁻
   C. Al³⁺
   D. Na⁺
   E. Mg²⁺

24. First ionisation energy is defined for removal of an electron from:
   A. A gaseous neutral atom
   B. A liquid molecule only
   C. An atomic nucleus
   D. A solid crystal only
   E. A neutron

25. Why is the first ionisation energy of B lower than that of Be?
   A. B has fewer protons
   B. B has a smaller mass number necessarily
   C. B's removed electron is in a higher-energy 2p subshell
   D. Be has no electrons
   E. B is a noble gas

26. What is the maximum number of electrons in one atomic orbital?
   A. 3
   B. 2
   C. 6
   D. 8
   E. 1

27. A neutral atom of chlorine-37 has atomic number 17. How many neutrons does it contain?
   A. 54
   B. 18
   C. 17
   D. 20
   E. 37

28. Which atom has the largest atomic radius among Li, Na and K under the usual periodic trend?
   A. The trend cannot distinguish these elements
   B. Li
   C. Na
   D. K
   E. All three have equal radius

29. For an electron with principal quantum number n=2, which set contains all allowed values of l?
   A. {2}
   B. {0, 1}
   C. {-1, 0, 1}
   D. {1, 2}
   E. {0, 1, 2}

30. A sodium ion Na+ has atomic number 11. How many electrons does it contain?
   A. 23
   B. 11
   C. 9
   D. 12
   E. 10

31. How many electrons can a p subshell hold?
   A. 2
   B. 3
   C. 4
   D. 6
   E. 10
