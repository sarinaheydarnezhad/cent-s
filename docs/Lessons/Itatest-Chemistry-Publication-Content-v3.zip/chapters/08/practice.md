# اکسایش و کاهش — تمرین و تست

1. N در NO3⁻؟

2. Cr در Cr2O7²⁻؟

3. H در NaH؟

4. در 2Mg+O2→2MgO اکسنده چیست؟

5. آیا NaCl+AgNO3→AgCl+NaNO3 ردوکس است؟

6. در 2H2O2→2H2O+O2 عدد O چگونه تغییر می‌کند؟

7. Cu²⁺→Cu را موازنه کن.

8. Fe³⁺→Fe²⁺ چند e⁻ نیاز دارد؟

9. O2→H2O در محیط اسیدی؟

10. H⁺+OH⁻ چه می‌سازد؟

11. در MnO4⁻→MnO2 چند الکترون دریافت می‌شود؟

12. بار کل سمت چپ O2+2H2O+4e⁻ چیست؟

13. در سلول گالوانی الکترون به کدام الکترود می‌رود؟

14. آند در الکترولیز کدام واکنش را دارد؟

15. اگر E°cathode=0.5 و E°anode=−0.2، E°cell؟

## Multiple-choice questions

1. What is the oxidation number of oxygen in H2O2?
   A. +2
   B. −2
   C. −1
   D. +1
   E. 0

2. Oxidation number of N in NH4⁺?
   A. −4
   B. +5
   C. +3
   D. −3
   E. +1

3. Oxidation number of Cr in CrO4²⁻?
   A. −6
   B. +4
   C. +8
   D. +2
   E. +6

4. What is the oxidation number of Cl in elemental Cl2?
   A. +1
   B. 0
   C. +2
   D. −1
   E. −2

5. The sum of oxidation numbers in a polyatomic ion equals:
   A. Always zero
   B. Its total number of protons
   C. Its molar mass
   D. Its total number of neutrons
   E. Its net ionic charge

6. Which species is oxidised in Mg + Cu²⁺ → Mg²⁺ + Cu?
   A. Cu²⁺
   B. Mg
   C. Cu
   D. Mg²⁺ as reactant
   E. Both ions are reduced

7. An oxidising agent itself undergoes:
   A. Neither in any reaction
   B. Nuclear decay
   C. Oxidation only
   D. Proton emission necessarily
   E. Reduction

8. Which is not a redox reaction?
   A. 2Mg + O2 → 2MgO
   B. 2H2O2 → 2H2O + O2
   C. C + O2 → CO2
   D. Zn + Cu²⁺ → Zn²⁺ + Cu
   E. HCl + NaOH → NaCl + H2O

9. Which change represents reduction?
   A. Na → Na⁺
   B. Mg → Mg²⁺
   C. Fe³⁺ → Fe²⁺
   D. Cl⁻ → Cl2
   E. Fe²⁺ → Fe³⁺

10. What is the reducing agent in H2 + Cl2 → 2HCl?
   A. Cl2
   B. Neither reactant
   C. HCl
   D. H2
   E. Cl⁻ product

11. How many electrons are required for MnO4⁻ → Mn²⁺ in acidic solution?
   A. 8
   B. 2
   C. 5
   D. 3
   E. 7

12. In Cr2O7²⁻ + 14H⁺ + 6e⁻ → 2Cr³⁺ + xH2O, x equals:
   A. 14
   B. 4
   C. 2
   D. 7
   E. 6

13. What is the electron coefficient in Al → Al³⁺ + xe⁻?
   A. 1
   B. 6
   C. 0
   D. 2
   E. 3

14. For MnO4⁻ reduced to Mn²⁺ and Fe²⁺ oxidised to Fe³⁺, how many Fe²⁺ react per MnO4⁻?
   A. 2
   B. 7
   C. 5
   D. 3
   E. 1

15. What should remain of electrons after adding balanced oxidation and reduction half-reactions?
   A. None in the overall reaction
   B. All on reactant side
   C. One per oxygen atom
   D. All on product side
   E. The same as hydrogen count

16. When converting an acidic half-reaction to basic form, what is added to both sides to remove H⁺?
   A. Na⁺ only
   B. O2 only
   C. Cl⁻
   D. Electrons only
   E. OH⁻

17. How many electrons does MnO4⁻ gain when reduced to MnO2?
   A. 7
   B. 3
   C. 4
   D. 5
   E. 1

18. In O2 + 2H2O + 4e⁻ → xOH⁻, x equals:
   A. 2
   B. 1
   C. 8
   D. 6
   E. 4

19. In Cl2 + 2OH⁻ → Cl⁻ + ClO⁻ + H2O, chlorine undergoes:
   A. Only reduction
   B. Nuclear fission
   C. Only oxidation
   D. No oxidation state change
   E. Disproportionation

20. Which check is essential after balancing a redox half-reaction?
   A. Only colour
   B. Only oxygen mass
   C. Both atom counts and total charge
   D. Only volume
   E. Only molecule count

21. Where does oxidation occur in a galvanic cell?
   A. Both electrodes always
   B. Salt bridge only
   C. Neither electrode
   D. Anode
   E. Cathode

22. E°red cathode=+0.60 V, E°red anode=−0.20 V. E°cell?
   A. −0.80 V
   B. −0.40 V
   C. +0.40 V
   D. +0.80 V
   E. +0.12 V

23. Which reduction half-cell is the stronger standard oxidant in the comparison?
   A. The one with more negative E°red always
   B. The one with lower atomic number only
   C. The one with greater mass only
   D. The one whose equation has more coefficients
   E. The one with more positive E°red

24. What is the main role of a salt bridge in a galvanic cell?
   A. Providing all chemical energy
   B. Changing the atomic numbers
   C. Maintaining charge balance through ion migration
   D. Stopping both half-reactions
   E. Carrying electrons through the solution as a metal wire

25. If a balanced half-reaction is multiplied by 2, its standard reduction potential:
   A. Changes sign necessarily
   B. Halves
   C. Remains unchanged
   D. Doubles
   E. Becomes zero

26. In Zn + Cu2+ -> Zn2+ + Cu, which species is the oxidising agent?
   A. Zn
   B. Cu
   C. Zn2+
   D. Cu2+
   E. Both neutral metals

27. In Fe2+ -> Fe3+ + e-, the iron species undergoes:
   A. oxidation by gaining one proton
   B. reduction by losing one neutron
   C. oxidation by losing one electron
   D. no change in oxidation state
   E. reduction by gaining one electron

28. What is the oxidation number of sulfur in SO4^2-?
   A. +2
   B. 0
   C. +4
   D. +6
   E. -2

29. Standard reduction potentials are +0.34 V for Cu2+/Cu and -0.76 V for Zn2+/Zn. What is E cell for the spontaneous standard Zn/Cu galvanic cell?
   A. -0.42 V
   B. +0.42 V
   C. -1.10 V
   D. +1.10 V
   E. +0.2584 V

30. In Zn + Cu2+ -> Zn2+ + Cu, which species is the reducing agent?
   A. Cu
   B. Zn2+
   C. Cu2+
   D. Neither reactant
   E. Zn

31. What is the oxidation number of N in NO3−?
   A. −3
   B. −1
   C. +1
   D. +3
   E. +5
