# شیمی کاربردی — تمرین و تست

1. ۳۵۰ mg چند g؟

2. 20.0±0.5 mL چه عدم قطعیت درصدی؟

3. 2.3+1.42 با قاعده ارقام اعشاری؟

4. عامل اصلی ایجاد حباب در تخمیر الکلی؟

5. چرا شوینده می‌تواند چربی را در آب پراکنده کند؟

6. چرا خشک شدن لباس تغییر فیزیکی است؟

7. ۱۲ g پروتئین در ۱۰۰ g؛ ۱۵۰ g محصول؟

8. ۴۰۰ mg در هر سهم و ۳ سهم؟

9. محلول ۲٪ جرمی، جرم کل ۵۰۰ g؛ حل‌شونده؟

10. چرا اوزون سطح زمین و اوزون استراتوسفر اثر متفاوت دارند؟

11. دو ماده مرتبط با یوتریفیکاسیون؟

12. اقتصاد اتمی در واکنش A+B→C که C تنها محصول و موازنه کامل است؟

13. تفاوت hazard و risk؟

14. برای اطلاعات نگهداری و کمک اولیه چه سندی؟

15. چرا مواد پاک‌کننده نباید خودسرانه مخلوط شوند؟

## Multiple-choice questions

1. What is 0.250 L in mL?
   A. 250 mL
   B. 0.25 mL
   C. 2500 mL
   D. 25 mL
   E. 2.5 mL

2. A measurement is 50.0 ± 1.0 g. Relative percentage uncertainty?
   A. 2%
   B. 1%
   C. 0.02%
   D. 50%
   E. 5%

3. Repeated values are tightly grouped but far from the reference. They are:
   A. Neither repeated nor measured
   B. Free of systematic error necessarily
   C. Both accurate and precise necessarily
   D. Precise but inaccurate
   E. Accurate but imprecise

4. How many significant figures are in 0.00450?
   A. 3
   B. 4
   C. 2
   D. 5
   E. 6

5. Convert 2.0 mg to grams.
   A. 0.020 g
   B. 2.0 g
   C. 0.0020 g
   D. 2000 g
   E. 0.20 g

6. What gas is produced in the idealised alcoholic fermentation of glucose?
   A. Cl2
   B. O2
   C. CO2
   D. He
   E. N2

7. Which ions mainly contribute to ordinary water hardness?
   A. Ne and Ar
   B. H⁺ and Cl⁻ only
   C. Ca²⁺ and Mg²⁺
   D. Na⁺ and K⁺ only
   E. Electrons and neutrons

8. Which structural feature helps a surfactant remove grease?
   A. Only identical neutral atoms
   B. A radioactive core
   C. Hydrophilic and hydrophobic regions
   D. Absence of any interaction with water
   E. Only a metallic nucleus

9. Which process is an example of corrosion?
   A. Dissolving sugar
   B. Rusting of an iron object
   C. Condensing steam
   D. Breaking glass
   E. Melting ice

10. What gas is typically produced by acid reacting with a carbonate?
   A. N2
   B. CO2
   C. Ar
   D. He
   E. O2

11. A label states 6 g sugar per 100 mL. How much in 300 mL?
   A. 60 g
   B. 30 g
   C. 2 g
   D. 6 g
   E. 18 g

12. A package contains 4 servings, each with 250 mg sodium. Total sodium?
   A. 0.25 g
   B. 100 g
   C. 4 g
   D. 0.1 g
   E. 1.0 g

13. A 4% w/w solution has mass 150 g. Solute mass?
   A. 37.5 g
   B. 4 g
   C. 146 g
   D. 6 g
   E. 60 g

14. What additional quantity generally converts mass percent to mass per volume?
   A. Atomic number alone
   B. Solution density
   C. Container colour
   D. Number of printed ingredients
   E. Air temperature only

15. A food label gives 100 kcal. Approximately how many kJ is this?
   A. 418 kJ
   B. 24 kJ
   C. 4.184 kJ
   D. 4184 kJ
   E. 100 kJ

16. Which pollutants are major precursors of acid deposition?
   A. SO2 and nitrogen oxides
   B. NaCl and glucose
   C. O2 and water alone
   D. He and Ne
   E. N2 and Ar only

17. Which physical process is central to the greenhouse effect?
   A. Only ultraviolet scattering by nitrogen
   B. Nuclear fission in the lower atmosphere
   C. Precipitation of solid salts
   D. Absorption and emission of infrared radiation
   E. Filtration of sunlight by rain alone

18. Photochemical smog is strongly linked to sunlight, NOx and:
   A. Distilled water alone
   B. Solid gold
   C. Volatile organic compounds
   D. Helium only
   E. Pure nitrogen alone

19. Excess nitrogen and phosphorus in water can promote:
   A. Elimination of all microorganisms
   B. Eutrophication
   C. Nuclear decay
   D. Formation of pure oxygen everywhere
   E. Atmospheric pressure doubling

20. If reactants total 100 g stoichiometrically and the desired product accounts for 70 g, theoretical atom economy is:
   A. 30%
   B. 100%
   C. 0%
   D. 142.9%
   E. 70%

21. What does SDS stand for in chemical safety?
   A. Solution Dilution System
   B. Safety Data Sheet
   C. Standard Density Scale
   D. Scientific Data Sample
   E. Salt Dissociation Standard

22. A GHS flame-over-circle pictogram generally identifies which type of hazard?
   A. No hazard
   B. Only low temperature
   C. Radioactivity necessarily
   D. Biological infection
   E. Oxidising hazard

23. What is the safest general action when a chemical container has no identifiable label?
   A. Smell it directly
   B. Taste it to identify it
   C. Pour it into a food container
   D. Mix it with another product
   E. Do not use it; report it to the responsible person

24. Which statement best distinguishes risk from hazard?
   A. Risk is the molecular mass
   B. Risk is independent of exposure
   C. Risk depends on exposure and consequences as well as inherent hazard
   D. They always have identical meaning
   E. Hazard means a harmless substance

25. What should guide the safe use of a commercial chemical product?
   A. Unverified mixing advice
   B. Its label and applicable safety instructions
   C. Its smell alone
   D. The shape of its bottle alone
   E. Its colour alone

26. Which emissions are most directly associated with the formation of acid rain?
   A. Sulfur dioxide and nitrogen oxides
   B. Nitrogen gas alone
   C. Oxygen and argon
   D. Water vapour alone
   E. Helium and neon

27. A balance reports a mass of 10.0 +/- 0.2 g. Which report preserves that stated measurement information?
   A. 10.2 g with zero uncertainty
   B. 10.0 g with an uncertainty of 0.2 g
   C. A mass somewhere between 0 and 20 g
   D. 10.000000 g exactly
   E. An uncertainty-free mass of 10 g

28. A drink label states 8.0 g of sugar per 100 mL. How much sugar is in 250 mL?
   A. 20 g
   B. 8.0 g
   C. 3.2 g
   D. 12.0 g
   E. 32.0 g

29. What molecular interaction directly underlies the greenhouse role of carbon dioxide?
   A. Absorption and emission of infrared radiation
   B. Reflection of all visible sunlight by individual molecules
   C. Conversion of all oxygen into ozone
   D. Removal of gravity
   E. Elimination of molecular motion

30. A solution is 5.0% solute by mass. What mass of solute is present in 200 g of solution?
   A. 5.0 g
   B. 0.10 g
   C. 40 g
   D. 10 g
   E. 195 g
