# خواص ماکروسکوپی ماده — تمرین و تست

1. چرا لباس خیس بدون جوشیدن خشک می‌شود؟

2. انجماد ۲۵ g ماده با L=80 J/g چه Q دارد؟

3. اگر ۱۰ g یخ در صفر درجه ذوب و سپس آب تا ۱۰ درجه گرم شود، L=334 و c=4.18، انرژی کل؟

4. چرا میعان بخار آب فیزیکی است؟

5. کدام در پخت تخم مرغ رخ می‌دهد: فقط تغییر شکل یا تغییر در ساختار پروتئین‌ها؟

6. آیا تغییر رنگ محلول با افزودن آب حتماً واکنش است؟

7. چرا حشره سبک روی سطح آب می‌ماند؟

8. جرم ۹۰ g در حجم ۱۲۰ cm³ چه چگالی دارد؟

9. در هوای ساکن چرا بوی عطر پخش می‌شود؟

10. آب و روغن چه نوع مخلوطی هستند؟

11. برای بازیابی شکر از محلول بدون بازیابی آب چه روشی مناسب است؟

12. چرا آب مقطر خالص مخلوط نیست؟

13. در ظرف بسته ۲۵ g A و ۱۰ g B داریم؛ ۵ g A باقی می‌ماند و فقط C تشکیل می‌شود. جرم C؟

14. جرم اکسیژن در ۳۶ g آب خالص با جرم اتمی تقریبی؟

15. چرا حجم برابر He و O2 الزاماً جرم برابر نیست؟

## Multiple-choice questions

1. During equilibrium melting of a pure substance at constant pressure, what stays constant?
   A. Enthalpy
   B. Entropy
   C. Internal energy
   D. Temperature
   E. Amount of liquid

2. Which phase change is gas directly to solid?
   A. Boiling
   B. Sublimation
   C. Deposition
   D. Fusion
   E. Condensation

3. A liquid absorbs 600 J without changing phase. Its mass is 50 g and c=2 J/(g K). What is its temperature rise?
   A. 150 K
   B. 6 K
   C. 60 K
   D. 12 K
   E. 24 K

4. Which statement about evaporation is correct?
   A. It always increases liquid temperature
   B. It can occur below the boiling point
   C. It creates new chemical species
   D. It requires all liquid to boil
   E. It occurs only at 100 °C

5. If external pressure decreases, the boiling temperature of water generally does what?
   A. Decreases
   B. Becomes independent of pressure
   C. Remains exactly 100 °C
   D. Increases
   E. Becomes zero kelvin

6. Which process clearly forms a new chemical substance?
   A. Sugar dissolving in water
   B. Glass breaking
   C. Ice melting
   D. Iron rusting
   E. Water freezing

7. Which observation alone is insufficient to prove a reaction?
   A. Verified conversion to different chemical species
   B. A temperature change
   C. Chemical identification of a new product
   D. Confirmed rearrangement into a different molecular species
   E. Identification of a new compound

8. Which is a physical change under ordinary conditions?
   A. Neutralisation of HCl by NaOH
   B. Fermentation of glucose
   C. Combustion of methane
   D. Corrosion of zinc
   E. Condensation of steam

9. Which conclusion follows from the absence of a visible change after mixing two solutions?
   A. Both solutions must be pure water
   B. All reactants were consumed
   C. The reaction must be endothermic
   D. No reaction is possible
   E. A reaction may still have occurred

10. What is the main criterion for a chemical transformation?
   A. A change in volume
   B. Formation of different chemical species
   C. A change in shape
   D. Difficulty of reversing the process
   E. A change in physical state

11. A sample has mass 80 g and volume 40 cm³. What is its density?
   A. 3200 g/cm³
   B. 40 g/cm³
   C. 2 g/cm³
   D. 120 g/cm³
   E. 0.5 g/cm³

12. What causes gas pressure on a rigid container wall?
   A. A lack of thermal motion
   B. Momentum transfer in molecular collisions
   C. The weight of each molecule alone
   D. Expansion of each atom
   E. Chemical bonds with the wall

13. Which property primarily describes resistance to flow?
   A. Density
   B. Molar mass
   C. Viscosity
   D. Compressibility
   E. Boiling point

14. Why is a gas usually far more compressible than a liquid?
   A. Its particles have no mass
   B. Its atoms shrink under pressure
   C. Its particles are much farther apart
   D. Its molecules are always larger
   E. Its particles stop moving

15. Which statement about diffusion is correct?
   A. It requires a pump
   B. It requires a chemical reaction
   C. It can occur in solids, usually slowly
   D. It occurs only in gases
   E. It stops whenever temperature is constant

16. Which mixture is homogeneous under the stated conditions?
   A. Oil and water in two layers
   B. Completely dissolved salt in water
   C. Granite
   D. Sand in water
   E. Milk emulsion

17. Which method retains insoluble sand while dissolved salt passes through?
   A. Simple distillation
   B. Sublimation
   C. Magnetic separation
   D. Filtration
   E. Freezing the entire mixture

18. Which method is most appropriate to collect water from a solution of a nonvolatile salt?
   A. Distillation
   B. Sedimentation
   C. Filtration alone
   D. Sieving
   E. Magnetic separation

19. Chromatography separates substances primarily by differences in what?
   A. Interactions and partitioning between phases
   B. Total mass of the sample
   C. Number of containers
   D. Nuclear stability
   E. Atomic number only

20. Which is a pure chemical compound in the idealised description?
   A. Air
   B. Brass
   C. CO2
   D. Seawater
   E. Milk

21. Which law states a fixed mass ratio of elements in a stoichiometric pure compound?
   A. Avogadro's law
   B. Law of definite proportions
   C. Dalton's law of partial pressures
   D. Boyle's law
   E. Law of combining volumes

22. In a closed vessel 18 g and 12 g of two reactants are completely converted into one product. Its mass is:
   A. 18 g
   B. 12 g
   C. 216 g
   D. 30 g
   E. 6 g

23. For N2 + 3H2 → 2NH3(g), what volume of H2 is consumed by 15 mL of N2 at equal T and P (ideal gases)?
   A. 15 mL
   B. 60 mL
   C. 5 mL
   D. 45 mL
   E. 30 mL

24. Equal volumes of ideal neon and oxygen at the same T and P contain equal numbers of:
   A. Electrons
   B. Atoms
   C. Gas particles
   D. Protons
   E. Grams

25. Using H=1 and O=16, what is the approximate oxygen mass percentage in water?
   A. 66.7%
   B. 88.9%
   C. 50.0%
   D. 11.1%
   E. 16.0%

26. At 1 atm, how much heat is needed to vaporize 15 g of water at its boiling point? (L = 2260 J/g)
   A. 150.7 J
   B. 1507 J
   C. 15070 J
   D. 33900 J
   E. 3390 J

27. For an ideal gas, absolute temperature is proportional to which quantity?
   A. Total energy of the sample
   B. Mean translational kinetic energy per particle
   C. Particle mass
   D. Pressure at arbitrary volume
   E. Number of particles

28. For the same mass of a pure substance at constant pressure, a heating curve plots temperature against net heat absorbed. The boiling plateau is wider than the melting plateau. Why?
   A. Mass increases
   B. Latent heat of vaporization exceeds latent heat of fusion
   C. The sample is impure
   D. Heating power increases
   E. Temperature rises during boiling

29. A 30 g sample melts at constant temperature. L=200 J/g. How much heat is absorbed?
   A. 230 J
   B. 6.67 J
   C. 6000 J
   D. 600 J
   E. 60000 J

30. A 20 g sample freezes at constant temperature. L=200 J/g. What is Q for the sample?
   A. +4000 J
   B. −200 J
   C. +200 J
   D. −4000 J
   E. 0 J

31. A 40 g solid absorbs 8000 J while melting at constant temperature. What is its latent heat of fusion?
   A. 320000 J/g
   B. 200 J/g
   C. 0.005 J/g
   D. 20 J/g
   E. 8000 J/g

32. Two colorless solutions are mixed. The result is still perfectly colorless and no bubbles or precipitate appear. Which is the most accurate conclusion?
   A. No chemical change occurred
   B. A chemical change definitely occurred
   C. The absence of visible signs does not rule out a chemical change
   D. The solutions must be identical
   E. The absence of visible signs proves that no energy was transferred

33. Which observation alone cannot establish that a chemical reaction occurred?
   A. A verified new chemical species
   B. A verified new compound
   C. A temperature increase
   D. Chemical analysis confirming new products
   E. Verified conversion to different chemical species

34. Which is a chemical change?
   A. Melting butter
   B. Tearing paper
   C. Burning paper
   D. Freezing juice
   E. Dissolving sugar in water

35. Which process is a chemical change involving combustion?
   A. Sugar dissolving in water
   B. Cutting paper into pieces
   C. wood burning
   D. Water boiling
   E. Melting pure ice

36. Which process is a chemical change involving corrosion?
   A. Pure ice melting
   B. Sugar dissolving in water
   C. Cutting paper into pieces
   D. iron rusting
   E. Evaporating pure water

37. Which process involves chemical changes during souring?
   A. Cutting paper into pieces
   B. milk souring
   C. Pure ice melting
   D. Sugar dissolving in water
   E. Crushing a salt crystal

38. Why can a gas be compressed much more than a liquid?
   A. Gas particles have no mass
   B. Gas particles disappear under pressure
   C. Liquid particles cannot move at all
   D. There is much more empty space between gas particles
   E. Gas particles shrink substantially under pressure

39. Why does increasing pressure have almost no effect on the volume of a liquid, unlike a gas?
   A. Liquids have stronger chemical bonds
   B. Liquid particles are already nearly touching, leaving little empty space to remove
   C. Liquids are always denser than gases
   D. Pressure cannot act on liquids
   E. Liquid particles have zero mass

40. What directly produces the pressure of a gas on its container walls?
   A. The color of the container
   B. Collisions of gas particles with the walls
   C. Only gravitational attraction
   D. A complete absence of particle motion
   E. The chemical identity of the gas

41. In still air, perfume molecules spread from a region of high concentration to lower concentration. Which process describes this?
   A. Surface tension
   B. Diffusion
   C. Compression
   D. Sedimentation
   E. Crystallization

42. A liquid flows but nearly keeps its volume. Which particle-level model explains this?
   A. Particles are infinitely far apart
   B. Particles have stopped moving
   C. Particles remain close but can slide past one another
   D. Particles occupy fixed lattice positions only
   E. Particles form a rigid crystal lattice

43. A water strider insect can walk on the surface of a pond without sinking. Which property is primarily responsible?
   A. Compressibility
   B. Diffusibility
   C. Surface tension
   D. Boiling point
   E. Electrical conductivity

44. Which method is suitable for separating two miscible liquids of sufficiently different volatility?
   A. Evaporation
   B. Magnetic separation
   C. Distillation
   D. Filtration
   E. Sieving

45. Choose the appropriate separation method for insoluble sand suspended in water.
   A. Distillation
   B. Evaporation
   C. Magnetic separation
   D. Filtration
   E. Chromatography of dissolved dyes

46. Milk appears completely uniform to the naked eye. Why is it still classified as heterogeneous?
   A. It has a white color
   B. It contains dispersed fat droplets in an aqueous phase (an emulsion)
   C. It is a pure substance
   D. It cannot be filtered
   E. Milk consists of a single chemical element

47. Which method best separates two miscible liquids with close boiling points when no azeotrope prevents separation?
   A. Filtration
   B. Fractional distillation
   C. Magnetic separation
   D. Decantation
   E. Sieving

48. Which of the following is a heterogeneous mixture?
   A. Air
   B. Saltwater
   C. Oil and water
   D. Sugar water
   E. Pure distilled water

49. Which method recovers a nonvolatile dissolved salt when collecting the solvent is not required?
   A. Magnetic separation
   B. Evaporation
   C. Centrifugation without precipitating the salt
   D. Filtration through ordinary filter paper after adding more water
   E. Sieving

50. Which law states that total mass is conserved in an ordinary chemical reaction in a closed system?
   A. Law of definite proportions
   B. Law of conservation of mass
   C. Law of combining volumes
   D. Avogadro’s law
   E. Law of multiple proportions

51. In a closed system, 30 g A and 15 g B react completely to form only C. What mass forms?
   A. 15 g
   B. 30 g
   C. 45 g
   D. 450 g
   E. 0 g

52. A sealed vessel contains 40 g A and 20 g B. After reaction, 10 g A remains and only C forms. All B is consumed. What mass of C forms?
   A. 60 g
   B. 50 g
   C. 30 g
   D. 20 g
   E. 70 g

53. An open vessel initially contains 20 g A and 10 g B. After reaction, 24 g remains in the vessel and only gas escaped. What mass escaped?
   A. 24 g
   B. 30 g
   C. 4 g
   D. 6 g
   E. 10 g

54. Hydrogen and oxygen react to form water vapor: 2H₂ + O₂ → 2H₂O. If 40 mL of oxygen reacts completely, what volume of hydrogen was used (same T, P)?
   A. 20 mL
   B. 40 mL
   C. 60 mL
   D. 80 mL
   E. 120 mL

55. Equal volumes of ideal helium and carbon dioxide at the same temperature and pressure have:
   A. Equal gas masses
   B. Equal particle counts but different gas masses
   C. Fewer CO2 particles
   D. Counts dependent on vessel shape
   E. Equal molar masses

56. Two stoichiometric compounds contain elements X and Y. Compound A contains 3.00 g Y per 1.00 g X; compound B contains 1.50 g Y per 1.00 g X. Which law and ratio of Y masses (A:B) are illustrated?
   A. 1:2 — Law of Definite Proportions
   B. 2:1 — Law of Multiple Proportions
   C. 2:1 — Gay-Lussac's Law
   D. 1:1 — Avogadro's Law
   E. 3:1 — Law of Multiple Proportions

57. A mixture contains insoluble sand and dissolved sodium chloride. Which sequence separates sand and recovers salt from the filtrate?
   A. Evaporate, then filter the dry solid
   B. Filter, then evaporate water from the filtrate
   C. Filter the dissolved salt directly
   D. Use a magnet, then freeze the liquid
   E. Decant the salt crystals before any water is removed

58. Two ideal molecular gases occupy equal volumes at the same temperature and pressure. They must have equal:
   A. total masses
   B. molecular masses
   C. numbers of atoms per molecule
   D. numbers of molecules
   E. mass densities

59. In a sealed vessel, 12.0 g of carbon reacts completely with 32.0 g of oxygen to form only carbon dioxide. What mass of carbon dioxide forms?
   A. 20.0 g
   B. 32.0 g
   C. 56.0 g
   D. 12.0 g
   E. 44.0 g

60. Water vapour changes directly into ice on a cold surface. What phase change occurs?
   A. Condensation into liquid only
   B. Sublimation
   C. Deposition
   D. Boiling
   E. Melting

61. In a sealed vessel, 12.0 g of A reacts completely with 8.0 g of B to form only C. What mass of C forms?
   A. 8.0 g
   B. 20.0 g
   C. 4.0 g
   D. 96.0 g
   E. 12.0 g

62. A 20 g sample occupies 8 cm³. What is its density?
   A. 0.4 g/cm³
   B. 2.5 g/cm³
   C. 12 g/cm³
   D. 28 g/cm³
   E. 160 g/cm³
