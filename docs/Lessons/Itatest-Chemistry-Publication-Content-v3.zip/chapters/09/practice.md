# شیمی آلی — تمرین و تست

1. فرمول هپتان؟

2. نام CH3–CH2–CH2–CH3؟

3. فرمول سیکلوپروپان؟

4. فرمول آلکن باز تک‌دوگانه با ۶ C؟

5. هیبریداسیون C در اتین؟

6. نام C6H5CH3؟

7. موازنه احتراق کامل CH4؟

8. از ۲ mol بوتان در احتراق کامل چند mol CO2؟

9. چرا آلکان شاخه‌دار هم‌فرمول غالباً نقطه جوش پایین‌تر دارد؟

10. CH3CH2CHO چیست؟

11. CH3OCH3؟

12. CH3COCH2CH3؟

13. ethanol و methoxymethane چه نوع ایزومری؟

14. آیا CH2=CHCl ایزومر E/Z دارد؟

15. چرا ایزومرها جرم مولی برابر دارند؟

## Multiple-choice questions

1. What is the molecular formula of acyclic saturated pentane?
   A. C5H10
   B. C5H6
   C. C5H12
   D. C5H14
   E. C5H8

2. What hybridisation is assigned to carbon in methane?
   A. No hybridisation in the usual model
   B. dsp²
   C. sp³
   D. sp
   E. sp²

3. What is the name of CH3CH(CH3)CH3?
   A. But-1-ene
   B. 2-methylbutane
   C. 2-methylpropane
   D. Propane
   E. Cyclobutane

4. What formula describes a saturated monocyclic hydrocarbon with 5 carbons?
   A. C5H10
   B. C5H12
   C. C5H6
   D. C5H8
   E. C5H14

5. Which is a saturated acyclic hydrocarbon?
   A. Ethanol
   B. Ethyne
   C. Benzene
   D. Ethane
   E. Ethene

6. What is the formula of acyclic hexyne with one triple bond?
   A. C6H8
   B. C6H6
   C. C6H14
   D. C6H10
   E. C6H12

7. How many pi bonds are in a carbon-carbon triple bond?
   A. 1
   B. 3
   C. 0
   D. 4
   E. 2

8. Which formula represents ethene?
   A. HC≡CH
   B. CH3OH
   C. CH2=CH2
   D. CH3CH3
   E. C6H6

9. What best describes the carbon-carbon bonds in benzene?
   A. Equivalent bonds with delocalised pi electrons
   B. Six ionic bonds
   C. Six triple bonds
   D. Three permanently distinct single and three double bonds only
   E. No pi electrons

10. Which reaction type is commonly associated with simple alkenes?
   A. Only acid-base neutralisation
   B. Only crystallisation
   C. Only nuclear decay
   D. Addition across C=C
   E. No reaction under any condition

11. How many moles of O2 are needed for complete combustion of 1 mol C2H6?
   A. 2 mol
   B. 3 mol
   C. 6 mol
   D. 3.5 mol
   E. 4 mol

12. What are the products of complete methane combustion with excess oxygen?
   A. CO2 and H2O
   B. CO and H2 only
   C. C and O2 only
   D. H2 and O2 only
   E. CH3OH only

13. Which toxic gas can be formed by incomplete combustion?
   A. O2
   B. H2O vapour only
   C. CO
   D. He
   E. N2 from pure methane necessarily

14. Complete combustion of 0.5 mol C4H10 produces how much CO2?
   A. 2 mol
   B. 1 mol
   C. 0.5 mol
   D. 5 mol
   E. 4 mol

15. Which usually has the higher normal boiling point among these isomeric alkanes?
   A. n-Pentane
   B. 2,2-Dimethylpropane
   C. Both boil at 0 °C
   D. Neither has a boiling point
   E. Both must be equal

16. Which formula contains a carboxylic acid group?
   A. CH3OCH3
   B. CH3COCH3
   C. CH3COOH
   D. CH3CHO
   E. CH3CH2OH

17. Which compound is an aldehyde?
   A. CH3CH2OH
   B. CH3COOCH3
   C. CH3CH2CHO
   D. CH3OCH3
   E. CH3COCH3

18. What is CH3COCH3 named?
   A. Ethanoic acid
   B. Propan-1-ol
   C. Methoxyethane
   D. Propanal
   E. Propanone

19. Which condensed formula represents an ester?
   A. CH3COOCH2CH3
   B. CH3CH2OCH3
   C. CH3COOH
   D. CH3CH2OH
   E. CH3CH2CHO

20. Which name corresponds to CH3CH2OH?
   A. Ethanol
   B. Ethyl ethanoate
   C. Ethanoic acid
   D. Ethanal
   E. Ethene

21. Which pair are structural isomers?
   A. Ethene and ethane
   B. Propan-1-ol and propan-2-ol
   C. Water and hydrogen peroxide
   D. CO and CO2
   E. Methane and ethane

22. Which alkene can show geometric isomerism?
   A. Ethene
   B. Propene
   C. But-2-ene
   D. 2-Methylpropene
   E. But-1-ene

23. What must isomers share?
   A. Identical three-dimensional arrangement
   B. Identical boiling point
   C. Identical atom connectivity in all types
   D. Identical functional group in all types
   E. Molecular formula

24. What kind of isomerism relates ethanol and dimethyl ether?
   A. Functional group isomerism
   B. Isotopic variation
   C. Identical compound
   D. Chain length difference
   E. Nuclear isomerism

25. Which simple structural feature can create a chiral carbon centre?
   A. A CH2 group with two identical H atoms
   B. Four identical substituents
   C. A free carbon atom alone
   D. Four different substituents on a tetrahedral carbon
   E. A linear carbon with two identical ends

26. In complete combustion, 1 mol of methane produces how many moles of carbon dioxide?
   A. 1 mol
   B. 3 mol
   C. 2 mol
   D. 0.5 mol
   E. 4 mol

27. Which functional group distinguishes a carboxylic acid?
   A. -OH without a carbonyl
   B. A carbon-carbon triple bond
   C. -COOH
   D. -O- between two carbon atoms
   E. A halogen atom alone

28. Ethanol, CH3CH2OH, and dimethyl ether, CH3OCH3, are:
   A. isotopes
   B. members of the same homologous series
   C. ions differing by one electron
   D. structural isomers
   E. the same compound under different names

29. Which compound can have geometric isomers about its carbon-carbon double bond?
   A. But-2-ene
   B. But-1-ene
   C. 2-Methylpropene
   D. Ethene
   E. Propene

30. Which listed molecule contains an ester linkage, –C(=O)–O–C–?
   A. CH3COOCH3
   B. CH3CHO
   C. CH3OCH3
   D. CH3CH2OH
   E. CH3COCH3

31. Which formula represents an aldehyde?
   A. CH3COOH
   B. CH3CHO
   C. CH3OCH3
   D. CH3COCH3
   E. CH3CH2OH
