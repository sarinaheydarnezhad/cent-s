# اسید و باز — تمرین و تست

1. باز مزدوج H2CO3؟

2. اسید مزدوج OH⁻؟

3. در NH3+H2O⇌NH4⁺+OH⁻ کدام گونه پروتون می‌دهد؟

4. کدام قوی‌تر: Ka=10⁻³ یا 10⁻⁶؟

5. برای Ka=10⁻⁶، pKa؟

6. چرا با رقیق‌سازی اسید ضعیف درصد یونیزاسیون می‌تواند افزایش یابد؟

7. [H3O⁺]=10⁻⁵ M، pH؟

8. pH=9 در ۲۵°C، [OH⁻]؟

9. HCl رقیق از 0.01 M به 0.001 M می‌رسد؛ pH چه تغییر می‌کند؟

10. ۲۵ mL NaOH 0.1 M با HCl 0.1 M چه حجمی هم‌ارز است؟

11. NH4Cl محلول اسیدی یا بازی؟

12. برای ۰٫۰۲ mol H2SO4 در خنثی‌سازی کامل چند mol NaOH؟

13. اگر A⁻/HA=10، pH نسبت به pKa؟

14. بافر NH3/NH4Cl افزودن اسید را چگونه تعدیل می‌کند؟

15. چرا بافر پس از مصرف کامل A⁻ در برابر اسید ضعیف می‌شود؟

## Multiple-choice questions

1. A Brønsted–Lowry acid is a species that:
   A. Must contain OH⁻
   B. Donates a proton
   C. Accepts a proton only
   D. Must be a metal
   E. Donates a neutron

2. What is the conjugate base of HSO4⁻?
   A. SO4²⁻
   B. HSO3⁻
   C. SO3²⁻
   D. H2SO4
   E. H3O⁺

3. Which can act as both proton donor and acceptor?
   A. Na⁺
   B. HCO3⁻
   C. K⁺
   D. Cl⁻ as a proton donor
   E. CH4 under ordinary aqueous conditions

4. A Lewis acid is a species that:
   A. Accepts an electron pair
   B. Contains only hydroxide
   C. Must donate H⁺ in every reaction
   D. Accepts a neutron
   E. Donates an electron pair only

5. In NH3 + H2O ⇌ NH4⁺ + OH⁻, NH3 acts as:
   A. A proton acceptor
   B. An insoluble salt
   C. A spectator ion
   D. A proton donor
   E. An oxidant necessarily

6. Which is normally a strong acid in dilute water?
   A. HCN
   B. HCl
   C. H2CO3
   D. CH3COOH
   E. HF

7. Which Ka corresponds to the strongest acid among these?
   A. 10⁻⁸
   B. 10⁻²
   C. 10⁻¹⁰
   D. 10⁻⁴
   E. 10⁻⁶

8. For Ka=10⁻⁵, pKa is:
   A. 10
   B. −5
   C. 5
   D. 0.00001
   E. 14

9. At 25 °C, Ka for HA is 10⁻⁶. Kb of A⁻ is approximately:
   A. 10⁻⁸
   B. 10⁻⁶
   C. 10⁻²⁰
   D. 10⁸
   E. 10⁻¹⁴

10. Which distinguishes a weak acid from a strong acid at the same moderate concentration?
   A. The colour in every case
   B. The number of litres only
   C. The mass of container
   D. The presence of hydrogen atoms only
   E. The fraction ionised in water

11. At 25 °C, what is the approximate pH of 10⁻² M HCl?
   A. 2
   B. 10
   C. 12
   D. 7
   E. −2

12. At 25 °C, pOH=3. What is pH?
   A. 11
   B. 3
   C. 17
   D. 7
   E. 14

13. A pH decreases from 5 to 3. Hydronium activity increases by:
   A. 5/3 times
   B. 10 times
   C. 100 times
   D. 1/100
   E. 2 times

14. Which colour is phenolphthalein typically at pH 9.5?
   A. Pink
   B. Red-orange like methyl orange
   C. Green
   D. Blue
   E. Black

15. At 25 °C, a dilute solution has [OH⁻]=10⁻⁴ M. It is:
   A. Neutral, pH≈7
   B. Acidic, pH≈10
   C. Acidic, pH≈4
   D. Basic, pH≈10
   E. Always pH zero

16. How many mL of 0.2 M NaOH neutralise 20 mL of 0.1 M HCl?
   A. 40 mL
   B. 100 mL
   C. 10 mL
   D. 20 mL
   E. 5 mL

17. Which salt typically gives an acidic aqueous solution?
   A. NH4Cl
   B. CH3COONa
   C. NaCl
   D. KNO3
   E. Na2CO3

18. Which salt typically gives a basic aqueous solution?
   A. KCl
   B. NH4Cl
   C. NaNO3
   D. Na2CO3
   E. NH4NO3

19. At equivalence for a weak monoprotic acid titrated by strong base, the solution is usually:
   A. Basic
   B. Free of all ions
   C. Strongly acidic in every case
   D. Pure water
   E. Always pH 7

20. How many moles OH⁻ completely neutralise 0.10 mol H3PO4 if all three acidic protons are neutralised?
   A. 0.033 mol
   B. 0.30 mol
   C. 3.0 mol
   D. 0.20 mol
   E. 0.10 mol

21. Which mixture is a conventional buffer?
   A. NaOH and NaCl
   B. Pure water alone
   C. HF and NaF
   D. KNO3 and NaNO3
   E. HCl and NaCl

22. For HA/A⁻ with pKa=5 and equal concentrations, pH is approximately:
   A. 0
   B. 10
   C. 7
   D. 14
   E. 5

23. For pKa=4 and [A⁻]/[HA]=10, pH is approximately:
   A. 3
   B. 4
   C. 0.4
   D. 10
   E. 5

24. In an HA/A⁻ buffer, which component mainly consumes added OH⁻?
   A. A⁻
   B. HA
   C. Na⁺ spectator
   D. Cl⁻ spectator
   E. Both are consumed equally

25. Two buffers have identical pH and acid/base ratio but different total concentration. Which generally has greater capacity?
   A. Neither can resist any acid
   B. The more dilute buffer
   C. Both must have zero capacity
   D. The more concentrated buffer
   E. Capacity depends only on pH, not amount

26. Assuming complete dissociation and ideal dilute behaviour, what is the pH of 1.0 x 10^-3 mol/L HCl at 25 C?
   A. 11
   B. 13
   C. 2
   D. 3
   E. 1

27. In the Bronsted-Lowry model, a base is a species that:
   A. always has pH exactly 7
   B. accepts a proton
   C. must contain a metal
   D. cannot carry a charge
   E. donates a proton

28. Which mixture forms a conventional buffer solution?
   A. NaOH and KOH
   B. CH3COOH and CH3COONa
   C. NaCl and water
   D. Glucose and water
   E. HCl and NaCl

29. Why is an aqueous sodium acetate solution typically basic?
   A. Acetate removes every water molecule
   B. Sodium metal is present in the solution
   C. Acetate reacts with water to produce some OH-
   D. All dissolved salts have pH above 7
   E. Sodium ions release protons as a strong acid

30. Which mixture can act as an acid-base buffer when both components are present in appreciable amounts?
   A. Sodium hydroxide and potassium hydroxide only
   B. Hydrochloric acid and sodium chloride only
   C. Pure water and sand
   D. Acetic acid and sodium acetate
   E. Glucose and ethanol only

31. At 25°C, what is the pH of ideal 0.001 M NaOH?
   A. 3
   B. 7
   C. 10
   D. 11
   E. 13
