## Mock 1 — 5 questions / 10 minutes

1. What is the SI unit of momentum in base units?
   A. kg s⁻¹
   B. kg m s⁻²
   C. kg m s⁻¹
   D. kg m² s⁻²
   E. m s⁻¹

2. A particle starts at rest with constant acceleration 3 m/s². How far in 6 s?
   A. 54 m
   B. 108 m
   C. 9 m
   D. 18 m
   E. 36 m

3. A 2 kg body falls 4 m from rest without drag. Use g=10. Its final kinetic energy?
   A. 80 J
   B. 40 J
   C. 8 J
   D. 20 J
   E. 160 J

4. How much higher is the pressure 5 m deeper in fresh water? Use ρ=1000 kg/m³, g=10.
   A. 0.5 kPa
   B. 100 kPa
   C. 5 kPa
   D. 500 kPa
   E. 50 kPa

5. A 15 Ω ohmic resistor has 30 V across it. Current?
   A. 45 A
   B. 15 A
   C. 450 A
   D. 0.5 A
   E. 2 A

## Mock 2 — 5 questions / 10 minutes

1. Two perpendicular forces have magnitudes 5 N and 12 N. Resultant magnitude?
   A. 17 N
   B. 13 N
   C. 60 N
   D. 11 N
   E. 7 N

2. A particle moves in a circle of radius 4 m at speed 6 m/s. Centripetal acceleration?
   A. 24 m/s²
   B. 9 m/s²
   C. 4 m/s²
   D. 36 m/s²
   E. 1.5 m/s²

3. A net horizontal force of 18 N acts on a 4 kg body. Acceleration?
   A. 14 m/s²
   B. 22 m/s²
   C. 0.222 m/s²
   D. 72 m/s²
   E. 4.5 m/s²

4. A system absorbs 400 J of heat and performs 150 J of work. Change in internal energy?
   A. −550 J
   B. +150 J
   C. +550 J
   D. −250 J
   E. +250 J

5. A sound wave has wavelength 0.5 m and speed 340 m/s. Frequency?
   A. 680 Hz
   B. 85 Hz
   C. 170 Hz
   D. 340 Hz
   E. 0.00147 Hz

## Mock 3 — 5 questions / 10 minutes

1. Convert 0.08 mm to metres.
   A. 8×10⁻³ m
   B. 8×10⁻⁴ m
   C. 8×10⁻² m
   D. 8×10⁻⁶ m
   E. 8×10⁻⁵ m

2. A constant velocity of −5 m/s lasts 4 s. Displacement?
   A. −1.25 m
   B. −9 m
   C. 0 m
   D. 20 m
   E. −20 m

3. A 6 N force acts perpendicular to a 10 m displacement. Work done by that force?
   A. 0 J
   B. 6 J
   C. 60 J
   D. 10 J
   E. −60 J

4. An immersed object displaces 0.004 m³ of water of density 1000 kg/m³. Use g=10. Buoyant force?
   A. 40 N
   B. 100 N
   C. 0.04 N
   D. 400 N
   E. 4 N

5. For two fixed point charges in vacuum, their separation doubles. Force magnitude becomes:
   A. One half
   B. Four times
   C. Twice
   D. One quarter
   E. Unchanged

## Mock 4 — 5 questions / 10 minutes

1. A signal follows y=2ˣ. Increasing x by 3 multiplies y by:
   A. 8
   B. 9
   C. 3
   D. 6
   E. 2

2. A train moves west at 15 m/s and a passenger walks east at 2 m/s relative to it. Ground-frame passenger velocity?
   A. 15 m/s west
   B. 13 m/s west
   C. 17 m/s west
   D. 13 m/s east
   E. 2 m/s west

3. A hoist performs 900 J of mechanical work in 15 s. Average power?
   A. 0.0167 W
   B. 13500 W
   C. 900 W
   D. 60 W
   E. 15 W

4. An ideal gas at 200 kPa and 3 L expands isothermally to 5 L. Final pressure?
   A. 600 kPa
   B. 333 kPa
   C. 80 kPa
   D. 120 kPa
   E. 200 kPa

5. The field at a point is 80 N/C east. A positive test charge of 0.05 C is placed there. Force?
   A. 80 N east
   B. 4 N west
   C. Zero
   D. 4 N east
   E. 1600 N east

## Mock 5 — 5 questions / 10 minutes

1. For A=(1,2,0) and B=(2,−1,0), what is their dot product?
   A. 0
   B. 4
   C. −4
   D. 1
   E. 5

2. A stone is dropped from rest. Neglect air resistance and use g=10. Speed after 3 s?
   A. 45 m/s
   B. 30 m/s
   C. 15 m/s
   D. 90 m/s
   E. 3 m/s

3. A 2 kg body speeds up from 2 m/s to 6 m/s. Net work?
   A. 16 J
   B. 36 J
   C. 8 J
   D. 64 J
   E. 32 J

4. In a steady incompressible flow, cross-sectional area triples. What happens to mean speed?
   A. It becomes one ninth
   B. It becomes one third
   C. It increases ninefold
   D. It triples
   E. It remains constant

5. What happens when an ordinary bar magnet is cut in half?
   A. One piece has only north, the other only south
   B. Both pieces lose magnetism necessarily
   C. Both pieces become single north poles
   D. Only the larger piece remains magnetic
   E. Each piece has a north and a south pole