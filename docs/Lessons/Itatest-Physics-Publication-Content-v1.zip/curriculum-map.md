# Physics — CISIA curriculum alignment

Source: [CISIA CEnT-S structure and syllabus](https://cisiaonline.it/en/cent/cent-s/structure-and-syllabus), checked 2026-11-24. The published Physics section has five questions in ten minutes. This course retains six teaching chapters because fluid mechanics and thermodynamics are separated for learning; together they constitute one official nucleus. The following mapping is an editorial coverage map, not an independent certification of depth or accuracy.

| Official domain (paraphrased) | Required skills/topics (paraphrased) | Canonical lessons |
|---|---|---|
| Quantities and measurement | SI base and derived units; practical conversions; scientific notation and magnitude | 1.1–1.5 |
| Quantities and measurement | Recognise proportional, linear, quadratic, inverse-square, periodic, exponential and logarithmic models | 1.6 |
| Quantities and measurement | Vector components, addition, subtraction and both products in three dimensions | 1.4, 1.7 |
| Particle kinematics | Position, trajectory, distance, displacement, time, velocity, acceleration | 2.1–2.6 |
| Particle kinematics | Uniform and constant-acceleration motion, position/velocity/acceleration graphs | 2.3, 2.7–2.10 |
| Particle kinematics | Free fall | 2.11 |
| Particle kinematics | Circular motion: period, frequency, angular speed, tangential speed and acceleration | 2.12 |
| Particle kinematics | Galilean transformations between inertial frames | 2.13 |
| Dynamics, energy and work | Inertia, force, mass, Newton's laws, normal force, gravity, string tension | 3.8, 3.10–3.11, 3.13 |
| Dynamics, energy and work | Work, power, kinetic energy, work-energy relation | 3.1–3.5 |
| Dynamics, energy and work | Gravitational potential energy and conservation of mechanical energy | 3.5–3.6 |
| Fluids and thermodynamics | Density, pressure, atmosphere, hydrostatic pressure, Pascal and buoyancy | 4.2–4.13 |
| Fluids and thermodynamics | Volume flow rate, continuity, Bernoulli | 4.14 |
| Fluids and thermodynamics | Gas state, temperature scales, ideal gas equation and non-SI units | 4.6, 5.1, 5.10 |
| Fluids and thermodynamics | Heat transfer, work, first law and qualitative second law | 5.2–5.10 |
| Electromagnetism principles | Coulomb interaction, field of charges and uniform fields | 6.1–6.3 |
| Electromagnetism principles | Conductors, insulators, current, resistance and Ohm's law | 6.1, 6.3–6.5 |
| Electromagnetism principles | Permanent magnets, magnetic interaction and field lines | 6.6 |
| Electromagnetism principles | Light and sound, amplitude, frequency, period, wavelength, speed | 6.7 |
| Electromagnetism principles | Electromagnetic spectrum | 6.8 |

Additional supporting topics retained from the source: measurement uncertainty, friction, momentum, spring force, heat engines, refrigerators, circuit combinations and elementary magnetic-force calculations. These are not represented as separate mandatory syllabus nuclei. Difficulty labels are not empirically calibrated.
