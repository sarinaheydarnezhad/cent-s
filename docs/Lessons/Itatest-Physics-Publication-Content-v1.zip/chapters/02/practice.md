# Questions

1. An object moves from x₁ = 3 m to x₂ = −4 m. What is its displacement?
   A. −1 m
   B. 7 m
   C. 4 m
   D. −7 m
   E. 1 m

2. A particle moves on a circle of radius 8 m with period 4 s. Centripetal acceleration?
   A. 4π² m/s²
   B. 2π² m/s²
   C. π²/2 m/s²
   D. 8π² m/s²
   E. π² m/s²

3. Uniform motion starts at x₀=3 m with velocity 4 m/s. Find x after 5 s in metres.
   A. 23
   B. 2.3
   C. 11.5
   D. 230
   E. 46

4. Uniform circular motion has speed 4 m/s and radius 2 m. Find centripetal acceleration in m/s².
   A. 80
   B. 4
   C. 8
   D. 16
   E. 0.8

5. Uniform motion starts at x₀=3 m with velocity 3 m/s. Find x after 5 s in metres.
   A. 1.8
   B. 9
   C. 36
   D. 18
   E. 180

6. A velocity–time graph is horizontal at 2 m/s from t=0 to t=6 s. Find the displacement in metres.
   A. 120
   B. 24
   C. 1.2
   D. 6
   E. 12

7. Car A (25 m/s) is 150 m behind car B (15 m/s), same direction. Time to catch up?
   A. 6 s
   B. 20 s
   C. 10 s
   D. 15 s
   E. 12 s

8. Two vehicles move in the same direction at 12 and 6 m/s. Find the faster vehicle's speed relative to the slower in m/s.
   A. 6
   B. 7
   C. 8
   D. 5
   E. 18

9. Acceleration is constant at 4 m/s² for 4 s. What is the change in velocity in m/s?
   A. 8
   B. 16
   C. 1.6
   D. 32
   E. 160

10. Uniform motion starts at x₀=3 m with velocity 2 m/s. Find x after 5 s in metres.
   A. 1.3
   B. 130
   C. 26
   D. 13
   E. 6.5

11. An object starts from rest and accelerates at 2 m/s² for 4 s. Find distance in metres.
   A. 16
   B. 32
   C. 8
   D. 1.6
   E. 160

12. A ball dropped from rest takes 2 s to land (g = 10). Height?
   A. 20 m
   B. 30 m
   C. 40 m
   D. 10 m
   E. 5 m

13. A runner completes a 200 m trip in 20 s. Find average speed in m/s.
   A. 10
   B. 100
   C. 2
   D. 0.1
   E. 1

14. Acceleration is constant at 2 m/s² for 4 s. What is the change in velocity in m/s?
   A. 8
   B. 16
   C. 0.8
   D. 80
   E. 4

15. An object is at x=−2 m and has velocity +3 m/s. Which statement is correct?
   A. It must be moving away from the origin
   B. It is left of the origin and moving in the positive direction
   C. Its speed is negative
   D. It is right of the origin and moving in the negative direction
   E. It is moving in the negative direction

16. An object goes from x=3 m to x=10 m, then returns to x=5 m. Find the total displacement in metres.
   A. 7
   B. 12
   C. −2
   D. 2
   E. 5

17. A velocity–time graph is horizontal at 4 m/s from t=0 to t=6 s. Find the displacement in metres.
   A. 2.4
   B. 24
   C. 12
   D. 48
   E. 240

18. Acceleration is constant at 3 m/s² for 4 s. What is the change in velocity in m/s?
   A. 24
   B. 1.2
   C. 6
   D. 120
   E. 12

19. In one-dimensional motion, nonzero velocity and acceleration have opposite signs. What is happening to the speed at that instant?
   A. necessarily reversing direction at that instant
   B. moving uniformly
   C. speeding up
   D. slowing down
   E. at rest

20. Which quantity is invariant under a Galilean transformation between inertial frames?
   A. Time interval
   B. Kinetic energy
   C. Speed of light
   D. Velocity
   E. Position

21. A ball is thrown vertically upward near Earth, neglecting drag. At its highest point:
   A. v = 0 and a = 0
   B. v is upward and a = 9.8 m/s² downward
   C. v is maximum and a = 0
   D. v is downward and a = 0
   E. v = 0 and a = 9.8 m/s² downward

22. x = t² + 2t + 3 (SI). How many direction changes for t ≥ 0?
   A. 3
   B. 4
   C. 0
   D. 1
   E. 2

23. A car accelerates from rest to 20 m/s in 4 s. What is its acceleration?
   A. 5 m/s²
   B. 80 m/s²
   C. 0.2 m/s²
   D. 8 m/s²
   E. 4 m/s²

24. A position–time graph is the line x=4t+4 (SI). What is the velocity in m/s?
   A. 4
   B. 0
   C. 5
   D. 16
   E. 8

25. A car moves in a straight line with constant acceleration from 10 m/s to 25 m/s over 175 m. Find its acceleration.
   A. 2 m/s²
   B. 1 m/s²
   C. 2.5 m/s²
   D. 3 m/s²
   E. 1.5 m/s²

26. x = t² − 4t + 5 (SI). How many direction changes for t ≥ 0?
   A. 2
   B. 3
   C. 0
   D. 1
   E. 4

27. An object is at x=−3 m and has velocity +3 m/s. Which statement is correct?
   A. It is moving in the negative direction
   B. It must be moving away from the origin
   C. Its speed is negative
   D. It is right of the origin and moving in the negative direction
   E. It is left of the origin and moving in the positive direction

28. Velocity increases from 2 to 14 m/s in 3 s. Find average acceleration in m/s².
   A. 14/3
   B. 36
   C. 4
   D. 2
   E. 12

29. A velocity–time graph is horizontal at 3 m/s from t=0 to t=6 s. Find the displacement in metres.
   A. 36
   B. 9
   C. 1.8
   D. 180
   E. 18

30. A particle is at x = −3 m at t = 0, x = 9 m at t = 4 s (extra info), and x = 15 m at t = 6 s. Magnitude of the average velocity over the 6 s?
   A. 3 m/s
   B. 4 m/s
   C. 6 m/s
   D. 2 m/s
   E. 1 m/s

31. A cyclist travels a total distance of 180 m in 12 s. Its average speed is:
   A. 18 m/s
   B. 20 m/s
   C. 2160 m/s
   D. 12 m/s
   E. 15 m/s

32. An object goes from x=2 m to x=9 m, then returns to x=4 m. Find the total displacement in metres.
   A. −2
   B. 2
   C. 7
   D. 5
   E. 12

33. An object is at x=−4 m and has velocity +3 m/s. Which statement is correct?
   A. It is right of the origin and moving in the negative direction
   B. It is moving in the negative direction
   C. Its speed is negative
   D. It must be moving away from the origin
   E. It is left of the origin and moving in the positive direction

34. A car accelerates from rest at 2 m/s² for 5 s, moves at constant speed for 10 s, then brakes at 5 m/s² to stop. Total distance?
   A. 140 m
   B. 125 m
   C. 135 m
   D. 130 m
   E. 150 m

35. A position–time graph is the line x=3t+4 (SI). What is the velocity in m/s?
   A. 12
   B. 0
   C. 7
   D. 3
   E. 4

36. A ball is dropped from rest for 2 s. Neglect air resistance and use g=10 m/s². Find its downward speed in m/s.
   A. 2
   B. 20
   C. 200
   D. 40
   E. 10

37. A position–time graph is the line x=2t+4 (SI). What is the velocity in m/s?
   A. 0
   B. 4
   C. 6
   D. 2
   E. 8

38. Uniform circular motion has speed 6 m/s and radius 3 m. Find centripetal acceleration in m/s².
   A. 6
   B. 120
   C. 12
   D. 1.2
   E. 24

39. A one-dimensional particle has v=(t−5)² in SI for t≥0. Which statement is correct?
   A. Average acceleration from 4 s to 5 s is 5 m/s²
   B. It never reverses direction; it is momentarily at rest at t=5 s
   C. Direction changes once at t = 5 s
   D. Speed at t = 3 s differs from t = 7 s
   E. The acceleration is zero at every instant

40. Starting from rest, an object has constant acceleration 2.0 m/s^2 for 3.0 s. What is its displacement?
   A. 3.0 m
   B. 12.0 m
   C. 6.0 m
   D. 9.0 m
   E. 18.0 m

41. In uniform circular motion, the acceleration is directed:
   A. opposite to gravity in every case
   B. along the velocity
   C. nowhere because it is zero
   D. away from the centre
   E. towards the centre

42. A passenger walks at +2 m/s relative to a train moving at +10 m/s relative to the ground. What is the passenger velocity relative to the ground?
   A. -8 m/s
   B. +12 m/s
   C. +8 m/s
   D. +20 m/s
   E. +5 m/s

43. An object moves at +3 m/s for 2 s, then at -3 m/s for 2 s. What is its total displacement?
   A. 0 m
   B. -12 m
   C. 12 m
   D. 6 m
   E. 3 m

44. Velocity is +4 m/s for 3 s and −2 m/s for 5 s. Find the displacement.
   A. +2 m
   B. −10 m
   C. +12 m
   D. 22 m
   E. −2 m

45. A velocity–time graph is tangent to v=0 at t=4 s and positive on both sides. What happens?
   A. Acceleration must be constant
   B. It reverses at t=4 s
   C. The object stops momentarily without reversing
   D. Position is zero at t=4 s
   E. Distance travelled becomes zero

46. A wheel rotates at 120 revolutions per minute. What is its angular speed?
   A. 4π rad/s
   B. 240π rad/s
   C. 2π rad/s
   D. 120π rad/s
   E. π rad/s

47. A boat travels east at 4 m/s relative to water moving north at 3 m/s. Its speed relative to shore is:
   A. 5 m/s
   B. 25 m/s
   C. 7 m/s
   D. 1 m/s
   E. 12 m/s

48. A car travels with constant acceleration from 6 to 14 m/s in 4 s. Displacement?
   A. 40 m
   B. 24 m
   C. 80 m
   D. 32 m
   E. 56 m

49. A ball is thrown vertically upward at 20 m/s. Ignoring drag and using g=10 m/s², time until it returns to its starting height?
   A. 8 s
   B. 2 s
   C. 20 s
   D. 1 s
   E. 4 s