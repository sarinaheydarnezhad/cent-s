# Questions

1. A 10 Ω resistor carries 2 A. Power dissipated?
   A. 200 W
   B. 4 W
   C. 40 W
   D. 20 W
   E. 5 W

2. A 0.5 m wire carries 2 A perpendicular to a 2 T field. Find the magnetic force in newtons.
   A. 0.5
   B. 3
   C. 1
   D. 4
   E. 2

3. 30 C of charge passes through a wire in 10 s. The current is:
   A. 3 A
   B. 300 A
   C. 30 A
   D. 0.3 A
   E. 1/3 A

4. A positive test charge of 2 C feels a 30 N force. Find the electric field magnitude in N/C.
   A. 1.5
   B. 15
   C. 150
   D. 30
   E. 7.5

5. A charge of 24 C passes a cross-section in 4 s. Find current in amperes.
   A. 8
   B. 6
   C. 5
   D. 96
   E. 7

6. Which radiation has the highest photon energy?
   A. Gamma rays
   B. Infrared
   C. Visible red light
   D. Ultraviolet
   E. Radio waves

7. An echo is heard 1.5 s after shouting at a cliff (v = 340 m/s). Distance to cliff?
   A. 340 m
   B. 255 m
   C. 510 m
   D. 170 m
   E. 127.5 m

8. The field at 3 m from a 2 μC point charge is:
   A. 200 N/C
   B. 6000 N/C
   C. 18000 N/C
   D. 2 N/C
   E. 2000 N/C

9. Charges +2 μC and −2 μC are 0.6 m apart. Field magnitude at the midpoint?
   A. 1×10⁵ N/C
   B. 0
   C. 8×10⁵ N/C
   D. 2×10⁵ N/C
   E. 4×10⁵ N/C

10. An initially neutral isolated conductor loses 3 electrons. Its net charge is:
   A. Still exactly zero
   B. Magnetic but not electric
   C. Has an excess of electrons
   D. Negative
   E. Positive

11. A charge of 36 C passes a cross-section in 4 s. Find current in amperes.
   A. 0.9
   B. 9
   C. 18
   D. 4.5
   E. 90

12. A 12 V source connects to a 2 Ω resistor in series with a parallel combo of 6 Ω and 3 Ω. Voltage across the parallel part?
   A. 2 V
   B. 4 V
   C. 8 V
   D. 12 V
   E. 6 V

13. Compare photons with frequencies f and 2f. The photon with the higher frequency has:
   A. Zero energy
   B. 1/2 the energy
   C. The same energy
   D. 2 times the energy
   E. 4 times the energy

14. Compare photons with frequencies f and 3f. The photon with the higher frequency has:
   A. 9 times the energy
   B. The same energy
   C. 3 times the energy
   D. Zero energy
   E. 1/3 the energy

15. A positive test charge of 2 C feels a 20 N force. Find the electric field magnitude in N/C.
   A. 20
   B. 1
   C. 100
   D. 5
   E. 10

16. If the distance between two charges triples, the force becomes:
   A. 1/9 of original
   B. 9 times
   C. 1/3 of original
   D. 1/27 of original
   E. 3 times

17. Two 1 μC charges are 0.3 m apart. Find the force.
   A. 1 N
   B. 10 N
   C. 0.001 N
   D. 0.1 N
   E. 0.01 N

18. Light of wavelength 600 nm in vacuum has frequency:
   A. 1.8×10¹⁵ Hz
   B. 5×10¹² Hz
   C. 5×10¹⁴ Hz
   D. 5×10¹⁵ Hz
   E. 5×10¹³ Hz

19. A 0.5 m wire carries 4 A perpendicular to a 0.5 T field. Force?
   A. 0.25 N
   B. 1 N
   C. 2 N
   D. 0.5 N
   E. 4 N

20. 12 Ω and 4 Ω resistors in parallel. Equivalent resistance?
   A. 3 Ω
   B. 8 Ω
   C. 6 Ω
   D. 48 Ω
   E. 16 Ω

21. A wave has f = 200 Hz, λ = 1.7 m. Speed?
   A. 340 m/s
   B. 3400 m/s
   C. 118 m/s
   D. 0.0085 m/s
   E. 200 m/s

22. An initially neutral isolated conductor loses 2 electrons. Its net charge is:
   A. Still exactly zero
   B. Positive
   C. Magnetic but not electric
   D. Negative
   E. Has an excess of electrons

23. A 0.5 m wire carries 3 A perpendicular to a 2 T field. Find the magnetic force in newtons.
   A. 0.75
   B. 5
   C. 3
   D. 4
   E. 2

24. Two stationary positive point charges are brought near each other. They exert forces that:
   A. attract
   B. neutralize
   C. repel
   D. have no force
   E. alternate between attraction and repulsion while at rest

25. A wave has frequency 50 Hz and wavelength 2.0 m. What is its propagation speed?
   A. 52 m/s
   B. 100 m/s
   C. 25 m/s
   D. 48 m/s
   E. 2500 m/s

26. A 4.0 ohm ohmic resistor has 12 V across it. What current flows through it?
   A. 16 A
   B. 8.0 A
   C. 48 A
   D. 0.33 A
   E. 3.0 A

27. What is the electric field inside the material of an ideal conductor in electrostatic equilibrium?
   A. Zero
   B. Infinite
   C. Equal to current divided by mass
   D. Necessarily equal to the external field
   E. Always directed north

28. A charge −2 μC is placed in a uniform field of 300 N/C pointing east. Force?
   A. 6×10⁻⁴ N west
   B. 150 N east
   C. 6×10⁻⁴ N east
   D. Zero
   E. 600 N west

29. Two equal positive charges are fixed symmetrically about a midpoint. Electric field at the midpoint?
   A. Directed toward the left charge
   B. Directed toward the right charge
   C. Infinite
   D. Twice either individual field magnitude
   E. Zero

30. An ohmic resistor at fixed temperature has voltage doubled. Current becomes:
   A. Four times as large
   B. Twice as large
   C. Unchanged
   D. Half as large
   E. Zero

31. Outside an ordinary bar magnet, the magnetic field lines are conventionally drawn:
   A. With no direction
   B. From north to south
   C. From south to north
   D. Only toward north
   E. As straight radial lines from each pole

32. A wave has a period of 0.02 s and wavelength 0.8 m. Speed?
   A. 62.5 m/s
   B. 16 m/s
   C. 40 m/s
   D. 0.016 m/s
   E. 50 m/s

33. Which is the correct increasing-frequency order?
   A. Radio, ultraviolet, infrared, visible, X-rays
   B. Infrared, radio, visible, X-rays, ultraviolet
   C. Radio, infrared, visible, ultraviolet, X-rays
   D. X-rays, visible, infrared, radio, ultraviolet
   E. Visible, infrared, radio, ultraviolet, X-rays