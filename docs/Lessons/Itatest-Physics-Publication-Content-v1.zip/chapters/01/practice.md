# Questions

1. A ruler's smallest division is 0.3 cm. What is its resolution in millimetres?
   A. 4
   B. 6
   C. 5
   D. 2
   E. 3

2. Evaluate (2×10³)×(2×10^-2).
   A. 40
   B. 4
   C. 20
   D. 80
   E. 400

3. A ruler's smallest division is 0.2 cm. What is its resolution in millimetres?
   A. 2
   B. 1
   C. 3
   D. 20
   E. 4

4. A ruler is read directly to the nearest 1 mm without interpolation. Which reading matches this resolution?
   A. 12.34 cm
   B. 12.33 cm
   C. 12.3 cm
   D. 12.345 cm
   E. 12.3456 cm

5. The SI base unit for electric current is:
   A. Volt
   B. Ampere
   C. Watt
   D. Ohm
   E. Coulomb

6. A balance always reads 3 g too high. Which change directly corrects this error?
   A. Change grams into kilograms only
   B. Take more readings without calibration
   C. Round every reading to an integer
   D. Calibrate or zero the balance
   E. Subtract 3 g from the reference mass before weighing

7. Which pair contains one scalar and one vector quantity?
   A. Force and Momentum
   B. Distance and Speed
   C. Velocity and Acceleration
   D. Speed and Momentum
   E. Time and Temperature

8. A cyclist rides at 6 km/h. What is this in m/s?
   A. 1.67 m/s
   B. 21.6 m/s
   C. 2.16 m/s
   D. 0.60 m/s
   E. 1.2 m/s

9. Convert 64 mg to grams.
   A. 6.4 × 10⁻⁵ g
   B. 6.4 × 10⁻³ g
   C. 6.4 × 10⁻² g
   D. 6.4 × 10² g
   E. 6.4 × 10¹ g

10. What are the dimensions of speed v=s/t?
   A. L T
   B. M L^-1
   C. M T^-1
   D. L T²
   E. L T^-1

11. A balance always reads 2 g too high. Which change directly corrects this error?
   A. Take more readings without calibration
   B. Round every reading to an integer
   C. Calibrate or zero the balance
   D. Increase every measured value by 2 g
   E. Change grams into kilograms only

12. The pascal in SI base units is:
   A. kg m² s⁻²
   B. kg m⁻¹ s⁻²
   C. kg m s⁻²
   D. kg m⁻² s⁻²
   E. kg m⁻¹ s⁻¹

13. Which of these quantities requires a direction as well as magnitude?
   A. Temperature
   B. Kinetic energy
   C. Mass
   D. Elapsed time
   E. Velocity

14. Perpendicular vectors have magnitudes 6 and 8. Find the magnitude of their sum.
   A. 20
   B. 10
   C. 100
   D. 1
   E. 5

15. A model has y=k/x². If x becomes 2 times as large, by what factor does y change?
   A. 2
   B. 4
   C. 0.125
   D. 0.25
   E. 0.5

16. A mass measurement is reported as '9 kilograms'. What are the two essential parts of the measurement?
   A. A number with no unit
   B. Only a direction
   C. A numerical value and a unit
   D. A unit and a direction, without a value
   E. Only a measuring instrument

17. Which graph represents inverse proportionality?
   A. Exponential growth curve
   B. Sinusoidal wave
   C. Parabola
   D. Straight line through origin
   E. Hyperbola

18. Which is a systematic error?
   A. Random temperature fluctuations
   B. Electrical noise in a meter
   C. Variable reaction time with a stopwatch
   D. A balance that always reads 5 g too high
   E. Small unpredictable variations around the true value

19. A time measurement is reported as '12 seconds'. What are the two essential parts of the measurement?
   A. A numerical value and a unit
   B. Only a direction
   C. A clock reading without a unit
   D. A number with no unit
   E. Only a measuring instrument

20. What are the dimensions of force F=ma?
   A. M L T^-2
   B. M L^-1
   C. L T
   D. M L² T⁻²
   E. M T^-1

21. Which of the following is a vector quantity?
   A. Mass
   B. Time
   C. Displacement
   D. Temperature
   E. Speed

22. The horizontal component of a 20 N force at 30° to the horizontal is:
   A. 20 N
   B. 34.64 N
   C. 10 N
   D. 11.55 N
   E. 17.32 N

23. The number of seconds in one day is approximately:
   A. 8.64 × 10³
   B. 8.64 × 10⁴
   C. 1.44 × 10³
   D. 3.6 × 10⁵
   E. 3.6 × 10⁴

24. What are the dimensions of energy E=mv²/2?
   A. M L T⁻²
   B. M L^-1
   C. M L² T^-2
   D. M T^-1
   E. L T

25. Two forces of 8 N (East) and 6 N (North) act on a body. The magnitude of the resultant is:
   A. 10 N
   B. 48 N
   C. 7 N
   D. 2 N
   E. 14 N

26. A length measurement is reported as '6 metres'. What are the two essential parts of the measurement?
   A. A number with no unit
   B. Only a direction
   C. Only a measuring instrument
   D. A numerical value and a unit
   E. A direction and an instrument only

27. A model has y=k/x². If x becomes 3 times as large, by what factor does y change?
   A. 0.037037
   B. 0.111111
   C. 9
   D. 0.333333
   E. 3

28. For unit vectors i=(1,0,0) and j=(0,1,0), what is i x j in a right-handed coordinate system?
   A. (0,0,1)
   B. 1
   C. (0,0,-1)
   D. (0,0,0)
   E. (1,1,0)

29. What is 3.0 cm^2 expressed in m^2?
   A. 0.03
   B. 0.003
   C. 0.3
   D. 0.0003
   E. 300

30. For A=(2,−1,3) and B=(1,4,−2), what is A·B?
   A. 8
   B. −8
   C. 0
   D. −4
   E. 12

31. In a right-handed Cartesian system, what is (0,2,0) × (0,0,3)?
   A. (6,0,0)
   B. (0,0,0)
   C. (0,6,0)
   D. (0,0,6)
   E. (−6,0,0)

32. What is A−B for A=(3,−2,1) and B=(−1,4,2)?
   A. (2,−6,3)
   B. (4,−6,−1)
   C. (4,2,−1)
   D. (2,2,3)
   E. (−4,6,1)

33. A quantity y=3+2x is measured for x≥0. Which statement is correct?
   A. It is inversely proportional to x
   B. It is quadratic in x
   C. It is linear but not directly proportional to x
   D. It is directly proportional to x
   E. It has exponential growth

34. If y=log₁₀(x), increasing x from 10 to 1000 changes y by:
   A. +100
   B. +3
   C. +2
   D. −2
   E. +10

35. Convert 2.5 cm³ to m³.
   A. 2.5×10⁶ m³
   B. 2.5×10⁻⁶ m³
   C. 2.5×10⁻² m³
   D. 2.5×10⁻⁹ m³
   E. 2.5×10⁻⁴ m³