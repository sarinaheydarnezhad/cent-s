# Questions

1. An ideal barometer's fluid density doubles while the atmospheric pressure stays fixed. If its original height was 60 cm, what is its new height in cm?
   A. 15
   B. 3
   C. 300
   D. 30
   E. 60

2. Points at the same depth in the same connected static liquid have:
   A. zero pressure
   B. equal pressure
   C. different pressure depending on shape
   D. pressure proportional to the cross-sectional area
   E. pressure depending on container volume

3. A hydraulic press has output piston area 2 times the input area. An input force of 50 N gives what ideal output force in newtons?
   A. 100
   B. 10
   C. 200
   D. 1000
   E. 50

4. A hydraulic press: small piston 8 cm², large 320 cm², force 50 N on small piston. Force on large piston?
   A. 1000 N
   B. 1600 N
   C. 2000 N
   D. 12.5 N
   E. 500 N

5. Absolute pressure is 120 kPa and local atmospheric pressure is 100 kPa. Find gauge pressure in kPa.
   A. 40
   B. 20
   C. 2
   D. 200
   E. 10

6. A small hole is 0.8 m below the surface of a large open water tank. Assume ideal flow, negligible surface speed and g=10 m/s². Exit speed?
   A. 0.4 m/s
   B. 16 m/s
   C. 8 m/s
   D. 2 m/s
   E. 4 m/s

7. Absolute pressure is 130 kPa and local atmospheric pressure is 100 kPa. Find gauge pressure in kPa.
   A. 15
   B. 60
   C. 30
   D. 3
   E. 300

8. An ideal barometer's fluid density doubles while the atmospheric pressure stays fixed. If its original height was 40 cm, what is its new height in cm?
   A. 40
   B. 10
   C. 2
   D. 200
   E. 20

9. Find the gauge pressure at depth 0.3 m in water of density 1000 kg/m³, using g=10 m/s².
   A. 3000
   B. 30000
   C. 1500
   D. 6000
   E. 300

10. Find the gauge pressure at depth 0.2 m in water of density 1000 kg/m³, using g=10 m/s².
   A. 1000
   B. 2000
   C. 4000
   D. 200
   E. 20000

11. A sample has mass 3 kg and volume 0.002 m³. Find its density in kg/m³.
   A. 15000
   B. 3000
   C. 150
   D. 1500
   E. 750

12. A gas manometer: mercury on the gas side is 6 cm higher than the open side; atmosphere = 76 cmHg. Gas pressure?
   A. 70 cmHg
   B. 82 cmHg
   C. 76 cmHg
   D. 6 cmHg
   E. 88 cmHg

13. A mercury column has height 4 cm. Use ρHg=13600 kg/m³ and g=10 m/s². What pressure does it represent in pascals?
   A. 5440
   B. 54400
   C. 544
   D. 10880
   E. 2720

14. A measurement is taken 1000 m higher in the atmosphere. All else being typical, atmospheric pressure:
   A. Becomes negative
   B. Doubles at every kilometre
   C. Is exactly unchanged
   D. Increases in direct proportion to altitude
   E. Decreases

15. Water narrows from 20 cm to 5 cm diameter. If speed in the narrow part is 32 m/s, the speed in the wide part is:
   A. 2 m/s
   B. 0.5 m/s
   C. 1 m/s
   D. 8 m/s
   E. 4 m/s

16. An object displaces 0.003 m³ of water. Find the buoyant force in newtons, using ρ=1000 kg/m³ and g=10 m/s².
   A. 30
   B. 60
   C. 300
   D. 15
   E. 3

17. An open water manometer has a 2 cm level difference. Find the pressure difference in pascals with ρ=1000 kg/m³ and g=10 m/s².
   A. 400
   B. 100
   C. 20
   D. 2000
   E. 200

18. A 3 kg object rests on a horizontal base of area 0.02 m². Find its pressure on the base, using g=10 m/s².
   A. 3000
   B. 750
   C. 15000
   D. 1500
   E. 150

19. An incompressible steady flow has inlet area 2 times its outlet area. If inlet speed is 2 m/s, find outlet speed in m/s.
   A. 3
   B. 6
   C. 4
   D. 1
   E. 5

20. A measurement is taken 1500 m higher in the atmosphere. All else being typical, atmospheric pressure:
   A. Is exactly unchanged
   B. Becomes negative
   C. Increases in direct proportion to altitude
   D. Decreases
   E. Doubles at every kilometre

21. A mercury column has height 2 cm. Use ρHg=13600 kg/m³ and g=10 m/s². What pressure does it represent in pascals?
   A. 27200
   B. 1360
   C. 2720
   D. 272
   E. 5440

22. A liquid creates 3000 Pa of pressure above the pressure outside a flat base of area 0.02 m². Find the net pressure force in newtons.
   A. 6
   B. 30
   C. 120
   D. 60
   E. 600

23. Which description best matches an ordinary solid under normal conditions?
   A. Always zero density
   B. Fixed shape and fixed volume
   C. No particles and no mass
   D. Fills the whole container at any pressure
   E. Shape and volume both independent of state

24. A perpendicular force of 120 N acts on 0.2 m². Find pressure in pascals.
   A. 6000
   B. 1200
   C. 60
   D. 600
   E. 300

25. Two points in the atmosphere differ in altitude by 1500 m (average air density 1.1 kg/m³, g = 10). Pressure difference?
   A. 11 kPa
   B. 33 kPa
   C. 1.65 kPa
   D. 16.5 kPa
   E. 22 kPa

26. An open water manometer has a 3 cm level difference. Find the pressure difference in pascals with ρ=1000 kg/m³ and g=10 m/s².
   A. 30
   B. 150
   C. 600
   D. 300
   E. 3000

27. A 1.2 kg object has a volume of 5×10⁻⁴ m³. Its density is:
   A. 600 kg/m³
   B. 6000 kg/m³
   C. 240 kg/m³
   D. 0.0006 kg/m³
   E. 2400 kg/m³

28. A mercury barometer reads 70 cm. As a fraction of standard 76 cmHg, this is:
   A. 0.87 atm
   B. 0.95 atm
   C. 1.09 atm
   D. 1.0 atm
   E. 0.92 atm

29. An object displaces 0.002 m³ of water. Find the buoyant force in newtons, using ρ=1000 kg/m³ and g=10 m/s².
   A. 10
   B. 2
   C. 200
   D. 20
   E. 40

30. Absolute pressure is 140 kPa and local atmospheric pressure is 100 kPa. Find gauge pressure in kPa.
   A. 40
   B. 4
   C. 80
   D. 400
   E. 20

31. Which description best matches an ordinary liquid under normal conditions?
   A. Variable shape and nearly fixed volume
   B. Fixed shape but indefinitely expanding volume
   C. Shape and volume both independent of state
   D. Always zero density
   E. No particles and no mass

32. A mercury column has height 3 cm. Use ρHg=13600 kg/m³ and g=10 m/s². What pressure does it represent in pascals?
   A. 4080
   B. 40800
   C. 8160
   D. 408
   E. 2040

33. A 4 kg object rests on a horizontal base of area 0.02 m². Find its pressure on the base, using g=10 m/s².
   A. 4000
   B. 2000
   C. 20000
   D. 200
   E. 1000

34. A uniform perpendicular force of 450 N acts over 0.3 m². Pressure?
   A. 15000 Pa
   B. 0.00067 Pa
   C. 135 Pa
   D. 150 Pa
   E. 1500 Pa

35. Which description best matches an ordinary gas under normal conditions?
   A. Shape and volume both independent of state
   B. Always zero density
   C. Fixed shape and nearly fixed volume
   D. Variable shape and variable volume
   E. No particles and no mass

36. A hydraulic press has output piston area 3 times the input area. An input force of 50 N gives what ideal output force in newtons?
   A. 150
   B. 300
   C. 1500
   D. 75
   E. 15

37. A block of density 750 kg/m³ floats in oil of density 900 kg/m³. Fraction submerged?
   A. 0.75
   B. 0.80
   C. 0.90
   D. 0.83
   E. 1.20

38. A perpendicular force of 180 N acts on 0.2 m². Find pressure in pascals.
   A. 1800
   B. 9000
   C. 900
   D. 450
   E. 90

39. A liquid creates 2000 Pa of pressure above the pressure outside a flat base of area 0.02 m². Find the net pressure force in newtons.
   A. 40
   B. 80
   C. 20
   D. 400
   E. 4

40. A sample has mass 2 kg and volume 0.002 m³. Find its density in kg/m³.
   A. 500
   B. 2000
   C. 10000
   D. 100
   E. 1000

41. A 2 kg object rests on a horizontal base of area 0.02 m². Find its pressure on the base, using g=10 m/s².
   A. 1000
   B. 100
   C. 500
   D. 2000
   E. 10000

42. A sealed cylindrical tank has base area 250 cm², liquid density 950 kg/m³ and depth 60 cm. Gas pressure at the liquid surface is 2000 Pa above outside atmospheric pressure. Use g=10 m/s². What is the net downward pressure force across the base?
   A. 217.5 N
   B. 192.5 N
   C. 142.5 N
   D. 50 N
   E. 167.5 N

43. In water of density 1000 kg/m^3, how much does pressure increase over a depth increase of 2.0 m? Use g=10 m/s^2.
   A. 1000 Pa
   B. 10000 Pa
   C. 2000 Pa
   D. 200 Pa
   E. 20000 Pa

44. Steady incompressible flow enters a pipe at 2 m/s. The outlet area is half the inlet area. What is the outlet speed?
   A. 4 m/s
   B. 1 m/s
   C. 8 m/s
   D. 3 m/s
   E. 2 m/s

45. An object displaces 0.002 m^3 of water. Use density 1000 kg/m^3 and g=10 m/s^2. What is the buoyant force?
   A. 200 N
   B. 2 N
   C. 2000 N
   D. 20 N
   E. 0.02 N

46. Steady ideal water flows along a horizontal pipe. At one point its speed is 2 m/s, at a second 4 m/s. What is P₂−P₁, with density 1000 kg/m³?
   A. −6000 Pa
   B. 0 Pa
   C. 2000 Pa
   D. 6000 Pa
   E. −12000 Pa

47. A pipe carries steady incompressible water at 0.006 m³/s through an area of 0.003 m². Mean speed?
   A. 18 m/s
   B. 0.000018 m/s
   C. 20 m/s
   D. 2 m/s
   E. 0.5 m/s

48. A block of density 600 kg/m³ floats in water of density 1000 kg/m³. What fraction is above water?
   A. 0.40
   B. 0.60
   C. 0.20
   D. 0.00
   E. 1.00

49. Water depth increases from 1 m to 3 m. Surface pressure remains unchanged. With ρ=1000 kg/m³ and g=10, pressure increase?
   A. 10 kPa
   B. 40 kPa
   C. 20 kPa
   D. 2 kPa
   E. 30 kPa

50. An ideal hydraulic press has a large piston area four times the small one. Small piston moves down 8 cm. How far does the large piston rise?
   A. 32 cm
   B. 0.5 cm
   C. 2 cm
   D. 8 cm
   E. 4 cm

51. A pressure gauge reads −20 kPa at atmospheric pressure 100 kPa. Absolute pressure?
   A. 80 kPa
   B. 120 kPa
   C. 20 kPa
   D. 100 kPa
   E. −20 kPa