# Questions

1. A gas receives 200 J of work during an adiabatic compression. Find ΔU in joules.
   A. 20
   B. 400
   C. 200
   D. 2000
   E. 100

2. What is the pressure-volume boundary work done on a gas in an isochoric process?
   A. Equal to the gas volume
   B. Positive
   C. Zero
   D. Depends on ΔT
   E. Negative

3. 2 kg of water at 90°C mixes with 2 kg at 30°C, no loss. Final temperature?
   A. 45°C
   B. 120°C
   C. 55°C
   D. 60°C
   E. 75°C

4. 3 mol of gas occupies 0.1 m³ at 400 K (R=8.314). Pressure?
   A. 2.0×10⁵ Pa
   B. 3.0×10⁵ Pa
   C. 1.0×10⁴ Pa
   D. 0.5×10⁵ Pa
   E. 1.0×10⁵ Pa

5. An ideal gas expands isothermally from volume 2 L to 4 L. If its initial pressure is 120 kPa, find its final pressure in kPa.
   A. 120
   B. 6
   C. 600
   D. 30
   E. 60

6. Approximately what is 47°C in kelvin, to the nearest whole kelvin?
   A. 350 K
   B. 226 K
   C. 320 K
   D. 300 K
   E. 373 K

7. A gas absorbs 200 J in an isochoric process with no other work interactions. Find ΔU in joules.
   A. 100
   B. 20
   C. 400
   D. 2000
   E. 200

8. A gas expands isobarically at 200 kPa by 3 litres. Find work done by the gas in joules.
   A. 1200
   B. 60
   C. 6000
   D. 300
   E. 600

9. A heat engine absorbs 1000 J and rejects 300 J per cycle. Find efficiency as a percentage.
   A. 700
   B. 35
   C. 70
   D. 140
   E. 7

10. For a fixed amount of ideal gas undergoing an isothermal process, what is ΔU?
   A. Zero
   B. Negative
   C. Equal to the pressure change
   D. Equal to Q
   E. Positive

11. A gas at 2×10⁵ Pa, 6 L is compressed isothermally to 3 L. P₂?
   A. 4×10⁵ Pa
   B. 2×10⁶ Pa
   C. 8×10⁵ Pa
   D. 2×10⁵ Pa
   E. 1×10⁵ Pa

12. A gas releases 300 J while 500 J of work is done on it. ΔU?
   A. 200 J
   B. 0 J
   C. −200 J
   D. 800 J
   E. −800 J

13. A refrigerator removes 300 J from its interior using 100 J of work. Find its coefficient of performance.
   A. 5
   B. 3
   C. 0.33
   D. 4
   E. 2

14. A gas expands isobarically at 200 kPa by 2 litres. Find work done by the gas in joules.
   A. 400
   B. 800
   C. 4000
   D. 200
   E. 40

15. A 2 kg material with specific heat 500 J/(kg·K) warms by 4 K without changing phase. Find heat absorbed in joules.
   A. 8000
   B. 400
   C. 4000
   D. 2000
   E. 40000

16. A gas: P₁=1.5×10⁵ Pa, V₁=4 L, T₁=200 K changes to P₂=3×10⁵ Pa, T₂=600 K. V₂?
   A. 4 L
   B. 2 L
   C. 8 L
   D. 6 L
   E. 12 L

17. A heat engine absorbs 1000 J and rejects 200 J per cycle. Find efficiency as a percentage.
   A. 80
   B. 40
   C. 160
   D. 8
   E. 800

18. A gas absorbs 200 J of heat and does 50 J of work on its surroundings. Find ΔU in joules.
   A. 150
   B. 15
   C. 75
   D. 1500
   E. 300

19. A gas at constant pressure 3×10⁵ Pa has ΔV = −2 m³. Work on the gas?
   A. 0 J
   B. 6×10⁵ J
   C. −3×10⁵ J
   D. −6×10⁵ J
   E. 3×10⁵ J

20. A gas is compressed adiabatically with 350 J of work done on it. Q and ΔU?
   A. Q=350 J, ΔU=0
   B. Q=0, ΔU=350 J
   C. Q=0, ΔU=−350 J
   D. Q=−350 J, ΔU=0
   E. Q=350 J, ΔU=350 J

21. For a fixed amount of ideal gas undergoing an isothermal process, which quantity must be zero?
   A. Change in volume
   B. internal-energy change
   C. Absolute temperature
   D. Amount of gas
   E. Absolute pressure

22. A gas receives 300 J of work during an adiabatic compression. Find ΔU in joules.
   A. 600
   B. 300
   C. 150
   D. 3000
   E. 30

23. In a isochoric process, which quantity must be zero?
   A. boundary work
   B. Absolute pressure
   C. Change in pressure
   D. Absolute temperature
   E. Amount of gas

24. A refrigerator removes 200 J from its interior using 100 J of work. Find its coefficient of performance.
   A. 4
   B. 1
   C. 3
   D. 2
   E. 0.5

25. A gas at constant volume has P₁=1×10⁵ Pa at 250 K, heated to 400 K. P₂?
   A. 2.0×10⁵ Pa
   B. 0.625×10⁵ Pa
   C. 2.5×10⁵ Pa
   D. 1.6×10⁵ Pa
   E. 1.2×10⁵ Pa

26. In an adiabatic process, which quantity must be zero?
   A. Internal-energy change
   B. heat transfer
   C. Amount of gas
   D. Absolute temperature
   E. Absolute pressure

27. A gas absorbs 300 J of heat and does 50 J of work on its surroundings. Find ΔU in joules.
   A. 125
   B. 250
   C. 500
   D. 2500
   E. 25

28. A refrigerator expels 800 J using 300 J of work. Heat removed from interior?
   A. 240000 J
   B. 500 J
   C. 800 J
   D. 300 J
   E. 1100 J

29. A heat engine absorbs 900 J with 30% efficiency. Heat released?
   A. 1170 J
   B. 900 J
   C. 270 J
   D. 450 J
   E. 630 J

30. A fixed amount of ideal gas in a rigid closed vessel absorbs heat and does no work. Its internal energy increases. Identify the process and temperature change.
   A. Adiabatic; T decreases
   B. Isochoric; T increases
   C. Isothermal; T constant
   D. Isobaric; T constant
   E. Isochoric; T decreases

31. A gas absorbs 100 J of heat and does 30 J of work on its surroundings. What is its internal-energy change?
   A. +130 J
   B. +30 J
   C. +70 J
   D. -130 J
   E. -70 J

32. A fixed amount of ideal gas is heated at constant volume from 300 K to 450 K. Pressure ratio P₂/P₁?
   A. 0.667
   B. 2.25
   C. 1.5
   D. 1
   E. 150

33. A gas releases 80 J of heat while 120 J of work is done on it. Find ΔU.
   A. 0 J
   B. +40 J
   C. +200 J
   D. −40 J
   E. −200 J

34. A cyclic engine exchanges heat with only one reservoir and converts all absorbed heat into net work. Which law forbids this?
   A. Second law of thermodynamics
   B. Conservation of electric charge
   C. Pascal's law
   D. First law alone
   E. Ohm's law

35. Which heat-transfer process can occur across a vacuum?
   A. Conduction through matter only
   B. Radiation
   C. Convection only
   D. Diffusion of gas molecules only
   E. All require matter

36. A 0.5 kg sample with specific heat 400 J/(kg·K) absorbs 1000 J without phase change. Temperature rise?
   A. 50 K
   B. 2 K
   C. 5 K
   D. 200 K
   E. 0.2 K

37. An ideal gas expands adiabatically and does positive boundary work with no other work. What happens to its internal energy?
   A. It becomes zero
   B. It stays constant
   C. It increases
   D. It is determined only by volume
   E. It decreases