# Questions

1. A 3 kg body hangs motionless from a light vertical rope. Find tension in newtons, using g=10 m/s².
   A. 60
   B. 30
   C. 3
   D. 300
   E. 15

2. At height h = Rₑ above Earth, g′ equals:
   A. g/8
   B. g/9
   C. g/2
   D. g/4
   E. g/16

3. A net force of 24 N acts on a 6 kg mass. Find acceleration in m/s².
   A. 12
   B. 36
   C. 144
   D. 4
   E. 3

4. A 3 kg object's velocity changes from +3 to −2 m/s. What is its change in momentum in kg·m/s?
   A. −6
   B. -15
   C. -3
   D. 3
   E. 15

5. A machine performs 240 J of work in 6 s. Find its average power in watts.
   A. 20
   B. 80
   C. 400
   D. 4
   E. 40

6. A constant 30 N force acts in the same direction as a displacement of 3 m. Find its work in joules.
   A. 9
   B. 180
   C. 900
   D. 45
   E. 90

7. A 2 kg mass moves at 4 m/s around a circle of radius 2 m. What net inward force is required in newtons?
   A. 8
   B. 16
   C. 32
   D. 1.6
   E. 160

8. A body rests on a horizontal surface with normal force 200 N. If μk=0.2, find kinetic friction in newtons when it slides.
   A. 80
   B. 40
   C. 20
   D. 400
   E. 4

9. An object falls from rest through 10 m without losses. Find its speed squared in m²/s², using g=10 m/s².
   A. 400
   B. 200
   C. 100
   D. 20
   E. 2000

10. A net force of 15 N acts on a mass of 5 kg. What is its acceleration?
   A. 75 m/s²
   B. 2 m/s²
   C. 3 m/s²
   D. 8 m/s²
   E. 5 m/s²

11. A 0.9 kg mass moves in a horizontal circle of radius 1.0 m, one revolution per second. Centripetal force?
   A. 1.8π² N
   B. 0.9π² N
   C. 3.6π² N
   D. 4.8π² N
   E. 2.4π² N

12. A 3 kg object initially at rest reaches 4 m/s. What is the net work in joules?
   A. 2.4
   B. 240
   C. 12
   D. 48
   E. 24

13. A 4 kg object speeds up from 3 m/s to 5 m/s. What is the net work done on it?
   A. 50 J
   B. 16 J
   C. 64 J
   D. 8 J
   E. 32 J

14. A body rests on a horizontal surface with normal force 300 N. If μk=0.2, find kinetic friction in newtons when it slides.
   A. 30
   B. 60
   C. 120
   D. 600
   E. 6

15. A skier leaves a jump at 20 m/s (no losses, g = 10). Where is the speed 12 m/s?
   A. 12.8 m higher
   B. 20 m higher
   C. 25.6 m lower
   D. 25.6 m higher
   E. 12.8 m lower

16. A 3 kg object moves at 6 m/s. What is its kinetic energy in joules?
   A. 540
   B. 5.4
   C. 108
   D. 27
   E. 54

17. A pump uses 5000 J to lift 40 kg of water 8 m (g = 10). Efficiency?
   A. 32%
   B. 6.4%
   C. 48%
   D. 80%
   E. 64%

18. A machine receives 300 J and delivers 180 J of useful output. What is its efficiency as a percentage?
   A. 3
   B. 60
   C. 100
   D. 40
   E. 0.6

19. A 3 kg object is raised vertically by 3 m at constant speed. What is the work done by gravity in joules? Use g=10 m/s².
   A. -30
   B. 90
   C. 0
   D. -90
   E. 30

20. A 3 kg object accelerates at 4 m/s². The net force is:
   A. 4 N
   B. 7 N
   C. 12 N
   D. 0.75 N
   E. 3 N

21. An engine delivers 60 kW of mechanical power to maintain constant speed 20 m/s on a level road. What is the total resistive force magnitude?
   A. 1500 N
   B. 3000 N
   C. 4000 N
   D. 1200000 N
   E. 2000 N

22. A 2 kg object initially at rest reaches 4 m/s. What is the net work in joules?
   A. 32
   B. 1.6
   C. 16
   D. 160
   E. 8

23. A 2000 kg elevator moves down while decelerating at 2 m/s² (g = 10). The cable tension is:
   A. 28000 N
   B. 20000 N
   C. 16000 N
   D. 24000 N
   E. 4000 N

24. An ideal linear spring with k=150 N/m is stretched 0.2 m. Find the restoring force magnitude.
   A. 750 N
   B. 75 N
   C. 300 N
   D. 15 N
   E. 30 N

25. A car takes an unbanked horizontal curve of radius 50 m at 10 m/s. Use g=10 m/s². What minimum coefficient of static friction is required?
   A. 2
   B. 0.1
   C. 0.3
   D. 0.2
   E. 0.5

26. A 2 kg object is raised vertically by 3 m at constant speed. What is the work done by gravity in joules? Use g=10 m/s².
   A. 60
   B. -60
   C. 0
   D. -20
   E. 20

27. A 4 kg object is raised vertically by 3 m at constant speed. What is the work done by gravity in joules? Use g=10 m/s².
   A. -40
   B. 0
   C. 40
   D. -120
   E. 120

28. A 20 N force acts at 60° to a 5 m displacement. The work is:
   A. 0 J
   B. 50 J
   C. 87 J
   D. 100 J
   E. 25 J

29. A spring with k=200 N/m is extended by 0.1 m. Find the restoring force magnitude in newtons.
   A. 2
   B. 40
   C. 10
   D. 20
   E. 200

30. A 0.2 kg ball moving right at 8 m/s hits a wall and returns left at 5 m/s. Contact lasts 0.05 s. What is the magnitude of the average net force?
   A. 12 N
   B. 52 N
   C. 2.6 N
   D. 26 N
   E. 130 N

31. An object falls from rest through 15 m without losses. Find its speed squared in m²/s², using g=10 m/s².
   A. 150
   B. 30
   C. 3000
   D. 300
   E. 600

32. A machine receives 200 J and delivers 120 J of useful output. What is its efficiency as a percentage?
   A. 2
   B. 100
   C. 60
   D. 40
   E. 0.6

33. The separation of two point masses becomes 2 times as large. By what factor does their gravitational force change?
   A. 4
   B. 0.5
   C. 2
   D. 0.125
   E. 0.25

34. A machine performs 360 J of work in 6 s. Find its average power in watts.
   A. 60
   B. 600
   C. 30
   D. 6
   E. 120

35. A 4 kg object moves at 6 m/s. What is its kinetic energy in joules?
   A. 144
   B. 7.2
   C. 720
   D. 72
   E. 36

36. A 2 kg body hangs motionless from a light vertical rope. Find tension in newtons, using g=10 m/s².
   A. 20
   B. 2
   C. 10
   D. 200
   E. 40

37. A 60 kg box slides on a horizontal surface, pulled horizontally by 300 N in the direction of motion. μk=0.3 and g=10 m/s². Acceleration magnitude?
   A. 3 m/s²
   B. 2 m/s²
   C. 1 m/s²
   D. 5 m/s²
   E. 0.5 m/s²

38. A spring with k=300 N/m is extended by 0.1 m. Find the restoring force magnitude in newtons.
   A. 300
   B. 60
   C. 15
   D. 3
   E. 30

39. A constant 20 N force acts in the same direction as a displacement of 3 m. Find its work in joules.
   A. 600
   B. 60
   C. 6
   D. 30
   E. 120

40. Two point masses 3×10²⁴ kg and 2×10²² kg are 2×10⁷ m apart. Use G=6.67×10⁻¹¹ N·m²/kg². Gravitational force magnitude?
   A. 1.0×10²⁰ N
   B. 2.0×10²² N
   C. 4.0×10²² N
   D. 1.0×10²² N
   E. 8.0×10²² N

41. A 2 kg object's velocity changes from +3 to −2 m/s. What is its change in momentum in kg·m/s?
   A. -2
   B. 10
   C. −4
   D. -10
   E. 2

42. A 2 kg object moves at 6 m/s. What is its kinetic energy in joules?
   A. 72
   B. 3.6
   C. 18
   D. 36
   E. 360

43. What is the kinetic energy of a 2.0 kg object moving at 3.0 m/s?
   A. 18 J
   B. 6.0 J
   C. 9.0 J
   D. 12 J
   E. 3.0 J

44. A net force of 6.0 N acts on a 2.0 kg object. What is its acceleration?
   A. 12 m/s^2
   B. 8.0 m/s^2
   C. 0.33 m/s^2
   D. 2.0 m/s^2
   E. 3.0 m/s^2

45. A constant force of 5 N is perpendicular to a displacement of 4 m. What work does this force do?
   A. -20 J
   B. 0 J
   C. 20 J
   D. 9 J
   E. 1.25 J

46. A passenger in a freely falling lift neglecting drag has apparent weight (normal force):
   A. 2mg
   B. mg/2
   C. Zero
   D. Dependent only on the lift's speed
   E. mg

47. A book is at rest on a table. Which force is the Newton's third-law partner of the table's force on the book?
   A. The friction force on the table from the floor
   B. The net force on the book
   C. The gravitational force of the book on Earth
   D. The force of the book on the table
   E. The gravitational force of Earth on the book

48. A 10 N force makes an angle of 120° with a 2 m displacement. Work?
   A. −20 J
   B. 0 J
   C. −10 J
   D. 20 J
   E. 10 J

49. A 1 kg object starts at rest 5 m above ground. A resistive force does −20 J of work by the time it reaches ground. Use g=10. Final kinetic energy?
   A. 0 J
   B. 70 J
   C. 20 J
   D. 30 J
   E. 50 J

50. A horizontal 12 N force acts on a body moving at 3 m/s at 60° to the force. Instantaneous power?
   A. 4 W
   B. 0 W
   C. 9 W
   D. 18 W
   E. 36 W

51. Two blocks of 2 kg and 3 kg are linked by a light string on a frictionless horizontal surface. A horizontal 10 N force pulls the 3 kg block. Tension?
   A. 4 N
   B. 20 N
   C. 10 N
   D. 2 N
   E. 6 N