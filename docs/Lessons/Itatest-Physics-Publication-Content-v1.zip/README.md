# Itatest Physics — publication content handoff (v1)

Educational content only. The six existing main chapters and 68 full lessons are preserved and revised, rather than replaced by shorter summaries. The official fluid/thermodynamics nucleus is split into two teaching chapters. R1/R2 concepts are merged into the corresponding lessons; the superseded material is archived separately. The original 99 source sections, 220 questions and 97 source exercises are preserved in provenance.

## Canonical files
- `chapters/01`–`06`: `chapter.json`, `lessons.json`, `questions.json`, `exercises.json`. Lesson HTML is the delivery content; standalone HTML and Markdown are alternate views, not additional lessons. Existing lesson and topic IDs are preserved. Existing question IDs are preserved, but answer indexes may change because choices were revised and deterministically shuffled. All indexes are zero-based. The `correctOptionText` and `Explanation` fields are for grading/review, not ungraded learner payloads.
- 256 practice MCQs (220 revised existing questions plus 36 new original questions); 25 separate mock MCQs; 30 independent open-response exercises. 97 original exercises are linked aliases of MCQs, not 97 additional independent questions.
- `assessments.json`: six ten-question chapter reviews and five five-question, ten-minute practice mocks. Raw scoring is +1 correct, −0.25 wrong, 0 unanswered; these are not CISIA normalised scores. Mock questions are original Itatest practice, not official CISIA items.
- `figures/`: 51 restored SVG figures from the original authored source; inline SVG is also embedded in canonical lessons. Preserve vector rendering, RTL text and LTR formulas. SVG and layout still need site-side verification.
- `formula-sheet.md`, `curriculum-map.md`: formula reference and coverage mapping.
- `provenance/`: original records, editorial change/mapping files, near-duplicate variant groups. Do not publish archived lesson HTML or old answers. When selecting assessment questions, avoid selecting multiple members of a variant group; retain source-linked exercises as references rather than duplicate questions.

## Editorial and delivery boundaries
Source content was inspected; all 220 original MCQ answers were recalculated or conceptually reviewed, with Persian explanations, extra distractors, and explicit assumptions where needed. Existing four-option questions now have five options. Some generated numerical distractors were replaced with meaningful magnitude errors. The full existing teaching content and figures have not undergone independent line-by-line expert verification; 23 direct paragraph edits and targeted clarifications address identified overgeneralisations and syllabus gaps. Some legacy near-duplicate items remain intentionally as practice variants. Source-wide summaries/practice are archived; the canonical formula sheet and tests replace them. The chapter arrangement preserves supporting material beyond the syllabus. Question difficulty labels are editorial and uncalibrated.

No database, importer, application code or deployment changes were performed. The package is an authored content handoff for Codex to integrate and validate; independent physics-specialist review and real website rendering/import checks are still needed before commercial release. Do not infer those checks from structural validation.

Official syllabus (accessed 2026-11-24): https://cisiaonline.it/en/cent/cent-s/structure-and-syllabus
