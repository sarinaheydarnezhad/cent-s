# Biology — CISIA CEnT-S curriculum map

Reference: [Official CISIA structure and syllabus](https://cisiaonline.it/en/cent/cent-s/structure-and-syllabus), accessed 2026-11-24. Biology has 10 questions in 20 minutes. Five options per item, one correct. The mapping below identifies lesson locations, not independently verified mastery or official item weighting.

| Official nucleus / topic | Canonical lesson keys |
|---|---|
| Biological molecules — water, hydrophilicity/hydrophobicity | 1.2, 1.5 |
| Carbohydrates and lipids | 1.4, 1.5 |
| Protein organisation and interactions | 1.3, 1.4, 1.6 |
| Nucleic acids | 1.4, 1.6 |
| Cell biology — prokaryotes and eukaryotes | 2.1 |
| Plasma membrane and transport | 2.2 |
| Nucleus, ribosomes, ER, Golgi, lysosomes and cytoskeleton | 2.3 |
| Mitochondria, plant wall, vacuoles and plastids | 2.4; added amyloplast and chromoplast descriptions |
| Cell cycle/division/inheritance — genome | 3.1 |
| Replication, transcription and translation | 3.2–3.4 |
| Cell cycle and bacterial binary fission | 3.7; added explicit bacterial division explanation |
| Mitosis and meiosis | 3.7–3.8 |
| Mendelian inheritance and allele flow | 3.9, 4.9 |
| Plant and ecology — root, stem, leaf | 4.1, 4.3 |
| Flower, fruit and seed | 4.2 |
| Photosynthesis and energy flow | 2.7, 4.5 |
| Ecosystems and food chains | 4.5 |
| Competition, predation, parasitism, mutualism, commensalism | 4.8 |
| Animal physiology — four tissue classes | 5.1 |
| Musculoskeletal | 5.2 |
| Nervous | 5.3 |
| Circulatory | 5.5 |
| Respiratory | 5.6 |
| Digestive | 5.7 |
| Excretory | 5.8 |

Supporting content retained: atomic chemistry, enzyme kinetics, respiration and metabolism, signalling, gene regulation and biotechnology, plant hormones, nutrient cycles, population ecology, evolution, endocrine and immune systems. Label these as supporting rather than claiming all are explicit CISIA requirements. Some support lessons include core-related concepts. No official topic frequency is asserted. The original Itatest five-chapter arrangement is preserved.

Further scientific reference for independent verification: [OpenStax Biology 2e](https://openstax.org/details/books/biology-2e). This is a suggested review reference, not a claim that every sentence was verified against it.
