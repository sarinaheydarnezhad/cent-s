# Itatest Biology — original practice exams

## Biology mock 1 — 10 questions / 20 minutes

1. Which tissue class contains cells specialised to conduct electrical signals over long distances?
   A. Muscular exclusively
   B. Epithelial
   C. Connective
   D. Nervous
   E. Adipose exclusively

2. A water droplet forms a bead on a waxy leaf. Which property of water contributes most directly to its rounded shape?
   A. Ionic bonding to wax
   B. Water's inability to form hydrogen bonds
   C. Hydrolysis of wax
   D. Cohesion caused by hydrogen bonding
   E. Covalent bonding between water molecules

3. A diploid cell has 2n=14 in G1. Immediately after S phase and before mitosis, how many chromosomes and chromatids are present?
   A. 7 chromosomes and 14 chromatids
   B. 14 chromosomes and 28 chromatids
   C. 14 chromosomes and 14 chromatids
   D. 28 chromosomes and 56 chromatids
   E. 28 chromosomes and 28 chromatids

4. A cell secretes a glycoprotein. Which route is most consistent with this function?
   A. Smooth ER → mitochondrial matrix → ribosome
   B. Lysosome → nucleolus → plasma membrane
   C. Cytoskeleton → DNA → cell wall
   D. Golgi → nucleus → chloroplast
   E. Rough ER → Golgi → secretory vesicle → plasma membrane

5. In a typical flowering plant, what develops from the fertilised ovule?
   A. Petal
   B. Seed
   C. Stigma
   D. Anther
   E. Root hair

6. Which feature of a root hair cell most directly improves absorption?
   A. Its ability to produce pollen
   B. A large number of stomata
   C. A thick waterproof cuticle
   D. Its large surface area in contact with soil
   E. The absence of a plasma membrane

7. A newly observed cell has a nucleoid, ribosomes and a plasma membrane, but no membrane-bound nucleus. Which category best fits?
   A. Fungal cell
   B. Prokaryote
   C. Animal epithelial cell
   D. A mitochondrion-free typical eukaryotic cell with a nucleus
   E. Plant mesophyll cell

8. A membrane lipid has two hydrocarbon tails and a charged head. In water, where are the tails of a bilayer found?
   A. Covalently attached to DNA
   B. Inside the phosphate head
   C. Facing one another away from water
   D. Only on the extracellular face
   E. Facing the surrounding water

9. What connects a skeletal muscle to the bone it moves?
   A. Alveolus
   B. Tendon
   C. Ligament
   D. Neuron soma
   E. Nephron

10. Two heterozygous parents carry a recessive allele for a trait with complete penetrance. What is the chance that their first two children both have the recessive phenotype?
   A. 1/4
   B. 1/8
   C. 3/16
   D. 1/16
   E. 1/2

## Biology mock 2 — 10 questions / 20 minutes

1. Starting with one double-stranded DNA molecule, after three ideal rounds of semiconservative replication how many molecules contain one original strand?
   A. 6
   B. 8
   C. 2
   D. 1
   E. 4

2. A membrane is permeable to water but not to sucrose. Side A has 0.1 M sucrose and side B has 0.4 M. Initially, with equal pressure, net water moves:
   A. Only when sucrose crosses
   B. From A to B
   C. Only if ATP is added
   D. In neither direction
   E. From B to A

3. A food chain contains producers with 8,000 kJ available. Transfer efficiencies to primary and secondary consumers are 15% and 20%. How much reaches secondary consumers?
   A. 80 kJ
   B. 240 kJ
   C. 2800 kJ
   D. 1600 kJ
   E. 1200 kJ

4. At a typical chemical synapse, what directly triggers synaptic vesicle fusion after an action potential arrives?
   A. Calcium influx into the presynaptic terminal
   B. ATP release from the myelin sheath
   C. Sodium removal from the postsynaptic nucleus
   D. Potassium storage in the synaptic cleft
   E. DNA replication

5. A person's heart rate is 75 beats/min and stroke volume is 80 mL. What is cardiac output?
   A. 0.6 L/min
   B. 155 L/min
   C. 1.07 L/min
   D. 60 L/min
   E. 6.0 L/min

6. A linear chain of 45 amino acids is fully hydrolysed into individual amino acids. How many peptide bonds are broken?
   A. 90
   B. 45
   C. 43
   D. 46
   E. 44

7. A DNA template is 3′-CGTATA-5′. Which RNA segment is transcribed?
   A. 5′-CGUAUA-3′
   B. 5′-UAUACG-3′
   C. 3′-GCAUAU-5′
   D. 5′-GCAUAU-3′
   E. 5′-GCATAT-3′

8. A protein consists of two folded polypeptides that associate reversibly. Their association represents which structural level?
   A. Quaternary
   B. Tertiary of one chain
   C. Primary
   D. Secondary
   E. Nucleotide sequence

9. Which tissue carries assimilated sucrose from a mature source leaf to a growing sink?
   A. Phloem
   B. Xylem exclusively
   C. Cuticle
   D. Root cap
   E. Epidermis exclusively

10. Which plastid is especially associated with starch storage in non-photosynthetic plant tissue?
   A. Mitochondrion
   B. Rough ER
   C. Nucleolus
   D. Lysosome
   E. Amyloplast

## Biology mock 3 — 10 questions / 20 minutes

1. Which change would directly reduce oxygen diffusion across an otherwise unchanged alveolar exchange barrier?
   A. Increasing barrier thickness
   B. Decreasing diffusion distance
   C. Increasing surface area
   D. Increasing the oxygen partial-pressure difference
   E. Increasing available capillary area

2. A microbe obtains nutrients from a host and reduces host fitness. Which relationship is described?
   A. Neutralism
   B. Mutualism
   C. Parasitism
   D. Commensalism
   E. Competition for unrelated resources

3. In normal meiosis of a cell with 2n=10, which structures separate during anaphase I?
   A. Sister chromatids of every chromosome
   B. Nucleotides within DNA
   C. Homologous chromosomes
   D. Ribosomal subunits
   E. Paired bases in each double helix

4. A codon for an amino acid is replaced by a stop codon. What is the mutation called?
   A. Nonsense
   B. Silent
   C. Synonymous
   D. Chromosome duplication
   E. In-frame insertion

5. In a double-stranded DNA sample, cytosine makes up 18% of the bases. What proportion is thymine?
   A. 82%
   B. 64%
   C. 32%
   D. 18%
   E. 36%

6. Which carbohydrate contributes mainly to the mechanical strength of plant cell walls?
   A. Cellulose
   B. Sucrose
   C. Maltose
   D. Glucose stored in blood
   E. Glycogen

7. A mature root cell of a typical flowering plant does not photosynthesise. Which organelle still supplies ATP through aerobic respiration?
   A. Nucleolus
   B. Chloroplast
   C. Mitochondrion
   D. Central vacuole
   E. Golgi

8. Two species use the same limited nesting sites, reducing reproductive success in both. Which interaction is described?
   A. Predation
   B. Mutualism
   C. Commensalism
   D. Parasitism
   E. Competition

9. A drug prevents microtubule assembly. Which cell structure is directly affected during mitosis?
   A. Phospholipid bilayer
   B. Crista
   C. Nucleosome
   D. Spindle
   E. Peptidoglycan wall

10. A large reduction in small-intestinal villus surface area would most directly impair which function?
   A. Contraction of skeletal muscle
   B. Bile synthesis by the liver
   C. Nutrient absorption
   D. Air movement into lungs
   E. Glomerular filtration

## Biology mock 4 — 10 questions / 20 minutes

1. Which observation best distinguishes a typical bacterial genome from a mammalian nuclear genome?
   A. All bacterial DNA is inside mitochondria
   B. Only RNA is inherited
   C. DNA is made of amino acids
   D. DNA in a nucleoid instead of a membrane-bound nucleus
   E. No genetic information exists

2. Which process normally divides a bacterial cell into two daughter cells?
   A. Fertilisation
   B. Budding of a nucleus
   C. Mitosis with a nuclear spindle
   D. Meiosis I
   E. Binary fission

3. Which vessel carries oxygen-poor blood from the right ventricle toward the lungs?
   A. Coronary vein
   B. Aorta
   C. Pulmonary vein
   D. Superior vena cava
   E. Pulmonary artery

4. Which statement distinguishes energy flow from matter cycling in an ecosystem?
   A. Energy is recycled completely while matter disappears
   B. Energy is dissipated as heat while matter can be recycled
   C. Both are created by consumers
   D. Matter cannot pass between trophic levels
   E. Both are destroyed by photosynthesis

5. Which organelle contains enzymes that hydrolyse material delivered by endocytosis in a typical animal cell?
   A. Nucleolus
   B. Peroxisome exclusively
   C. Lysosome
   D. Smooth ER
   E. Centrosome

6. Two dilute solutions have pH 5 and pH 7. How does the hydrogen-ion concentration of the first compare with the second?
   A. The same
   B. 100 times as low
   C. 100 times as high
   D. 2 times as high
   E. 10 times as high

7. A healthy kidney filters 160 L of fluid per day and produces 2 L of urine. Approximately what percentage of filtered water is reabsorbed?
   A. 50%
   B. 99.9%
   C. 80%
   D. 1.25%
   E. 98.75%

8. An enzyme speeds up a reversible reaction at constant temperature. What happens to the equilibrium constant?
   A. It becomes equal to the activation energy
   B. It increases only for the forward reaction
   C. It doubles
   D. It stays unchanged
   E. It becomes zero

9. In a typical terrestrial leaf, which structures regulate gas exchange through the epidermis?
   A. Stomata and guard cells
   B. Xylem vessels alone
   C. Root hairs
   D. Seed coats
   E. Pollen grains

10. A spherical cell's radius triples. What happens to its surface-area-to-volume ratio?
   A. It becomes one ninth
   B. It becomes nine times larger
   C. It becomes one third
   D. It triples
   E. It stays constant

## Biology mock 5 — 10 questions / 20 minutes

1. Which molecule is a lipid but is not a polymer of repeating monomers?
   A. DNA
   B. Glycogen
   C. Cholesterol
   D. A polypeptide
   E. Cellulose

2. A bird gains food by following a large grazing mammal that is demonstrably unaffected. What interaction is described?
   A. Commensalism
   B. Mutualism
   C. Competition
   D. Predation
   E. Parasitism

3. Which structure is directly responsible for translating mRNA into a polypeptide?
   A. Centrioles
   B. Nuclear pore
   C. Lysosome
   D. Golgi apparatus
   E. Ribosome

4. Which epithelial arrangement best supports a short diffusion path across an alveolar wall?
   A. Thick smooth muscle bundles
   B. Dense bone matrix
   C. Stratified cuboidal epithelium
   D. A single layer of thin squamous cells
   E. Many layers of keratinised cells

5. For independent loci, an AaBb individual is crossed with aabb. What is the probability of offspring Aabb?
   A. 1/16
   B. 1/2
   C. 3/4
   D. 1/4
   E. 1

6. A transporter moves a neutral solute from 1 mM outside to 10 mM inside by coupling it to downhill sodium entry. What type of transport is this?
   A. Primary active transport directly hydrolysing ATP
   B. Secondary active transport
   C. Passive facilitated diffusion of the solute
   D. Osmosis
   E. Simple diffusion

7. Which linkage forms the sugar-phosphate backbone of RNA?
   A. Phosphodiester
   B. Disulfide
   C. Hydrogen bond between bases
   D. Ester between glycerol and fatty acid
   E. Peptide

8. A diploid organism has three homologous chromosome pairs. How many gamete chromosome combinations can independent assortment alone produce?
   A. 6
   B. 9
   C. 3
   D. 8
   E. 16

9. During dehydration, which hormonal response normally reduces water loss in urine?
   A. Reduced ADH action on collecting ducts
   B. Insulin acting on alveoli
   C. Complete cessation of glomerular filtration
   D. Increased ADH action on collecting ducts
   E. Glucagon blocking all aquaporins

10. During oxygenic photosynthesis, which molecule supplies the released molecular oxygen?
   A. Carbon dioxide
   B. Sucrose
   C. Water
   D. Chlorophyll
   E. ATP