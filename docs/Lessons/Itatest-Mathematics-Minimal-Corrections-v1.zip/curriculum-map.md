# Mathematics curriculum alignment
Reference: CISIA, CEnT-S structure and syllabus, https://www.cisiaonline.it/en/cent/cent-s/structure-and-syllabus (checked 2026-11-24). Mathematics: 15 items / 30 minutes.

Existing chapter-level mapping (not a claim of full line-by-line coverage):

| Official area (paraphrased) | Existing Itatest chapters and supplements | Evidence / scope |
|---|---|---|
| Number operations, factors, powers, percentages | Chapter 1; R1 number lesson | Core operations, number types, factors, powers, roots, percent and estimation; division with remainder in R1. |
| Algebra and solution sets | Chapters 1–2; R1 algebra | Identities, linear and quadratic equations/inequalities, sign analysis, systems. |
| Plane/solid geometry and coordinates | Chapters 2 and 5; R1 geometry | Area, volume, similarity, distance, line and circle equations; plane regions addressed in R1. |
| Functions and graphs | Chapter 3; R1 functions, R2 inverse/domain | Elementary functions, composition, inverses, graph transformations, graphical solution. |
| Exponential and logarithmic expressions | Chapter 3; R1 exponent/log | Definitions, graph behavior, equations and inequalities. |
| Counting and finite probability | Chapter 6; R1 counting | Counting rules, arrangements, combinations, disjoint and independent events. |
| Basic statistics | Chapter 7; R1 statistics, R2 scales | Graphs, frequency, central measures and four measurement scales (R1). |

Trigonometry (chapter 4), conditional probability and dispersion are retained as existing supplementary material; the official Mathematics list does not explicitly require them as standalone areas. Trigonometric basics are relevant to Physics. All seven syllabus areas have corresponding material; depth/coverage at every sub-item has not been certified. No new curriculum content was added.
