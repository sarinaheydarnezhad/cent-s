# Itatest Mathematics — minimal correction package

Purpose: preserve existing teaching material, chapter sequence, visual assets, questions, exercises, and identity keys; change only specific documented issues. No new syllabus structure or question bank was imposed.

## Integration handoff
- `patches.json` is authoritative: each row identifies the original record by Id and ImportKey and contains exact before/after values of changed fields. Apply by matching ID and expected old field; abort/report conflicts, and do not apply twice. For source-derived records, also port the corresponding localized corrections into the canonical source/seed HTML so a subsequent import cannot overwrite them. Raw source documents included under `database-sources/math/` are untouched historical references, NOT replacement import payloads. Likewise `frontend-samples` and source-document metadata are references, not new production content. Do not import the entire archive blindly.
- `subjects/math/` contains the corrected export in its original organization, including source-wide sections. JSON records are authoritative; Markdown is for review. Original answer keys, options, IDs, topic relationships, ordering and all other record fields are unchanged.
- `validation.json` records structural checks. No database or application code has been modified.
- Existing four-option practice questions are deliberately retained (174 of 201). The official examination uses five choices; do not represent these practice items as exact-format mock exams. No new mock exam is included in this minimal-change package.
- Scientific review: all 201 existing MCQ stems/answer keys were inspected; 27 generic explanations were made question-specific. Selected lesson passages and open-response items were checked and corrected; no exhaustive line-by-line certification of all 89 sections and 204 exercises is claimed. No independent specialist or browser test was performed.
