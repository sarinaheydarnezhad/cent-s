# Source-wide sections (no chapter assigned in the original data)

Original chapter ID: `source-252303E1-32E1-77F4-D8E2-B3F765C5F480`

## آمار (Statistics)

Section ID: `456A03E5-3FA1-819B-7D28-173BAC4441C3`

Import key: `math/chapter7-statistics.html#intro`

Topic ID: `None`

Source: [math/chapter7-statistics.html](../../../../database-sources/math/252303E1-32E1-77F4-D8E2-B3F765C5F480.html) — ID `252303E1-32E1-77F4-D8E2-B3F765C5F480`

فصل ۷ | جزوهٔ آموزشی گام‌به‌گام
آمار (Statistics)
از جامعه و نمونه تا جدول‌ها، نمودارها، شاخص‌های مرکزی و پراکندگی — قدم‌به‌قدم و بدون پرش مفهومی
؟
مقدمه

## چگونه از این جزوه استفاده کنیم؟

Section ID: `ADE930F5-7478-97BE-68F6-B8E0930C8EAB`

Import key: `math/chapter7-statistics.html#section-01`

Topic ID: `None`

Source: [math/chapter7-statistics.html](../../../../database-sources/math/252303E1-32E1-77F4-D8E2-B3F765C5F480.html) — ID `252303E1-32E1-77F4-D8E2-B3F765C5F480`

چگونه از این جزوه استفاده کنیم؟
۱
فهم مفهوم
کارت آبی رو بخون تا تعریف و فرمول دستت بیاد.
۲
دیدن مثال
مثال‌های سبز رو خط‌به‌خط دنبال کن.
۳
بررسی دام‌ها
اشتباهات رایج قرمز رو بشناس تا توشون نیفتی.
۴
هایلایت امتحانی
نکات طلایی برای سرعت تست‌زنی.
۵
حل تمرین
تمرین بنفش رو خودت حل کن، بعد جواب رو ببین.
۱
بخش اول

## جمع‌بندی فصل ۷

Section ID: `F09623C3-7AAD-4EDF-00AC-E67AC578FA4D`

Import key: `math/chapter7-statistics.html#section-07`

Topic ID: `None`

Source: [math/chapter7-statistics.html](../../../../database-sources/math/252303E1-32E1-77F4-D8E2-B3F765C5F480.html) — ID `252303E1-32E1-77F4-D8E2-B3F765C5F480`

جمع‌بندی فصل ۷
جامعه و نمونه
انواع متغیر
جدول فراوانی
نمودارها
میانگین، میانه، مد
دامنه و انحراف معیار
ضریب تغییرات
مسیرمون از تشخیص جامعه و نمونه شروع شد، به جدول‌ها و نمودارها رسید، بعد وارد شاخص‌های مرکزی شدیم تا بفهمیم داده‌ها حول چه عددی متمرکزن، و در آخر با شاخص‌های پراکندگی یاد گرفتیم داده‌ها چقدر پخش شدن.
🧭 آمار فقط عدد و فرمول نیست — یه زبونه برای فهمیدن دنیای اطراف با داده. هر بار که یه شاخص جدید یاد می‌گیری، یه عینک تازه به چشمت میاد که با اون دقیق‌تر می‌بینی.
