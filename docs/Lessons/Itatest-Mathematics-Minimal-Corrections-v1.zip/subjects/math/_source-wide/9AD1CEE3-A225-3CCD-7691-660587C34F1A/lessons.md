# Source-wide sections (no chapter assigned in the original data)

Original chapter ID: `source-9AD1CEE3-A225-3CCD-7691-660587C34F1A`

## ترکیبات و احتمال

Section ID: `543DBD7F-B57E-24AB-8DE0-D4C5CF5F466C`

Import key: `math/chapter6-combinatorics-probability.html#intro`

Topic ID: `None`

Source: [math/chapter6-combinatorics-probability.html](../../../../database-sources/math/9AD1CEE3-A225-3CCD-7691-660587C34F1A.html) — ID `9AD1CEE3-A225-3CCD-7691-660587C34F1A`

فصل ۶ | جزوهٔ آموزشی گام‌به‌گام
ترکیبات و احتمال
از شمردن حالت‌ها با اصل ضرب تا محاسبهٔ احتمال شرطی — قدم‌به‌قدم، با مثال و تمرین برای هر بخش.

## چگونه از این جزوه استفاده کنیم؟

Section ID: `F0500AB0-2437-6164-D135-1AD22FE64FF3`

Import key: `math/chapter6-combinatorics-probability.html#section-01`

Topic ID: `None`

Source: [math/chapter6-combinatorics-probability.html](../../../../database-sources/math/9AD1CEE3-A225-3CCD-7691-660587C34F1A.html) — ID `9AD1CEE3-A225-3CCD-7691-660587C34F1A`

چگونه از این جزوه استفاده کنیم؟
هر بخش رو به همین ترتیب پیش برو تا هیچ‌جا گیر نکنی:
۱
فهم مفهوم
تعریف و فرمول رو بخون
۲
دیدن مثال
حل‌های قدم‌به‌قدم رو دنبال کن
۳
بررسی دام‌ها
اشتباهای رایج رو بشناس
۴
هایلایت امتحانی
ترفندهای سرعت رو یاد بگیر
۵
حل تمرین
خودت امتحان کن و پاسخ رو چک کن
۱
بخش اول

## اصل ضرب، جایگشت و ترکیب — کنار هم

Section ID: `08156335-DAF8-B462-8C24-7D2812D9FA3B`

Import key: `math/chapter6-combinatorics-probability.html#section-08`

Topic ID: `None`

Source: [math/chapter6-combinatorics-probability.html](../../../../database-sources/math/9AD1CEE3-A225-3CCD-7691-660587C34F1A.html) — ID `9AD1CEE3-A225-3CCD-7691-660587C34F1A`

اصل ضرب، جایگشت و ترکیب — کنار هم
این سه ابزار همیشه با هم قاطی می‌شن. قبل از حل هر سؤال شمارشی، از خودت این دو سؤال رو بپرس: «ترتیب مهمه؟» و «تکرار مجازه؟» — جواب همین دو سؤال مستقیم بهت می‌گه کدوم ستون این کارت مال توئه.
اصل ضرب
کاربرد
شمردن حالت‌های چند مرحلهٔ مستقل
ترتیب مهمه؟
بی‌ربط — مراحل جدان
تکرار
هم مجاز، هم غیرمجاز ممکنه
کلیدواژه
«برای هر ... و برای هر ...»
N = n
× n
× ...
۱
۲
جایگشت
کاربرد
چیدن اشیای متمایز به ترتیب
ترتیب مهمه؟
بله ✓
تکرار
معمولاً بدون تکرار
کلیدواژه
«چیدن»، «صف»، «رتبه»
P(n,r) =
n!
(n−r)!
ترکیب
کاربرد
انتخاب گروه، بدون چیدن
ترتیب مهمه؟
نه ✗
تکرار
معمولاً بدون تکرار
کلیدواژه
«انتخاب»، «کمیته»، «گروه»
C(n,r) =
n!
r!(n−r)!
★
مرور بخش‌های احتمال

## جدول جمع‌بندی فرمول‌های احتمال

Section ID: `1A6A3EB1-E978-4488-85A3-67138CD47034`

Import key: `math/chapter6-combinatorics-probability.html#section-09`

Topic ID: `None`

Source: [math/chapter6-combinatorics-probability.html](../../../../database-sources/math/9AD1CEE3-A225-3CCD-7691-660587C34F1A.html) — ID `9AD1CEE3-A225-3CCD-7691-660587C34F1A`

جدول جمع‌بندی فرمول‌های احتمال
همهٔ فرمول‌هایی که در این فصل با احتمال کار کردیم، در یک جدول — برای مرور سریع قبل از امتحان.
مفهوم
فرمول
بیان فارسی
احتمال پایه
P(A) = n(A) / n(S)
نسبت حالت‌های موردنظر به کل حالت‌ها
متمم
P(A′) = ۱ − P(A)
احتمال رخ‌ندادن A
اجتماع (یا)
P(A∪B) = P(A) + P(B) − P(A∩B)
حداقل یکی از A یا B رخ دهد
اجتماع پیشامدهای ناسازگار
P(A∪B) = P(A) + P(B)
وقتی A و B هم‌زمان رخ نمی‌دهند
تفاضل
P(A−B) = P(A) − P(A∩B)
فقط A رخ دهد (نه B)
هیچ‌کدام رخ ندهند
P(A′∩B′) = ۱ − P(A∪B)
نه A و نه B رخ دهد
دقیقاً یکی از دو
P(A)+P(B)−۲P(A∩B)
فقط یکی رخ دهد، نه هر دو
احتمال شرطی
P(A|B) = P(A∩B) / P(B)
احتمال A، به‌شرط رخ‌دادن B

## جمع‌بندی فصل ۶

Section ID: `EE5E1FEB-433A-FF89-4644-CEE37CCC32E6`

Import key: `math/chapter6-combinatorics-probability.html#section-10`

Topic ID: `None`

Source: [math/chapter6-combinatorics-probability.html](../../../../database-sources/math/9AD1CEE3-A225-3CCD-7691-660587C34F1A.html) — ID `9AD1CEE3-A225-3CCD-7691-660587C34F1A`

جمع‌بندی فصل ۶
اصل ضرب
اصل متمم
جایگشت
ترکیب
فضای نمونه
احتمال پایه
قوانین احتمال
احتمال شرطی
این فصل با شمردن حالت‌ها شروع شد (اصل ضرب و متمم)، بعد یاد گرفتیم چطور اشیای متمایز رو بچینیم (جایگشت) یا از بینشون انتخاب کنیم بدون توجه به ترتیب (ترکیب).
    سپس این ابزارهای شمارش رو وارد دنیای احتمال کردیم: از فضای نمونه و فرمول پایه، تا قوانین ترکیب پیشامدها، و در نهایت احتمال شرطی که یکی از پرکاربردترین مباحث امتحانیه.
اگه یک‌جا گیر کردی، برگرد به بخش اول: اکثر مسائل احتمال در واقع همون سؤال‌های شمارشِ اول فصل‌اند، فقط با یک فرمول احتمال روی‌شون.
