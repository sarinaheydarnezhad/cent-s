# Mathematics — ریاضی

Chapter folders preserve original order and IDs.

- [مسترکلاس ریاضی: پایه‌های محاسباتی](001-mastercalss-riazi-fasl1-3-chapter/): 11 lesson sections, 39 questions, 35 exercises.
- [معادلات، نامعادلات و هندسهٔ مختصات](002-chapter2-chapter/): 12 lesson sections, 36 questions, 35 exercises.
- [توابع (Functions)](003-chapter/): 10 lesson sections, 30 questions, 38 exercises.
- [مثلثات؛ از رادیان تا حل معادله](004-trig_chapter-chapter/): 7 lesson sections, 21 questions, 21 exercises.
- [هندسه از صفر تا تشابه و مختصات](005-geometry-chapter-chapter/): 5 lesson sections, 15 questions, 15 exercises.
- [ترکیبات و احتمال](006-chapter6-combinatorics-probability-chapter/): 6 lesson sections, 18 questions, 18 exercises.
- [آمار (Statistics)](007-chapter7-statistics-chapter/): 5 lesson sections, 15 questions, 15 exercises.
- [مبانی و تکمیل سرفصل CEnT-S — math](100-updates-2026-r1-chapter/): 7 lesson sections, 21 questions, 21 exercises.
- [مبانی و تکمیل سرفصل CEnT-S — math](100-updates-2026-r2-chapter/): 2 lesson sections, 6 questions, 6 exercises.
- [Source-wide sections (no chapter assigned in the original data)](_source-wide/19C7CDBD-2DF8-9F2C-1A05-63D46DE121F4/): 3 lesson sections, 0 questions, 0 exercises.
- [Source-wide sections (no chapter assigned in the original data)](_source-wide/252303E1-32E1-77F4-D8E2-B3F765C5F480/): 3 lesson sections, 0 questions, 0 exercises.
- [Source-wide sections (no chapter assigned in the original data)](_source-wide/9AD1CEE3-A225-3CCD-7691-660587C34F1A/): 5 lesson sections, 0 questions, 0 exercises.
- [Source-wide sections (no chapter assigned in the original data)](_source-wide/BF9D2665-4596-B277-18D4-97F78837DA08/): 3 lesson sections, 0 questions, 0 exercises.
- [Source-wide sections (no chapter assigned in the original data)](_source-wide/E9A151B7-6771-BD88-21E8-92C20F5BE4FC/): 3 lesson sections, 0 questions, 0 exercises.
- [Source-wide sections (no chapter assigned in the original data)](_source-wide/FB4BA96D-9049-D967-8C15-D757133E6642/): 3 lesson sections, 0 questions, 0 exercises.
- [Source-wide sections (no chapter assigned in the original data)](_source-wide/FF202D05-9692-A6E3-39B6-BB651FBA345A/): 4 lesson sections, 0 questions, 0 exercises.

`frontend-samples/` contains separate original frontend demo questions when present. `documents/` holds source document metadata. Reading shared texts and linked keys are in `passages/`.
