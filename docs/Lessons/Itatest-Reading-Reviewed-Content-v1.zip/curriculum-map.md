# Reading and Comprehension — syllabus alignment

Reference: CISIA, CEnT-S structure and syllabus, https://www.cisiaonline.it/en/cent/cent-s/structure-and-syllabus (checked 2026-11-24). Official section: 10 questions, 30 minutes; raw score +1 correct, −0.25 incorrect, 0 unanswered. The official format changed in November 2026. The mock grouping (two passages with five questions each) is an Itatest training convention, not a verified official group-size rule.

| Official skill / genre (paraphrased) | Existing lessons | New practice |
|---|---|---|
| English reading at upper-intermediate level | Vocabulary in context; details and paraphrase | All passages target B2; editorial estimate only |
| Abstraction and summarisation | Main idea; abstraction and evidential limits | Workshop, map, pause, labels |
| Formal and semantic relationships | Text structure; reference; evidence; attribution | Questions on transitions, paragraph functions, contrasts, scope |
| Implicit and implied meaning | Inference; purpose and tone | Literary narratives and inferences across all genres |
| Non-fiction | Tool library, museum | Workshop, map, pause, labels |
| Literary | Station | Spare key, chair, borrowed time |
| Journalistic | Bus trial, rainwater | Town hall, gallery, crossing |

The original ten lesson sections remain in the original two chapter records. The new materials are simulations written for learning, not authentic journalistic publications or literary/non-fiction excerpts selected according to CISIA's historical publication-date criteria. This gap remains; authentic licensed/public-domain reading could supplement the package. No external specialist knowledge is required by these questions. The difficulty labels have not been calibrated on real examinees.
