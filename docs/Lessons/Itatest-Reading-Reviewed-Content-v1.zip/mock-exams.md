# Reading Mock 1

10 questions · 30 minutes

## Passage 1: A quiet change in the workshop

A repair workshop used to offer a short demonstration before handing each visitor a broken object to examine. The organisers assumed that a clear explanation would make the rest of the session straightforward. Yet visitors often waited for someone to tell them which part to inspect next. Last winter, the organisers reversed the order. Visitors first examined an object in pairs and wrote down what they noticed. Only then did a volunteer demonstrate a possible repair. The change did not shorten the sessions. In fact, some pairs spent longer discussing the object than the volunteer spent repairing it. However, the questions visitors asked became more specific, and volunteers could respond to misunderstandings rather than repeat general instructions. The organisers do not regard initial confusion as desirable in itself. Their aim is to make the explanation answer a question the learner already has, while providing enough support to prevent frustration. They still demonstrate safety procedures before anyone handles equipment.

1. What is the central argument of the passage?

   A. Demonstrations should be removed from every workshop.
   B. Repair sessions are valuable only when they are short.
   C. An initial investigation can make later instruction more relevant.
   D. Visitors should learn entirely without volunteers.
   E. Safety instructions prevent meaningful questions.

2. What did the change NOT achieve, according to the passage?

   A. Shorter sessions
   B. More specific questions
   C. Opportunities to address misunderstandings
   D. Initial examination in pairs
   E. Delaying the repair demonstration

3. Why does the final sentence mention safety procedures?

   A. To explain why volunteers stopped giving demonstrations
   B. To suggest that repairs had become more dangerous
   C. To introduce a separate workshop for experts
   D. To prove the old approach was entirely ineffective
   E. To establish an exception to the revised teaching order

4. What can be inferred about the organisers' attitude to confusion?

   A. It is the principal measure of successful learning.
   B. It is acceptable only as part of a supported learning process.
   C. It should be prolonged even when visitors become frustrated.
   D. It indicates that every demonstration has failed.
   E. It is useful only for experienced repairers.

5. In context, "straightforward" most nearly means:

   A. Physically moving in a straight line
   B. Completely unrelated to instruction
   C. Requiring no equipment at all
   D. Easy to carry out or understand
   E. Repeated at a fixed speed

## Passage 2: The spare key

When Ellis returned to the flat, the hallway smelled of fresh paint. The landlord had left a new key in a small envelope, together with a note asking him to return the old one. Ellis placed both keys on the kitchen table. They looked almost identical, except for a worn mark on the older key where his thumb had rested for years. He had expected to feel pleased about the new lock. Instead, he remembered the evening when his neighbour had lent him a torch during a power cut, and the mornings when he had turned the key while balancing coffee and a bag of books. None of these memories belonged to the key itself, he told himself. He could have thrown it into the envelope without another thought. Yet he took a photograph of the two keys side by side before leaving the old one in the landlord's office. On his way back upstairs, he realised that the new key worked without the familiar little twist. He smiled at the unfamiliar ease.

6. What is suggested by Ellis's attention to the worn mark?

   A. He believes the landlord has given him the wrong key.
   B. The old key has become associated with his ordinary routines.
   C. He is trying to identify a manufacturing defect.
   D. He intends to repair the old lock himself.
   E. He cannot remember where he lives.

7. What does Ellis do before returning the old key?

   A. Gives the new key to his neighbour
   B. Removes the worn mark
   C. Asks for the old lock to be restored
   D. Writes a note about the power cut
   E. Photographs both keys together

8. What is the effect of the contrast between the two keys?

   A. It connects a small practical change with attachment to the past.
   B. It establishes that the landlord has behaved dishonestly.
   C. It shows that fresh paint is unsafe.
   D. It suggests that Ellis plans to move out immediately.
   E. It proves the older key was more efficient.

9. How is the final smile best interpreted?

   A. As proof that his earlier memories were false
   B. As a reaction to finding another old key
   C. As an attempt to hide anger from the landlord
   D. As a sign that Ellis is beginning to appreciate the change
   E. As evidence that he never liked the flat

10. Which description best fits the narrator's tone?

   A. Mocking and aggressive
   B. Urgent and alarmed
   C. Reflective and quietly hopeful
   D. Strictly instructional
   E. Unreservedly triumphant

# Reading Mock 2

10 questions · 30 minutes

## Passage 1: A new use for the town hall

The council of the fictional town of Linton has announced a three-month trial in which the unused upper floor of its town hall will become a study space. According to the council, the existing ground-floor library has been particularly crowded on weekday afternoons. The new room will open at those times, but it will not initially operate on weekends. A student group has welcomed the proposal while asking for evening access. The council says it must first establish whether additional staff would be needed. It expects that some existing library users will move upstairs, making more seats available below. However, there is no estimate of how many new users the room might attract. An independent accessibility group has pointed out that the upper floor can be reached by a lift, although the lift has occasionally been out of service. The council has promised to record interruptions during the trial. No decision about permanent operation has yet been made.

1. What is the status of the study space?

   A. Permanent weekend operation has been approved.
   B. It is already a replacement for the library.
   C. The council has abandoned the proposal.
   D. A temporary trial has been announced.
   E. It is open every evening.

2. Why is evening access not yet guaranteed?

   A. Students have opposed evening opening.
   B. The staffing requirements need to be established.
   C. The upper floor has no lighting.
   D. The library is empty during weekdays.
   E. The lift operates only at night.

3. What does the accessibility group's observation qualify?

   A. The number of books in the library
   B. The legal ownership of the town hall
   C. The practical reliability of access to the upper floor
   D. The estimated cost of weekend staffing
   E. The reason students prefer evenings

4. Which statement is a forecast of future user behaviour?

   A. The accessibility group has commented on the lift.
   B. The trial has a stated length of three months.
   C. The student group requested evening access.
   D. No permanent decision has yet been made.
   E. Some library users are expected to move upstairs.

5. What is the main purpose of the report?

   A. To describe a trial proposal and the questions still unresolved
   B. To argue that public libraries should close
   C. To announce the final timetable of a permanent service
   D. To teach students how to reserve a seat
   E. To establish that the council has solved every access problem

## Passage 2: A map that changes with the walker

A printed map usually shows where paths lead, but it rarely tells a walker how those paths feel. One research team asked people to describe a short journey through their neighbourhood using words rather than distances. Some participants described a road as long because they had to wait at several crossings. Others described a similar distance as short because the route passed places where they liked to stop. The team was not proposing a replacement for conventional maps. Accurate distances remain essential for many purposes, including estimating travel time. Instead, the descriptions revealed qualities that a simple measurement can overlook. A map designed to help someone choose a pleasant route may need different information from one designed to help a delivery driver find the quickest route. The choice of information depends on the intended user. The researchers therefore argued that maps should be evaluated in relation to the decisions they are meant to support, rather than by a single universal standard.

6. What is the main conclusion?

   A. A map's usefulness depends on the decisions it is designed to support.
   B. Descriptions should replace all distance measurements.
   C. Everyone experiences the same journey in the same way.
   D. Delivery drivers should always choose the most pleasant route.
   E. Printed maps cannot represent roads accurately.

7. Why does the author mention waiting at crossings?

   A. To show that crossings should be removed from every road
   B. To establish a precise walking speed
   C. To explain why printed maps are illegal
   D. To illustrate why perceived length can differ from measured distance
   E. To prove that pleasant routes are always faster

8. What does "Instead" signal in the middle of the passage?

   A. A chronological step after printing a new map
   B. A shift from a rejected interpretation to the team's actual purpose
   C. A reason to abandon accurate distances
   D. A contradiction of the participants' descriptions
   E. A new example of a delivery route

9. Which statement follows from the team's argument?

   A. A route with accurate distances cannot be pleasant.
   B. All users need identical information.
   C. Two maps of the same area may be useful for different reasons.
   D. The longest route is always the least attractive.
   E. A delivery map must omit street names.

10. In context, "overlook" most nearly means:

   A. View from a high building
   B. Deliberately measure twice
   C. Draw in greater detail
   D. Replace with a shorter path
   E. Fail to take into account

# Reading Mock 3

10 questions · 30 minutes

## Passage 1: The chair by the window

For as long as Nila could remember, her aunt had kept a chair beside the window, facing the street rather than the television. On Sunday afternoons they used to sit there and guess where people were going, inventing occupations for strangers carrying unusual bags. Years later, Nila came to help her aunt move into a smaller apartment. Her cousin had already labelled the furniture: keep, sell, donate. The chair had received a donation label. Nila's aunt noticed her reading it and said that the new apartment had no suitable window. Nila began to argue, but her aunt interrupted by asking whether they could take the little table instead. They had used it for cups of tea on those afternoons. Nila suddenly understood that her aunt was not trying to preserve the room exactly as it had been. She was choosing which parts of it could continue to have a place in her life. Nila removed the label from the table and found a pencil to write another.

1. Why is the chair important to Nila?

   A. It is the most expensive item in the room.
   B. She believes it belongs to her cousin.
   C. It was bought for the new apartment.
   D. She uses it to watch television every day.
   E. It is connected to shared memories with her aunt.

2. Why does the aunt ask to take the table instead?

   A. It will allow her to restore the entire room exactly.
   B. It is the only item with a donation label.
   C. It offers a way to retain part of the old routine.
   D. It has never been used by the family.
   E. It is required to repair the window.

3. What changes in Nila's understanding?

   A. She decides that all the furniture should be sold.
   B. She concludes that her aunt has forgotten their afternoons.
   C. She learns that the new apartment has a larger window.
   D. She recognises that preserving memories need not mean keeping every object.
   E. She discovers that her cousin never labelled the chair.

4. What is the narrative function of the labels?

   A. They make the abstract problem of change concrete through practical choices.
   B. They reveal a secret message left by the aunt.
   C. They identify the occupations of strangers in the street.
   D. They prove that the cousin wants to keep all the furniture.
   E. They establish that the table is broken.

5. Which word best describes the tone of the passage?

   A. Contemptuous
   B. Thoughtful
   C. Panicked
   D. Boastful
   E. Indifferent

## Passage 2: The second entrance

A fictional regional gallery has introduced a second entrance for visitors who already hold tickets. Its director says the aim is to reduce the queue near the main door, where people buy tickets and ask for information. During the first two Saturdays, staff recorded shorter queues at the main door than on the previous two Saturdays. Yet attendance was also lower, following a change in the exhibition programme. The director described the early observations as useful but insufficient to establish the effect of the new entrance. Some visitors reported that the signs outside the building were unclear. In response, the gallery moved one sign closer to the pavement, a change that was made after the first two Saturdays. Staff will now collect waiting-time measurements at both entrances, rather than simply counting people in the main queue. The gallery has not announced whether the arrangement will become permanent. The results of the next phase will be discussed at its next management meeting.

6. What is the main reason the early queue results are inconclusive?

   A. Staff refused to observe the queues.
   B. Tickets were no longer available.
   C. Attendance was lower during the same period.
   D. The second entrance was closed on both Saturdays.
   E. The management meeting had already cancelled the trial.

7. What will staff measure in the next phase?

   A. Waiting times at both entrances
   B. The price of all tickets sold
   C. The number of exhibitions planned next year
   D. The distance from the pavement to every gallery room
   E. The number of visitors who have never bought tickets

8. Why does the report specify when the sign was moved?

   A. To prove that signs caused all the shorter queues
   B. To establish that visitors had complained before the gallery opened
   C. To explain why the exhibition programme changed
   D. To show that the original sign was never visible
   E. To distinguish a later adjustment from the conditions of the initial observations

9. Which statement is best supported by the report?

   A. The second entrance has conclusively reduced waiting times.
   B. The trial is ongoing and its effect has not yet been isolated.
   C. Every ticket holder prefers the new entrance.
   D. Lower attendance was caused by the second entrance.
   E. A permanent arrangement has been approved.

10. What does "insufficient" mean in this context?

   A. Entirely unrelated to the gallery
   B. Deliberately inaccurate
   C. Too expensive to collect
   D. Not enough to justify the conclusion
   E. Impossible to measure

# Reading Mock 4

10 questions · 30 minutes

## Passage 1: Borrowed time

At closing time, the bookshop owner asked Theo whether he wanted the novel he had been reading near the back shelf. Theo checked the price again, although he already knew it was more than he could spend that week. He said he was still deciding. The owner nodded and placed a small paper bookmark at the page Theo had reached. On the following afternoon, Theo returned, expecting the book to be gone. It was still on the shelf, but the bookmark had been moved to the front. For a moment he thought the owner had forgotten him. Then he opened the book and found a note: the owner had reserved another copy for a customer, leaving this one available for anyone to read in the shop. Theo had mistaken an ordinary gesture of welcome for a personal favour that he might have to repay. He read the next chapter, and when another reader approached the shelf, he moved his bag to make space.

1. Why does Theo say he is still deciding?

   A. He has not yet seen the price.
   B. He is reluctant to admit that he cannot afford the book that week.
   C. He dislikes the novel's first chapter.
   D. He wants to buy the book for the owner.
   E. He cannot find the correct shelf.

2. What does Theo initially think when he finds the bookmark moved?

   A. The novel has been sold.
   B. The customer has torn out a page.
   C. The bookmark was never there.
   D. The owner has increased the price.
   E. The owner may have forgotten him.

3. What does the owner's note clarify?

   A. The book is available to readers generally, not reserved solely for Theo.
   B. Theo is expected to pay for both copies.
   C. The shop will stop allowing people to read inside.
   D. Another customer has bought this particular copy.
   E. Theo may take the book home without paying.

4. What is the significance of Theo moving his bag?

   A. He plans to leave without finishing the chapter.
   B. He is trying to hide the book's price.
   C. He wants the other reader to buy the novel for him.
   D. He acts in a way that shares the welcome he has received.
   E. He is following an explicit instruction from the owner.

5. Which interpretation best captures the passage?

   A. A dispute about money ends in a refund.
   B. A reader learns that bookshops never reserve books.
   C. A perceived personal obligation becomes an understanding of shared hospitality.
   D. A customer discovers the owner has been dishonest.
   E. A novel is lost because of a misplaced bookmark.

## Passage 2: The value of a pause

In a discussion group, quick answers may appear to demonstrate confidence. A facilitator noticed, however, that the same few participants often answered first, while others rarely joined in. She introduced a brief silent period after posing a question. Everyone could write a few words before anyone spoke. At first, the change seemed to interrupt the rhythm of the meeting. Some participants worried that discussion would become less spontaneous. After several sessions, the facilitator noticed a wider range of speakers. She did not conclude that silence had made every contribution better. A greater number of speakers is not the same as a greater quality of argument. Nevertheless, the new arrangement appeared to make participation less dependent on the speed with which someone could formulate an answer. The facilitator kept the silent period for complex questions but removed it for routine announcements. The point was not to make every conversation slower, but to choose a rhythm that fitted the task.

6. What is the main idea?

   A. All discussions must be silent before anyone speaks.
   B. Fast answers are always less accurate.
   C. A larger number of speakers proves that arguments improve.
   D. A short pause can widen participation when the task benefits from reflection.
   E. Routine announcements require longer preparation than complex questions.

7. Why did the facilitator introduce the silent period?

   A. To stop confident participants from ever speaking
   B. To give more participants time to formulate an answer
   C. To replace discussion with written examinations
   D. To ensure that every contribution was correct
   E. To shorten the length of all meetings

8. What distinction does the passage make about the observed result?

   A. Writing answers is identical to giving announcements.
   B. Confident participants cannot provide good arguments.
   C. Wider participation does not necessarily imply better arguments.
   D. Complex questions should have no answers.
   E. Silence and reflection are always equivalent.

9. What does "spontaneous" most nearly mean here?

   A. Recorded in an official document
   B. Limited to written responses
   C. Carefully memorised in advance
   D. Completely unrelated to the topic
   E. Arising naturally without much advance planning

10. Why was the pause removed for routine announcements?

   A. The facilitator adapted the method to the needs of different tasks.
   B. The experiment had proved the pause harmful in all cases.
   C. Nobody could understand the announcements.
   D. The number of participants had doubled.
   E. Written notes were no longer permitted.

# Reading Mock 5

10 questions · 30 minutes

## Passage 1: A crossing under review

In the fictional district of Ashbrook, a temporary pedestrian crossing has been installed outside a community centre. Local officials say that the crossing was requested by people attending evening classes. During its first month, a volunteer group counted more pedestrians crossing at that location than before the installation. The group noted that the centre had also begun hosting a weekly market, which might have brought additional visitors. A resident association welcomed the crossing, arguing that it made the route easier to understand for people unfamiliar with the area. The road authority, however, has not yet completed its review of vehicle speeds or near misses. It has asked the volunteers to continue their counts but will collect separate traffic observations. An official explained that the number of pedestrians using a facility was relevant to its usefulness, although it could not by itself establish how safely the facility operated. The crossing will remain temporary until the review is complete.

1. What is the limitation of the volunteer count?

   A. It does not establish either the crossing's independent effect or its safety.
   B. It proves that nobody used the crossing before installation.
   C. It directly measures all vehicle speeds and near misses.
   D. It establishes that the market has closed.
   E. It shows that evening classes were cancelled.

2. What did the resident association claim?

   A. The crossing had eliminated all near misses.
   B. The market should be permanently closed.
   C. Vehicle speeds had been measured and reduced.
   D. The crossing made the route easier for unfamiliar visitors to understand.
   E. The centre should stop hosting evening classes.

3. Why are separate traffic observations planned?

   A. They will replace the community centre's classes.
   B. They provide evidence relevant to safety beyond pedestrian counts.
   C. They show that the volunteer group fabricated its numbers.
   D. They are needed to determine the price of market goods.
   E. They will count only people who have never used the road.

4. What is the current status of the crossing?

   A. It has already been approved permanently.
   B. It will be removed before any observations take place.
   C. It remains temporary pending completion of the review.
   D. It is restricted to market traders.
   E. It has been replaced by a bridge.

5. Which description best fits the report's tone?

   A. Dismissive of all residents' concerns
   B. Certain that the crossing is unsafe
   C. Celebratory without qualification
   D. Humorous and fictional in its treatment of the officials
   E. Balanced and cautious about the evidence

## Passage 2: What a label can tell us

A small exhibition displayed everyday objects together with short descriptions of their origins. The curator initially arranged the objects according to their country of manufacture. Visitors could easily compare objects from the same place, but they often missed similarities in how the objects were used. In a later arrangement, the curator grouped objects by function: carrying, storing, measuring and preparing. The country labels remained visible. The new arrangement encouraged comparisons across regions, although it made the original geographical pattern less obvious. The curator concluded that neither arrangement was neutral. Each made a particular kind of relationship easy to notice and placed others in the background. This did not mean that the objects had changed or that every interpretation was equally valid. Their origins and uses still provided limits on what could be claimed. Rather, the exhibition illustrated how the organisation of information can influence which questions a reader or visitor is likely to ask first.

6. What is the central claim?

   A. Grouping by function changes the actual origin of objects.
   B. Country labels should always be removed from exhibitions.
   C. Every interpretation of an object is equally accurate.
   D. Objects from one region can never be compared with others.
   E. The organisation of information influences which relationships people notice.

7. What remained visible after the rearrangement?

   A. Only the names of the curators
   B. A map of every exhibition in the country
   C. The country labels
   D. The previous physical grouping by country
   E. The prices of all objects

8. What is meant by "neither arrangement was neutral"?

   A. Both contained deliberately false descriptions.
   B. Neither arrangement had any educational value.
   C. Neither arrangement involved a physical change.
   D. Both arrangements emphasised some relationships over others.
   E. Both arrangements prevented comparison altogether.

9. Why does the author state that the objects themselves had not changed?

   A. To distinguish a change in presentation from a change in facts
   B. To claim that the curator never rearranged anything
   C. To prove that the original arrangement was always superior
   D. To explain why all labels were removed
   E. To show that function cannot be studied in an exhibition

10. Which generalisation follows from the passage?

   A. A classification is useful only if it is the sole possible one.
   B. Different classifications can highlight different valid aspects of the same material.
   C. Any new grouping makes all earlier information false.
   D. An object's actual use depends entirely on its label.
   E. Every reader will ask exactly the same question first.
