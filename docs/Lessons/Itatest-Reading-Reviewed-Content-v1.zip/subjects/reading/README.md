# Reading and Comprehension — درک مطلب انگلیسی

Chapter folders preserve original order and IDs.

- [مبانی و تکمیل سرفصل CEnT-S — reading](100-updates-2026-r1-chapter/): 8 lesson sections, 23 questions, 23 exercises.
- [مبانی و تکمیل سرفصل CEnT-S — reading](100-updates-2026-r2-chapter/): 2 lesson sections, 10 questions, 10 exercises.

`frontend-samples/` contains separate original frontend demo questions when present. `documents/` holds source document metadata. Reading shared texts and linked keys are in `passages/`.
