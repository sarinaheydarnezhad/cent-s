# reading-bus-r1

Source: `curriculum-2026.json`; release `cent-content-2026-r1`

In the fictional town of Bellford, a six-week trial of a later evening bus has ended with a modest rise in passenger numbers. The transport office said the additional departure carried an average of eighteen passengers on weekdays. It had expected fifteen. Officials will now consider whether to continue the service through the winter.

A traders' association welcomed the result, saying that employees who finished after the previous last bus could travel home without paying for a taxi. The office also received requests for an earlier connection from the railway station. The trial route did not include that station, and its timetable was not designed to meet arriving trains.

The passenger figures do not settle the question of cost. During the trial, the operator used a vehicle that would otherwise have returned empty to its depot. Continuing the service may require different staffing arrangements. The transport office has not yet published a comparison of these costs.

Several residents described the service as a success at a public meeting on Tuesday. The meeting was open to anyone, but attendance was voluntary, so those comments cannot be treated as a survey of the whole town. The office plans to collect written responses before making a decision. For now, the trial shows that there is some demand for the later journey; it does not show that every proposed expansion would be equally useful.
