# reading-station-r1

Source: `curriculum-2026.json`; release `cent-content-2026-r1`

Mara arrived at the station early enough to watch the café owner lift the chairs from the tables. She put an envelope beside her cup and turned it so that the address faced the window. For three weeks she had carried it between her desk and the front door, always finding another reason to wait.

Her brother had written that the old house would be sold in spring. There was no accusation in his letter, only a request that she say which objects she wanted to keep. That reasonable question had unsettled her more than an argument might have done. A blue bowl came to mind, then a cracked wooden ruler, then nothing she could name without feeling foolish.

When the announcement for her train sounded, Mara lifted the envelope. Across the room, a child was teaching a younger child to read the departure board. They tried the longer names together and laughed when they reached the end of one. Mara watched until the café owner asked whether she wanted another cup.

"Not today," she said, and smiled as if she had answered a different question. On the platform she opened the envelope, added a line beneath her careful list, and sealed it again. Then she walked towards the post box instead of the train. She could take the next one. For the first time that morning, waiting seemed like a choice rather than a habit.
