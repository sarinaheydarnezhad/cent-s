# reading-roof-r2

Source: `curriculum-2026-r2.json`; release `cent-content-2026-r2`

A fictional local newspaper reports that a school has finished its first season of collecting rainwater from a roof for use in its garden. The caretaker estimated that the system supplied about one third of the garden water during that season. The figure was based on tank readings, not on a prediction of rainfall for future years.

The school said it had reduced the amount of treated mains water used outdoors. It did not claim that the collected water was suitable for drinking, and the newspaper found no published test establishing that it was. Garden use and drinking-water use involve different requirements; success at one does not by itself establish suitability for the other.

An environmental club proposed installing a second tank. The caretaker supported examining the idea but pointed out that storage was not the only constraint. During long dry periods, even a larger tank could eventually be empty. During heavy rain, the amount reaching a tank also depended on the area and condition of the roof and gutters. Extra capacity would help only when there was additional water available to store.

The governing board has requested records from another season before deciding. One board member called the first results promising, while adding that a second season would not remove all uncertainty about later weather. The current report therefore describes a useful local trial and a proposal still under review, rather than a decision already made.
