# reading-tool-library-r1

Source: `curriculum-2026-r2.json`; release `cent-content-2026-r2`

A conventional library lends books, but several neighbourhoods have begun experimenting with libraries of things: collections of tools, kitchen equipment and other objects that members borrow briefly. The idea responds to a simple mismatch. An electric drill may be useful to many households, yet each household may need one for only a few minutes a year. Sharing can reduce both expenditure and the space devoted to rarely used possessions.

The arithmetic, however, is not the whole story. An object that serves many borrowers must be checked, repaired and occasionally replaced. Someone must explain how to use it safely. A collection without a reliable maintenance budget can become a cupboard of broken promises. The organisers of one fictional neighbourhood scheme therefore began with a small range of robust equipment rather than accepting every donation.

They also discovered that access was not equally easy for everyone. Evening opening helped people who worked during the day, while a telephone reservation system helped those uncomfortable with online forms. These changes did not increase the number of objects, but they made the existing collection useful to a wider group.

A library of things is consequently better understood as a service than as a pile of shared possessions. Its success depends on the arrangements that keep objects usable and borrowing practical. The promise of buying less remains attractive, provided that sharing is organised as carefully as buying.
