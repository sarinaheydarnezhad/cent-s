# reading-museum-r2

Source: `curriculum-2026-r2.json`; release `cent-content-2026-r2`

At a fictional museum, the education team replaced a long introduction to an exhibition with three short questions printed on a card. Visitors could choose one question, look for an object that helped them answer it, and compare their choice with a companion. The card did not identify a single correct object. Its purpose was to encourage visitors to explain the connection they had made.

In a small observation exercise, the team recorded more conversations near the entrance after the cards appeared. That finding did not show that visitors learned more facts. Conversation length had been recorded, but no test of factual knowledge had been given. Nor could the team exclude the possibility that a new seating area, installed during the same week, helped people stay and talk.

Some staff worried that a question without a single answer would make the exhibition seem vague. Others argued that an answer could be open without being arbitrary: visitors still needed evidence from an object to support it. A claim about a painted scene, for example, could be challenged if the described detail was absent. On this view, several interpretations might be reasonable while some remained unsupported.

The team decided to keep the cards and to study how they were used. Its report distinguished two goals: helping people begin a conversation and helping them improve an explanation. The first observations offered limited evidence for the first goal. Evaluating the second would require attention to what visitors said, rather than only how long they spoke.
