# Reading Mock 1

1. **C — An initial investigation can make later instruction more relevant.**

   متن ترتیب تازه را برای مرتبط‌کردن توضیح با پرسش یادگیرنده ارزشمند می‌داند؛ حذف آموزش یا ایمنی را پیشنهاد نمی‌کند.

2. **A — Shorter sessions**

   متن صریحاً می‌گوید زمان جلسه کوتاه نشد؛ سایر گزینه‌ها با روش جدید یا نتایج آن سازگارند.

3. **E — To establish an exception to the revised teaching order**

   ایمنی پیش از کار با ابزار آموزش داده می‌شود، پس همهٔ توضیحات به بعد از بررسی منتقل نشده‌اند.

4. **B — It is acceptable only as part of a supported learning process.**

   بند پایانی میان سردرگمی اولیه و هدف آموزشی تمایز می‌گذارد و بر حمایت کافی تأکید دارد.

5. **D — Easy to carry out or understand**

   در جملهٔ نخست انتظار می‌رود پس از توضیح ادامهٔ جلسه آسان باشد؛ معنی مکانی واژه مناسب نیست.

6. **B — The old key has become associated with his ordinary routines.**

   خاطرات عادی با علامت فرسودگی و سال‌ها استفاده پیوند خورده‌اند؛ متن مشکل فنی یا فراموشی نشانی را نشان نمی‌دهد.

7. **E — Photographs both keys together**

   بند دوم گرفتن عکس از دو کلید را پیش از بازگرداندن کلید قدیمی بیان می‌کند.

8. **A — It connects a small practical change with attachment to the past.**

   تفاوت جزئی دو کلید زمینه‌ای برای یادآوری گذشته و پذیرش تغییر فراهم می‌کند.

9. **D — As a sign that Ellis is beginning to appreciate the change**

   آسانی تازهٔ بازکردن در و لبخند نشان‌دهندهٔ پذیرش احتمالی تغییر است؛ قطعیت دربارهٔ همهٔ احساسات او نداریم.

10. **C — Reflective and quietly hopeful**

   روایت با تأمل در خاطرات و پایان آرام همراه است، نه تمسخر یا اضطرار.

# Reading Mock 2

1. **D — A temporary trial has been announced.**

   جملهٔ نخست دورهٔ آزمایشی سه‌ماهه را اعلام می‌کند و پایان متن تصمیم دائمی را رد می‌کند.

2. **B — The staffing requirements need to be established.**

   شورا نیاز احتمالی به نیروی اضافی را علت تصمیم‌نگرفتن معرفی می‌کند.

3. **C — The practical reliability of access to the upper floor**

   وجود آسانسور دسترسی را ممکن می‌کند، ولی خرابی گهگاه آن قابلیت اتکا را محدود می‌کند.

4. **E — Some library users are expected to move upstairs.**

   جابه‌جایی برخی کاربران پیش‌بینی شورا است و هنوز نتیجهٔ مشاهده‌شده نیست؛ سایر موارد گزارش وضعیت یا رویداد هستند.

5. **A — To describe a trial proposal and the questions still unresolved**

   گزارش برنامه و محدودیت‌های نیروی انسانی، تقاضا و دسترسی را بیان می‌کند و تصمیم قطعی نمی‌دهد.

6. **A — A map's usefulness depends on the decisions it is designed to support.**

   نتیجهٔ نهایی معیار ارزیابی نقشه را هدف و نیاز کاربر می‌داند، نه یک معیار همگانی.

7. **D — To illustrate why perceived length can differ from measured distance**

   مثال عبور از تقاطع‌ها نشان می‌دهد تجربهٔ مسیر صرفاً تابع فاصله نیست.

8. **B — A shift from a rejected interpretation to the team's actual purpose**

   نویسنده ابتدا جایگزینی نقشهٔ سنتی را رد می‌کند و سپس هدف واقعی را توضیح می‌دهد.

9. **C — Two maps of the same area may be useful for different reasons.**

   تفاوت هدف گردشگر و راننده نشان می‌دهد نقشه‌های یک منطقه می‌توانند کارکردهای متفاوت داشته باشند.

10. **E — Fail to take into account**

   منظور ویژگی‌هایی است که اندازه‌گیری ساده در نظر نمی‌گیرد؛ معنای مکانی واژه مناسب نیست.

# Reading Mock 3

1. **E — It is connected to shared memories with her aunt.**

   بند اول خاطرات مشترک کنار پنجره را بیان می‌کند؛ قیمت یا مالکیت مورد ادعا نیست.

2. **C — It offers a way to retain part of the old routine.**

   میز محل چای‌خوردن مشترک بوده و انتخاب آن با حفظ بخشی از زندگی گذشته سازگار است.

3. **D — She recognises that preserving memories need not mean keeping every object.**

   بند پایانی تغییر برداشت نیلا را مستقیماً توضیح می‌دهد.

4. **A — They make the abstract problem of change concrete through practical choices.**

   برچسب‌ها تصمیم‌های ملموس دربارهٔ اشیا را به مسئلهٔ پذیرش تغییر پیوند می‌دهند.

5. **B — Thoughtful**

   روایت آرام و تأملی است و تفاهم شخصیت‌ها را نشان می‌دهد؛ سایر لحن‌ها شاهدی ندارند.

6. **C — Attendance was lower during the same period.**

   کاهش حضور بازدیدکننده توضیح جایگزین برای کوتاه‌تر شدن صف است.

7. **A — Waiting times at both entrances**

   بند پایانی برنامهٔ اندازه‌گیری زمان انتظار هر دو ورودی را مشخص می‌کند.

8. **E — To distinguish a later adjustment from the conditions of the initial observations**

   جابه‌جایی پس از دو شنبهٔ اول بوده، پس نمی‌تواند تغییر انجام‌شده در آن دو مشاهده را توضیح دهد.

9. **B — The trial is ongoing and its effect has not yet been isolated.**

   مدیر دادهٔ اولیه را ناکافی می‌داند و تصمیم نهایی نگرفته شده است.

10. **D — Not enough to justify the conclusion**

   دادهٔ اولیه مفید است ولی برای تعیین اثر کافی نیست؛ متن آن را جعلی یا نامرتبط نمی‌نامد.

# Reading Mock 4

1. **B — He is reluctant to admit that he cannot afford the book that week.**

   متن قیمت را بیش از بودجهٔ همان هفته می‌داند؛ «هنوز تصمیم نگرفته‌ام» با پنهان‌کردن این مشکل سازگار است.

2. **E — The owner may have forgotten him.**

   جملهٔ مربوط به واکنش اولیه این فکر را صریحاً گزارش می‌کند.

3. **A — The book is available to readers generally, not reserved solely for Theo.**

   نسخهٔ دیگر برای مشتری رزرو شده و این نسخه برای هر خواننده در فروشگاه قابل استفاده است.

4. **D — He acts in a way that shares the welcome he has received.**

   حرکت آخر بازتاب درک تازهٔ او از عمومی‌بودن فضا و امکان استفادهٔ دیگران است.

5. **C — A perceived personal obligation becomes an understanding of shared hospitality.**

   متن دربارهٔ تغییر برداشت تئو از لطف شخصی به خوشامد عمومی است؛ اختلاف مالی یا گم‌شدن کتاب رخ نداده است.

6. **D — A short pause can widen participation when the task benefits from reflection.**

   نویسنده مکث را ابزار متناسب با نوع کار برای مشارکت گسترده‌تر می‌داند، نه قاعدهٔ همگانی.

7. **B — To give more participants time to formulate an answer**

   مشکل پاسخ‌دادن همیشگی چند نفر با زمان کوتاه فکرکردن برای همه هدف گرفته شد.

8. **C — Wider participation does not necessarily imply better arguments.**

   متن افزایش تعداد گویندگان را با کیفیت استدلال یکسان نمی‌داند.

9. **E — Arising naturally without much advance planning**

   نگرانی مربوط به کم‌شدن طبیعی‌بودن و بی‌درنگی گفت‌وگو است.

10. **A — The facilitator adapted the method to the needs of different tasks.**

   جملهٔ آخر هدف را انتخاب ریتم متناسب با وظیفه معرفی می‌کند.

# Reading Mock 5

1. **A — It does not establish either the crossing's independent effect or its safety.**

   بازار عامل جایگزین افزایش تردد است؛ تعداد عابر نیز به‌تنهایی معیار ایمنی نیست.

2. **D — The crossing made the route easier for unfamiliar visitors to understand.**

   ادعای انجمن دربارهٔ فهم آسان‌تر مسیر است، نه اثبات ایمنی.

3. **B — They provide evidence relevant to safety beyond pedestrian counts.**

   بررسی سرعت و نزدیک‌تصادف‌ها برای ارزیابی ایمنی اطلاعات متفاوتی فراهم می‌کند.

4. **C — It remains temporary pending completion of the review.**

   جملهٔ آخر وضعیت موقت تا پایان بررسی را مشخص می‌کند.

5. **E — Balanced and cautious about the evidence**

   گزارش استقبال و محدودیت شواهد را هم‌زمان بیان می‌کند؛ ساختگی‌بودن محل به معنی لحن طنز نیست.

6. **E — The organisation of information influences which relationships people notice.**

   متن اثر سازمان‌دهی بر روابط قابل مشاهده را محور قرار می‌دهد و تغییر واقعیت اشیا را رد می‌کند.

7. **C — The country labels**

   متن صریحاً باقی‌ماندن برچسب کشورها را می‌گوید.

8. **D — Both arrangements emphasised some relationships over others.**

   هر چینش توجه را به دسته‌ای از روابط جلب و دسته‌ای دیگر را کم‌رنگ می‌کند؛ این به معنی جعل داده نیست.

9. **A — To distinguish a change in presentation from a change in facts**

   نویسنده میان تغییر نمایش و تغییر واقعیت بیرونی مرز می‌گذارد.

10. **B — Different classifications can highlight different valid aspects of the same material.**

   مقایسهٔ چینش جغرافیایی و کاربردی نمونه‌ای از برجسته‌کردن جنبه‌های متفاوت همان داده‌هاست.
