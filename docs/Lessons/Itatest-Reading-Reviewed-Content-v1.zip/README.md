# Itatest Reading and Comprehension — reviewed content v1

Content-only handoff for Codex. No application code, database migrations, credentials or user data. Original lesson order, topic IDs, section IDs, question IDs and exercise IDs remain unchanged. The input was the local export, not production.

## Apply
- `subjects/reading/`: reviewed copies of existing content; two original question stems and two lesson examples were corrected. Existing question keys were retained. `patches.json` lists precise field-level changes. Treat original `_source` metadata and SHA values as historical provenance, not as updated hashes.
- `database-sources/reading/`: matching reviewed source HTML and Markdown. Do not reimport these as extra chapters. Regenerate source metadata and any derived documents from the selected reviewed sources in the target environment.
- `existing-passages-canonical.json`: five distinct existing passages with original question-group references. The R1 historical snapshots duplicate three of the R2 passages; do not import both releases as distinct active content. Original exercise records duplicate the 33 original questions and must not be counted twice.
- `new-passages.json`, `new-questions.json`, `mock-exams.json`: 10 additional original passages, 50 new five-option questions, and five 10-question / 30-minute practice exams. New UUIDs are deterministic; question keys and group relationships are explicit. Questions carry existing skill/topic associations; new content source keys are proposed and Codex must map them to the application schema. No new exercises are implied by the mock questions.
- `mock-exams.md` / `.html`: student-facing preview without keys; `mock-answers.md`: separate instructor/feedback answers. Do not expose answer keys during timed attempts.
- `curriculum-map.md`: official syllabus comparison and genre limitations. `validation.json`: structural validation results.

## Review status
All 33 original question stems, choices and keys were compared against their passage or short excerpt. Two stems were clarified without changing keys. The 10 existing lesson sections were read; two generic repeated examples replaced. The new passages and questions were authored for training, with Persian explanations. All 83 unique questions have five distinct options and consistent zero-based answers. Each mock has two passages and 10 unique questions, with two answers per option letter. This is an editorial design choice, not a CISIA specification. The passages are original simulations targeting B2; no independent specialist review, CEFR calibration, live import or frontend test has been performed. They are not official CISIA questions or authentic published excerpts.
